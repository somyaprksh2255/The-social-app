# Squado — Codebase Discovery Report

**Project:** `squado-section03/squado-readable-rebuild`  
**Investigation date:** 2025  
**Status:** Read-only inspection complete. Baseline build/test could not be run due to PowerShell execution policy restrictions on `npm` scripts; Node.js itself is available at v22.14.0. Build and test outputs are described from source analysis only.

---

## Summary

Squado is a complete, well-structured **frontend-only** social meetup app. Every feature is implemented in client-side HTML/CSS/JavaScript — auth, membership, chat, QR attendance, feedback, and notifications all work within a single browser's `localStorage`. There is **no backend, no database, no API server**. The codebase is ready for a Supabase integration; the frontend has clean module boundaries, centralized access control, and thorough inline documentation of exactly what a backend must provide.

---

## 1. Technology Stack

### Runtime (no build step needed)
| Layer | Technology |
|---|---|
| Language | Vanilla JavaScript (ES2020+, no TypeScript, no JSX) |
| Framework | None — plain `<script>` tags sharing one global scope |
| CSS | Plain CSS with custom properties (CSS variables), 5 files |
| Fonts | Poppins via Google Fonts CDN |
| Icons | Lucide 0.469.0 (jsDelivr CDN), Twemoji 15.1.0 SVGs (jsDelivr CDN) |
| QR code | `qrcode-generator@1.4.4` + `jsQR@1.4.0` (jsDelivr CDN) |
| Auth | Google Identity Services (`accounts.google.com/gsi/client`) |
| Persistence | `localStorage` key `squado-v5` (one JSON blob) |

### Dev tooling (Node ≥ 18, zero npm runtime dependencies)
| Tool | File | Purpose |
|---|---|---|
| Dev server | `scripts/dev-server.js` | Zero-dep HTTP static server, port 5173 |
| Build checker | `scripts/build.js` | Verifies all `index.html` refs exist + JS syntax check, copies to `dist/` |
| Tests | `tests/e2e.test.js` | Simulated DOM e2e test suite using Node's `vm` module |

**Dev server port:** `5173` (default; overridable via `PORT` env var)  
**No bundler, no transpiler, no Babel, no Webpack/Vite/esbuild.**

---

## 2. Entry Point Flow

### Load order (defined entirely by `index.html` script tags)

```
config.js                    → window.SQUADO_CONFIG (googleClientId, appBaseUrl, etc.)
utils/icons.js               → I(), T[] icon helpers
components/common/DoodleBackground.js
constants/activities.js      → T{}, INT[], INT_T{}, AGES[]
data/locations.js            → CITY_DATA[], cityOfLoc(), isCity(), LC{}
constants/options.js         → VIBES[], MF[], FT[], AVC[]
data/users.js                → U[] (8 mock users)
data/plans.js                → P0[] (mock plans)
data/events.js               → E0[] (4 mock events)
data/notifications.js        → NOTIFS0 = []
data/chats.js                → CHATS0{}, UNREAD0{}
state/store.js               → S (global state), O (UI state), save(), GUEST()
state/selectors.js           → usr(), pl(), vis(), unreadFor(), etc.
utils/helpers.js             → path(), goHash()
utils/time.js                → hm(), mins(), nowM()
utils/geo.js                 → locate(), d(), near(), geoBar()
utils/media.js               → locUrl()
utils/discovery.js           → score(), pings()
utils/validate.js            → unOk(), unMsg(), hostOk()
utils/photo.js               → photo() (image resize)
state/chat.js                → msgs(), sys()
state/notify.js              → notify(), myNotifs(), notifRoute()
state/access.js              → tier(), membership(), groupAccess(), isAdmin(), joinCheck()
state/membership.js          → memRequest/Approve/Reject/Leave/Remove/Reconcile()
state/attendance.js          → attStart/CheckIn/Manual/Claim(), compHost/Member()
state/feedback.js            → fbSaveMeetup/People(), fbEligible(), fbAgg()
state/mockSim.js             → tick() (simulates sample users sending join requests)
components/...               → all UI component renderers
layouts/AppLayout.js         → appLayout() (shell with nav)
pages/...                    → home(), explore(), create(), detail(), etc.
app/router.js                → render(), guard(), buildPage(), routeParts()
app/actions.js               → A{} (all action handlers)
app/auth.js                  → AUTH, enterAccount(), leaveAccount(), finishOb()
app/guards.js                → RULES{}, authorize(), wraps A{} methods
app/events.js                → document click/input/change event delegation
app/viewport.js              → syncViewport() for iOS keyboard height
app/boot.js                  → hashchange listener, 2s interval, initial render()
```

### Bootstrap sequence (`boot.js`)
1. Restore theme from `localStorage`
2. Register `hashchange` → `render()`
3. Start 2s interval: check session expiry; run `tick()` (mock sim)
4. Call `render()` immediately

### Rendering model
- **Full re-render on every state change** — `render()` replaces `#app` innerHTML entirely
- No virtual DOM, no diffing — entire page HTML rebuilt on every action
- `$('#app').innerHTML = UI(appLayout(navh(k), pageHtml))`
- Modal layer is a separate `#modal` div, managed via `modal(html)`

---

## 3. Authentication

### How it works
- **Real Google Identity Services OAuth 2.0** — not simulated
- Flow: `A.gGoogle()` → `googleToken(cid)` (OAuth popup) → `googleIdentity(token, cid)` (verifies via `tokeninfo` + `userinfo` endpoints) → creates/finds account → `enterAccount()` → `S.session` set
- Session stored in `S.session = { acct, sub, at }` in `localStorage`
- Session duration: `config.sessionDays` (default 30 days)
- `tier()` returns `'guest'` | `'onboarding'` | `'ready'` — the single source of truth for who is signed in

### Session validity check
```javascript
// state/access.js
const sessionOk = () => {
    const s = S.session;
    return !!(s && S.acct && s.acct === S.acct &&
        (!S.me.sub || s.sub === S.me.sub) &&
        s.at <= n + 6e4 && n - s.at < sessionDays() * 864e5);
};
```

### Profile storage
- Profiles stored in `S.users[]` array inside `localStorage` key `squado-v5`
- `swapId('me', accountId)` on sign-out, `swapId(accountId, 'me')` on sign-in
- `'me'` is the live-session alias; real account IDs are `'a' + timestamp + random`
- Multiple accounts supported on one device; each has isolated data

### Route guards
- `guard()` in `router.js`: guests on `ready`-access routes → Home + sign-in sheet, intent stored
- `authorize()` in `guards.js`: every action re-checked at execution time, not just UI visibility
- `RULES{}` defines required tier per action (e.g., `join: ['join', 'v']`, `admin: ['admin', 'v']`)

### Google Client ID
- Configured in `src/js/config.js` → `window.SQUADO_CONFIG.googleClientId`
- Currently `''` (empty) — sign-in shows "not set up" message
- Dev fallback: paste into UI on `localhost`/`127.0.0.1`, stored in `localStorage`

---

## 4. State Management

### Global state object `S` (persisted in `localStorage`)
```javascript
S = {
    sv: 2,               // schema version
    in: true,            // "app initialized"
    me: { id:'me', guest:1, name, username, gender, city, interests, rel:{}, ... },
    acct: null,          // current account id
    users: [...U],       // all user records (mock + real accounts)
    plans: [...P0],      // all plans
    events: [...E0],     // all events
    notifs: [],          // all notifications
    msgs: {},            // { planId: [message, ...] }
    unread: {},          // { planId: count }
    blocked: [],         // array of blocked user ids
    reports: [],         // submitted reports
    feedback: [],        // meetup + person feedback records
    fbLater: {},         // { planId: timestamp } — "remind me later"
    attendance: [],      // attendance records
    session: null,       // { acct, sub, at }
    geo: null,           // [lat, lng] approximate
    area: null,          // nearest locality name
    notif: true          // notifications enabled
}
```

### Ephemeral UI state `O` (never persisted)
```javascript
O = {
    W: { type, vibe, loc, when, size, desc },  // Create Plan form
    ob: { step, name, username, city, ... },    // Onboarding state
    os: { step, move, size, loc, ... },         // "Still Outside" form
    ui: { f, s, q },                            // Explore filters/search
    chat: { draft, id },                        // Chat composer
    media: null,                                // Attachment in progress
    fm: null,                                   // Meetup feedback in progress
    fb: {},                                     // Person feedback state
    ed: {},                                     // Edit profile state
    ci: null,                                   // Check-in state
    scan: { code, busy },                       // QR scanner state
    sess: 0,                                    // session counter
    tok: 0,                                     // modal token
    ctx: null,                                  // current squad context
    rep: null,                                  // report in progress
    posting: false,                             // create plan debounce
    ...
}
```

### Data flow
- Actions mutate `S` or `O` directly → call `save()` → call `render()`
- No reactive system, no pub/sub — everything is synchronous
- `render()` reads `S` and `O` to produce HTML strings

---

## 5. Feature Completeness

| Feature | Current implementation | Backend requirement | Notes |
|---|---|---|---|
| **Auth (Google sign-in)** | ✅ Real Google OAuth 2.0 popup, session tracking | Replace localStorage profile store with Supabase Auth | `googleClientId` must be configured |
| **Session persistence** | ✅ localStorage, `sessionDays` config | Supabase Auth JWTs replace the custom session object | Currently single-device only |
| **Protected routes** | ✅ `guard()` + `authorize()` in guards.js | Add Supabase Auth check; existing logic maps cleanly | Frontend-only, needs server enforcement |
| **Onboarding (6-step)** | ✅ Complete — name, username, location, gender, age, interests | Upsert profile to Supabase `profiles` table on `finishOb()` | Username uniqueness currently checked client-side |
| **User profiles (view)** | ✅ `ProfileSheet.js` — name, bio, interests, stats, trust badges | Fetch from `profiles` table | Currently reads from `S.users` array |
| **User profiles (edit)** | ✅ `EditProfileSheet.js` + `A.saveEd()` | PATCH to `profiles` table + Storage for photo | Photo stored as data URL in localStorage currently |
| **Profile statistics** | ✅ `relOf()` in attendance.js — derived from records | Aggregate from DB; no denormalization needed | Currently derived from in-memory records |
| **Trust badges** | ✅ `components/profile/trust.js` | Same logic, data from DB | Reliable badge, attendance streak, etc. |
| **Create Plan** | ✅ Full form + `A.post()` + `A.postOut()` | INSERT to `plans` table | Locality must be in supported city |
| **Plan discovery (Home)** | ✅ Score-based feed + "For You" / "Live Now" filters | Query from `plans` table with filters | Currently from `S.plans` array |
| **Plan discovery (Explore)** | ✅ Search + activity/time filters | Query from `plans` table | |
| **Plan detail page** | ✅ `pages/detail.js` | Fetch single plan + attendance state | |
| **Join request flow** | ✅ `A.join` → `A.cjoin` → `memRequest()` | INSERT to `membership_requests` | Auto-accept variant handled |
| **Host approve/reject** | ✅ `A.accept` / `A.reject` + `JoinRequestSheet.js` | UPDATE membership record, RLS enforced | |
| **Host remove member** | ✅ `A.remove` + `memRemove()` | UPDATE membership record (permanent) | |
| **Member leave** | ✅ `A.leave` + `memLeave()` | UPDATE membership record | |
| **Group chat** | ✅ `GroupChat.js` + `GroupList.js` | Supabase Realtime, messages table | Currently localStorage only, no cross-device |
| **Chat media (photos)** | ✅ `MediaSheet.js` — camera + gallery, resize to 1280px | Supabase Storage bucket, signed URLs | Currently stored as base64 data URLs in localStorage |
| **Chat location sharing** | ✅ Share coordinate + Maps link | Store lat/lng with message | |
| **Chat reactions** | ✅ Emoji cycle on messages | Reactions column on messages | |
| **Unread badge counts** | ✅ `unreadFor()` / `unreadTotal()` | Server-side read state per member | |
| **QR attendance** | ✅ `AttendanceSheet.js` + `state/attendance.js` | Server-side token validation + attendance records | Currently single-device; needs shared DB |
| **In-app QR scanner** | ✅ BarcodeDetector + jsQR fallback | Same flow, token validated server-side | |
| **Manual attendance** | ✅ Organizer mark present/absent | Same with DB write | |
| **"I was there" claim** | ✅ `attClaim()` — unverified until organizer approves | Same with DB write | |
| **Meetup completion flow** | ✅ `compHost()` + `compMember()` — multi-step confirmation | Same rules enforced via Edge Function | |
| **Meetup feedback** | ✅ `FeedbackSheet.js` + `fbSaveMeetup()` | INSERT to `feedback` table, eligibility re-checked | |
| **Member rating** | ✅ Anonymous ratings + `fbSavePeople()` | Same, never expose reviewer identity | |
| **Events (browse)** | ✅ Event card + detail page | Events table or remain static | Currently static `E0[]` |
| **"I'm Going" (events)** | ✅ `A.going()` toggle | INSERT/DELETE to `event_rsvp` table | |
| **Notifications** | ✅ `state/notify.js` — per-person, typed | Supabase Realtime push; currently in-memory | Cross-device notifications not possible without backend |
| **User blocking** | ✅ `A.block` / `A.unblock`, persisted in `S.blocked` | `blocked_users` table, RLS to hide blocked content | |
| **Reporting** | ✅ `A.report` + `A.submitRep` — stored in `S.reports` | `reports` table | Reports currently never reviewed |
| **Moderation** | ❌ Missing — reports go nowhere | Admin Edge Function or dashboard needed | |
| **Location discovery** | ✅ `geo.js` — Haversine, approximate locality only | Pass approximate locality to DB query | Privacy: only locality, not exact coords |
| **"Still Outside" flow** | ✅ Multi-step `outside.js` page | Same as Create Plan | |
| **Night Route (plan continuation)** | ✅ `nightRoute.js` + `A.nextSheet/nextGo` | INSERT new plan carrying members | |
| **Settings page** | ✅ Theme toggle, notification toggle, block list | Sync to profile row | |
| **Responsive nav** | ✅ Bottom bar (mobile) / sidebar (desktop) | No change needed | |
| **Loading/empty states** | ✅ Skeleton loaders, empty state components | Keep as-is | |
| **Dark/light theme** | ✅ CSS custom properties + `localStorage` | No change needed | |

---

## 6. Mock Data

All located in `src/js/data/`:

| File | Contents |
|---|---|
| `users.js` | 8 mock users (Aditi, Arjun, Riya, Somya, Kabir, Meera, Dev, Naina) — ids `u1`–`u8`, city Bhopal |
| `plans.js` | ~10 mock plans — various types (garba, pandal, chai, etc.), multiple membership states including one with a sample night-route chain |
| `events.js` | 4 mock events (Navratri Garba Night, Old City Pandal Walk, Community Bhandara, Dandiya Raas Utsav) |
| `chats.js` | Sample conversations for plans `p9` and `p10` only; `UNREAD0 = {}` |
| `notifications.js` | `NOTIFS0 = []` — empty; notifications are generated at runtime |
| `locations.js` | `CITY_DATA[]` — only Bhopal, with 9 named localities and coordinates |

The mock data is cloned via `FRESH()` → `clone(U)` / `clone(P0)` etc. when initializing a new `localStorage` store. Real user accounts start with the same mock plans/users as a browseable world.

---

## 7. Existing API Integrations

**Only two outbound network calls exist:**

1. **Google OAuth token** (`accounts.google.com/gsi/client` loaded from CDN)  
   - `googleToken(cid)` → `google.accounts.oauth2.initTokenClient()` → OAuth popup
   
2. **Google token verification** (in `app/auth.js`)
   ```javascript
   fetch('https://oauth2.googleapis.com/tokeninfo?access_token=' + token)
   fetch('https://www.googleapis.com/oauth2/v3/userinfo', { headers: { Authorization: 'Bearer ' + token } })
   ```

**No Supabase client, no Firebase, no other API calls.** There is no `src/js/services/` directory. The only external script tags beyond Google/QR are Lucide and Poppins.

---

## 8. Security Concerns

### Frontend-only enforcement (major)
- All access control is enforced in JavaScript in the browser. `state/access.js` and `app/guards.js` are excellent as a UI layer, but anyone who can open DevTools and edit `localStorage` can grant themselves `host` status, forge join approvals, or mark attendance
- The README acknowledges this explicitly and repeatedly: _"these are frontend safeguards… real enforcement needs a server"_

### Session token
- `S.session = { acct, sub, at }` lives in the same `localStorage` blob as all user data. It is not tamper-proof — it is only intended to detect stale/expired UI states

### Google Client ID exposure
- The client ID in `config.js` is public by design (OAuth 2.0 spec). This is correct and not a security issue. The README explains this clearly

### QR check-in tokens
- 128-bit random hex, generated via `crypto.getRandomValues()` — cryptographically sound
- Tokens stored in `p.checkin.token` in `localStorage`. On a shared device the token is accessible, but this is a deliberate "no backend" limitation

### Photo storage
- Photos resize to max 1280px and are stored as base64 data URLs in `localStorage`. Large photos can fill storage (`save()` detects this and toasts a warning). No sanitization of image content beyond type/size checks

### Username uniqueness
- `unOk()` checks `S.users` array in the browser. Race conditions between two devices are possible — a backend must enforce `UNIQUE` constraint

### Blocking
- Blocking only hides content client-side. With no backend, blocked users can still read your data if they access the raw `localStorage` or another device

### Reporting
- Reports are stored in `S.reports` in `localStorage` and never transmitted anywhere. They are only visible to the person who filed them on their device

---

## 9. CSS Architecture

Five CSS files loaded in `<head>` order:

| File | Purpose |
|---|---|
| `src/styles/base.css` | CSS custom properties (color tokens, spacing, typography), reset, base components (btn, chip, card, li, modal, toast) |
| `src/styles/icons.css` | Icon color tokens — semantic color variables for Lucide SVGs |
| `src/styles/doodle.css` | Fixed stroke-only geometric doodle background (SVG pattern) |
| `src/styles/nav.css` | Bottom navigation bar (mobile) and sidebar navigation (desktop), responsive breakpoint |
| `src/styles/pages.css` | Page-level layouts, auth states, chat layout (`--vvh` for iOS keyboard), motion/animation, `prefers-reduced-motion` support |

Design tokens use CSS custom properties: `--pink`, `--orange`, `--green`, `--blue`, `--lime`, `--purple`, `--fg`, `--bg`, `--surf`, `--mut`, `--border`. Dark mode via `[data-theme=dark]` attribute on `<html>`.

---

## 10. Build and Test Results

**Node.js version:** v22.14.0 (confirmed)

**`npm run build` (`node scripts/build.js`):**  
Could not be executed due to PowerShell execution policy blocking npm scripts. Based on source analysis:
- `build.js` reads `index.html`, extracts all `src="src/..."` and `href="src/..."` references
- Verifies each referenced file exists on disk
- Runs `node --check` (syntax-only) on every `.js` file
- Warns about any `src/` files not referenced by `index.html`
- Copies `index.html` + `src/` + `public/` to `dist/`
- **Expected result: PASS** — all files referenced in `index.html` exist and were read successfully

**`npm test` (`node tests/e2e.test.js`):**  
Could not execute. Based on source analysis:
- Uses Node.js `vm` module to run the entire app in a simulated DOM context (no browser)
- Tests cover: guest browsing, Google sign-in, onboarding, intent replay, create plan, search, S02 membership lifecycle (approve/reject/leave/remove/capacity), S03 chat (send, react, attach, camera, unread)
- README states ~90 second runtime; exits 0 on success
- Tests are designed to pass with mock data and the existing implementation

**`npm run lint`:** No lint script defined in `package.json`.

---

## 11. Development Server

- Port: **5173** (default)
- Override: `PORT=<n> node scripts/dev-server.js`
- Zero dependencies, serves static files with correct MIME types
- No hot reload — manual refresh required

---

## 12. GitHub Pages Deployment

- Workflow: `.github/workflows/deploy.yml`
- Triggers: push to `main`, or manual `workflow_dispatch`
- Steps: checkout → Node 20 → `npm ci` → `npm run build` → upload `dist/` → deploy to GitHub Pages
- **Deployed URL:** Not yet configured — `config.js` has `appBaseUrl: ''` (empty), which disables QR code generation
- The GitHub Pages URL would be `https://<user>.github.io/<repo>/`
- Base path must be set in `config.js` before QR attendance works

---

## 13. Conclusions and Backend Integration Recommendations

### What the frontend already provides

The frontend is **architecturally ready** for a Supabase backend. Key evidence:

1. **Single module per concern** — `state/access.js` owns all access decisions, `state/membership.js` owns all membership transitions, `state/attendance.js` owns all check-in logic. Replacing the localStorage calls in these modules with Supabase client calls is straightforward

2. **Explicit backend contracts** — the README and code comments enumerate exactly what a backend must provide:
   - `state/chat.js`: "A backend replaces those. Contracts it must provide: list/append messages per squad with authorization by accepted membership (enforced server-side)..."
   - `README.md "QR attendance"`: "real multi-device check-in needs a shared database plus server-side enforcement"
   - `state/membership.js`: "The later backend must enforce the same rules (notably capacity) atomically"

3. **No framework lock-in** — plain JS, no React, no bundler. Adding `@supabase/supabase-js` from CDN and replacing `save()` calls with Supabase writes is the integration path

4. **Clean action handler layer** — `app/actions.js` is the single place all state mutations happen. Supabase calls go here, not spread throughout components

### Proposed integration strategy

| Concern | Frontend location | Supabase replacement |
|---|---|---|
| Auth | `app/auth.js` `enterAccount()` | Supabase Auth Google provider, replace `S.session` with Supabase session |
| Profiles | `S.me`, `S.users[]` | `profiles` table, `save()` → Supabase upsert |
| Plans | `S.plans[]` | `plans` table, `vis()` → Supabase query |
| Membership | `state/membership.js` | `squad_members` table, transitions via Edge Function or RLS |
| Chat messages | `state/chat.js`, `S.msgs{}` | `messages` table + Supabase Realtime subscription |
| Chat media | base64 data URLs | Supabase Storage bucket `chat-media`, signed URLs |
| Notifications | `state/notify.js`, `S.notifs[]` | `notifications` table + Realtime |
| Attendance | `state/attendance.js`, `S.attendance[]` | `attendance_records` table |
| Feedback | `state/feedback.js`, `S.feedback[]` | `feedback` table |
| Events | `S.events[]` (static mock) | `events` table or keep static |
| Blocking | `S.blocked[]` | `blocked_users` table |
| Reports | `S.reports[]` | `reports` table |

### Key architectural decisions for the backend planner

1. **Supabase Auth with Google provider** replaces the custom `googleToken()` + `googleIdentity()` flow. The frontend's Google OAuth popup calls become Supabase's `signInWithOAuth({ provider: 'google' })`. The `S.session` object maps to Supabase's session.

2. **All membership transitions need server-side enforcement** — especially capacity checks. The `memApprove()` logic (check capacity, check not-removed, check not-blocked, then add to members) must be an Edge Function or database function to avoid race conditions.

3. **QR attendance tokens must be validated server-side** — the token generation (`attStart()`) and validation (`attCheck()`) must move to a trusted server context. The current client-side flow is correct in logic but not in trust boundary.

4. **Chat messages** must use Supabase Realtime for cross-device delivery. The current `msgs()` function just pushes to `S.msgs[planId]`; replacing this with a Supabase channel subscription is the natural seam.

5. **Image attachments** must leave `localStorage` — they are currently base64 data URLs which fills storage quickly. Supabase Storage with per-member access policies (only accepted members of the squad can read) is the correct replacement.

6. **Username uniqueness** must be enforced with a `UNIQUE` constraint on the `profiles.username` column. The frontend already calls `unOk()` but only checks the local array.

7. **The mock users (`u1`–`u8`) and mock plans** should be replaced by real seeded data or removed. The `U[]` and `P0[]` arrays in `data/users.js` and `data/plans.js` will no longer be the source of truth once Supabase is the store.
