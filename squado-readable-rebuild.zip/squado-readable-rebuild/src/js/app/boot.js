try {
    const th = localStorage.getItem('squado-theme');
    if (th)
        document.documentElement.dataset.theme = th;
}
catch (e) { }
addEventListener('hashchange', () => { modal(''); render(); });
setInterval(() => {
    if (S.me && !S.me.guest && checkSession()) {
        render();
        return;
    }
    if (S.in && S.me)
        tick();
}, 2000);
render();
