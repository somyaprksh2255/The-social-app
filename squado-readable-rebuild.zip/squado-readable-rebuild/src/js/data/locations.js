/* Single source of truth for supported cities, their localities and coordinates.
   Only cities whose localities and coordinates are listed here are offered anywhere in the UI.
   To add a city later, add one entry: dropdowns, filters, distance and validation all read from this list. */
const CITY_DATA = [
    {
        id: 'bhopal',
        name: 'Bhopal',
        state: 'Madhya Pradesh',
        center: [23.2599, 77.4126],
        radiusKm: 40,
        localities: {
            'Near DB Mall': [23.2335, 77.433],
            'MP Nagar': [23.235, 77.434],
            'Old City': [23.2599, 77.401],
            'Near Jehan Numa': [23.209, 77.429],
            'Bittan Market': [23.216, 77.435],
            '10 No. Market': [23.237, 77.429],
            'Shahpura Lake': [23.198, 77.435],
            'New Market': [23.233, 77.401],
            'Arera Colony': [23.215, 77.434]
        }
    }
];

const CITIES = CITY_DATA.map(c => c.name);

const cityByName = n => CITY_DATA.find(c => c.name == n) || null;

const isCity = n => !!cityByName(n);

const cityLabel = n => {
    const c = cityByName(n);

    return c ? `${c.name}, ${c.state}` : n || '';
};

const localitiesOf = n => {
    const c = cityByName(n);

    return c ? Object.keys(c.localities) : [];
};

/* the supported city a locality name belongs to, or null (unknown / legacy values) */
const cityOfLoc = l => {
    const c = CITY_DATA.find(x => l in x.localities);

    return c ? c.name : null;
};

/* locality name -> [lat, lng], across all supported cities */
const LC = Object.assign({}, ...CITY_DATA.map(c => c.localities));
