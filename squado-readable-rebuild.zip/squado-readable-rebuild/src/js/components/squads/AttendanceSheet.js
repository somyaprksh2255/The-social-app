/* Attendance UI: organizer panel, QR sheet, check-in page (opened by a phone camera link), in-app scanner. Logic lives in state/attendance.js. */

const ATT_MSG = {
    checked_in: ['You\'re checked in ✅', 'Your attendance is recorded. Thanks for coming!'],
    duplicate: ['Already checked in', 'You were already checked in for this meetup. Nothing was added twice.'],
    disputed: ['Sent to the host', 'The host marked you as not attending, so this was recorded as a dispute for them to resolve.'],
    auth: ['Sign in to check in', 'Check-in is tied to your Squado account.'],
    noplan: ['Meetup not found', 'This meetup isn\'t available in this browser. Squado keeps data on each device for now, so check-in only works where the meetup was created (see README, QR attendance).'],
    cancelled: ['This meetup was cancelled', 'There\'s nothing to check in to.'],
    ended: ['This meetup is already wrapped up', 'Check-in is closed. If you were there, ask the host to mark you present.'],
    nosession: ['Check-in isn\'t open', 'The host hasn\'t started check-in for this meetup.'],
    invalid: ['That code isn\'t valid', 'This QR code doesn\'t match an open check-in. Ask the host to show it again.'],
    revoked: ['That code was replaced', 'The host created a newer code. Scan the latest one.'],
    closed: ['Check-in is closed', 'The host closed check-in. If you were there, use "I was there" or ask the host to mark you present.'],
    expired: ['That code has expired', 'Ask the host for a new code.'],
    notmember: ['You\'re not in this squad', 'Only accepted squad members can check in. Ask to join first.'],
    method: ['Couldn\'t check in', 'Unknown check-in method.'],
    save: ['Couldn\'t save your check-in', 'Your device storage didn\'t accept it. Nothing was recorded. Try again.']
};

const attMsg = c => ATT_MSG[c] || ATT_MSG.invalid;

const ATT_STATUS = a =>
    !a ? '⏳ Not checked in yet'
        : a.dispute ? '⚠️ Disputed'
            : a.status == 'present' ? '✅ Checked in'
                : a.status == 'claimed' ? '🙋 Says they attended'
                    : '🚫 Marked absent';

/* why feedback is still locked, for a member of the plan (null when it is open to them) */
function fbLockReason(p) {
    if (!p || !p.members.includes('me') || S.me.guest)
        return null;

    if (p.status == 'cancelled')
        return 'This plan was cancelled, so there\'s no feedback.';

    const a = attGet(p, 'me');

    if (p.status != 'ended') {
        const l = lifeState(p);

        return l == 'disputed' ? 'Feedback is locked: the meetup\'s completion is disputed.'
            : l == 'completion_pending' ? 'Feedback opens once the meetup is confirmed completed (waiting for confirmations).'
                : 'Feedback opens after the host confirms the meetup ended, for people whose attendance was verified.';
    }

    if (fbEligible(p))
        return null;

    return !a ? 'Feedback is for people whose attendance was verified. Scan the meetup QR code, or ask the host to mark you present.'
        : a.dispute ? 'Your attendance is disputed, so feedback stays locked until the host resolves it.'
            : a.status == 'claimed' ? 'Waiting for the host to verify that you attended. Feedback stays locked until then.'
                : a.status == 'absent' ? 'The host marked you as not attending. If that\'s wrong, tap "I was there".'
                    : 'Feedback isn\'t open for this plan.';
}

/* attendance + completion block of the plan page (host: manage; member: own status only, other people's attendance stays private) */
function attPanel(p) {
    if (p.status == 'cancelled' || S.me.guest || !p.members.includes('me'))
        return '';

    const host = isHost(p);
    const l = lifeState(p);
    const open = p.status == 'open';
    const ss = attSessionState(p);
    const a = attGet(p, 'me');
    let h = '';

    if (host) {
        const nPresent = attCount(p);

        h += `<div class="card" style="margin:14px 0 0">
            <b>Attendance</b>
            <p class="mut" style="margin:4px 0 8px">
                ${open
                    ? ss == 'open'
                        ? 'Check-in is open. Members scan your QR code with their phone camera or inside Squado.'
                        : ss == 'none' ? 'Start check-in to show a QR code. QR check-ins and manual marks use the same records.'
                            : ss == 'closed' ? 'Check-in is closed.' : 'The check-in code expired.'
                    : 'This meetup is wrapped up. You can still correct attendance below.'}
            </p>
            <p style="margin:0 0 8px"><b>${nPresent} of ${p.members.length}</b> checked in or marked present</p>`;

        if (open)
            h += `<div class="row">
                ${ss == 'open'
                    ? `<button class="btn pink sm" data-a="attQr" data-v="${p.id}">Show QR code</button>
                        <button class="btn ghost sm" data-a="attClose" data-v="${p.id}">Close check-in</button>
                        <button class="btn ghost sm" data-a="attStart" data-v="${p.id}">New code</button>`
                    : `<button class="btn pink sm" data-a="attStart" data-v="${p.id}">${ss == 'none' ? 'Start check-in' : 'Reopen with a new code'}</button>`}
            </div>`;

        h += p.members.map(m => {
            const r = attGet(p, m);

            return `<div class="li" style="margin-top:8px">
                ${av(m, 36)}
                <div style="flex:1;min-width:120px">
                    <b>${esc(usr(m).name)}${m == p.creator ? ' 👑' : ''}</b><br>
                    <span class="mut" style="font-size:.85rem">${ATT_STATUS(r)}${r && r.method ? ' · ' + esc(({ native_camera: 'phone camera', in_app_scanner: 'in-app scanner', manual: 'marked by you', organizer: 'organizer' })[r.method] || '') : ''}</span>
                </div>
                ${m == p.creator || p.status == 'cancelled' ? '' : `
                    ${r && r.status == 'present' && !r.dispute ? '' : `<button class="btn ghost sm" data-a="attMark" data-k="${p.id}|${m}|present">Present</button>`}
                    ${r && r.status == 'absent' && !r.dispute ? '' : `<button class="btn ghost sm" data-a="attMark" data-k="${p.id}|${m}|absent">Absent</button>`}`}
            </div>`;
        }).join('');

        h += '<p class="mut" style="margin:8px 0 0;font-size:.8rem">"Not checked in yet" is not "absent": it just means no record. Only you can mark someone absent or present by hand.</p></div>';
    }
    else {
        h += `<div class="card" style="margin:14px 0 0">
            <b>Your attendance</b>
            <p style="margin:6px 0">${ATT_STATUS(a)}</p>`;

        if (open && !(a && attPresent(p, 'me')))
            h += `<div class="row">
                <button class="btn pink sm" data-a="scanOpen" data-v="${p.id}">Scan QR to check in</button>
                ${!a || (a.status == 'absent' && !a.dispute) ? `<button class="btn ghost sm" data-a="attClaim" data-v="${p.id}">I was there${a ? '' : ', but couldn\'t scan'}</button>` : ''}
            </div>`;

        h += '</div>';
    }

    /* completion: separate from attendance */
    if (open) {
        h += `<div class="card" style="margin:10px 0 0">
            <b>Meetup status: ${({ scheduled: 'Scheduled', awaiting_completion: 'Awaiting completion', completion_pending: 'Waiting for confirmations', disputed: 'Disputed' })[l] || l}</b>`;

        if (host) {
            if (!p.completion)
                h += `<p class="mut" style="margin:6px 0 8px">Confirm only once the meetup really happened and ended. Checking people in does not complete it.</p>
                    <button class="btn sm" data-a="end" data-v="${p.id}">Confirm it ended</button>`;
            else
                h += `<p class="mut" style="margin:6px 0 0">${l == 'disputed'
                    ? 'A verified attendee disputes this. It stays open until they withdraw it or you mark their attendance.'
                    : `Waiting for ${compNeed(p) - compHave(p)} of ${compNeed(p)} attendee confirmation(s). No reply counts as unverified, not as absent.`}</p>`;
        }
        else if (p.completion) {
            const me = p.completion;
            const mine = me.confirms.includes('me');
            const disp = me.disputes.some(d => d.u == 'me');

            h += `<p class="mut" style="margin:6px 0 8px">The host says this meetup happened and ended.</p>`;

            if (a && ['present', 'claimed'].includes(a.status))
                h += `<div class="row">
                    ${mine || disp ? '' : `<button class="btn pink sm" data-a="compOk" data-v="${p.id}" ${attPresent(p, 'me') ? '' : 'disabled'}>Yes, it happened</button>
                        <button class="btn ghost sm" data-a="compNo" data-v="${p.id}">That's not right</button>`}
                    ${mine ? '<span class="mut">You confirmed ✅</span>' : ''}
                    ${disp ? `<span class="mut">You disputed this</span> <button class="btn ghost sm" data-a="compUndo" data-v="${p.id}">Withdraw</button>` : ''}
                </div>`;
        }
        else
            h += '<p class="mut" style="margin:6px 0 0">The host confirms when the meetup has ended.</p>';

        h += '</div>';
    }

    return h;
}

/* ---- QR sheet (organizer) ---- */

const ATT_QR_ERR = {
    nobase: 'No deployed address is configured, so no QR code is made. Set appBaseUrl in src/js/config.js to your real https address (see README, QR attendance). Localhost addresses are never used for QR codes.',
    badbase: 'appBaseUrl in src/js/config.js must be the public https address of the deployed app (not localhost or a private address).',
    nosession: 'Start check-in first.'
};

function qrSheet(p) {
    const u = attUrl(p);
    let body;

    if (u.err)
        body = `<p role="alert" style="color:var(--ic-red)"><b>${esc(ATT_QR_ERR[u.err])}</b></p>`;
    else {
        let svg = '';

        try {
            const q = qrcode(0, 'M');

            q.addData(u.url);
            q.make();
            svg = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
        }
        catch (e) { }

        body = `${svg
            ? `<div role="img" aria-label="Check-in QR code for ${esc(p.title)}" style="background:#fff;padding:10px;border-radius:16px;max-width:300px;margin:10px auto">${svg}</div>`
            : '<p class="mut">The QR image library didn\'t load (needs an internet connection). Share this link instead:</p>'}
            <input type="text" readonly value="${esc(u.url)}" aria-label="Check-in link" onclick="this.select()">
            <p class="mut" style="font-size:.85rem">Valid until ${esc(new Date(p.checkin.expiresAt).toLocaleString())}, or until you close check-in or make a new code. It holds only the meetup and a random code, nothing personal.</p>`;
    }

    return `<h2 style="margin-top:0">Check-in QR code</h2>
        <p class="mut">Members scan with their phone's camera. It opens Squado in their browser, and they tap <b>Check me in</b>.</p>
        ${body}
        <p style="text-align:center"><button class="btn ghost sm" data-a="close">Done</button></p>`;
}

/* ---- check-in page: what a scanned link opens ---- */

function checkinPage(id, token) {
    const p = pl(id);
    const back = '<a class="back" href="#/home">← Home</a>';
    const done = O.ci && O.ci.id == id && O.ci.res;
    let body;

    if (done) {
        const m = attMsg(O.ci.res);
        const ok = ['checked_in', 'duplicate', 'disputed'].includes(O.ci.res);

        body = `<span class="okc ${ok ? '' : 'bad'}">${I(ok ? 'check' : 'x', '26px')}</span>
            <h2>${m[0]}</h2><p class="mut">${m[1]}</p>
            ${p ? `<a class="btn pink wide" href="#/plan/${esc(p.id)}">Open the meetup</a>` : ''}`;
    }
    else if (S.me.guest) {
        body = `<h2>${p ? 'Check in to ' + esc(p.title) : 'Check in'}</h2>
            <p class="mut">Sign in to check in. You'll come straight back here.</p>
            <button class="btn pink wide" data-a="checkinSignIn">Sign in to check in</button>`;
    }
    else {
        const c = attCheck(p, token);

        if (c != 'ok') {
            const m = attMsg(c);

            body = `<span class="okc bad">${I('x', '26px')}</span><h2>${m[0]}</h2><p class="mut">${m[1]}</p>
                ${p && c == 'notmember' ? `<a class="btn pink wide" href="#/plan/${esc(p.id)}">View the plan</a>` : ''}`;
        }
        else
            body = `<h2>Check in to ${esc(p.title)}?</h2>
                <p class="mut">Opening this link doesn't count as attendance. Tap below to confirm you're here.</p>
                <button class="btn pink wide ${O.scan.busy ? 'loading' : ''}" data-a="checkinGo" data-k="${esc(p.id)}|${esc(token)}" ${O.scan.busy ? 'disabled' : ''}>Check me in</button>`;
    }

    return `<main class="wrap" style="max-width:520px">${back}<div class="authst" style="margin-top:16px">${body}</div></main>`;
}

/* ---- in-app scanner ---- */

/* pull plan id + token out of a scanned/pasted link: only our own '#/checkin/<plan>/<32 hex>' shape is accepted */
function attParse(text) {
    const m = /#\/checkin\/([\w.~%-]+)\/([0-9a-f]{32})\s*$/i.exec(String(text || '').trim());

    return m ? { id: decodeURIComponent(m[1]), token: m[2].toLowerCase() } : null;
}

const SCAN_ERR = {
    unsupported: 'This browser can\'t open the camera here. Use your phone\'s camera app to scan the QR code (it opens Squado), or paste the link below.',
    denied: 'Camera permission was denied. Allow it in your browser settings, or scan with your phone\'s camera app, or paste the link below.',
    nocam: 'No camera was found on this device. Paste the check-in link below instead.',
    camfail: 'The camera couldn\'t start. Paste the check-in link below instead.',
    nodecoder: 'This browser has no QR reader available right now (it needs an internet connection for one small library). Paste the link below instead.'
};

const scanSheet = (note, err) => `<h2 style="margin-top:0">Scan to check in</h2>
    <p class="mut">${note || 'Point the camera at the meetup\'s QR code.'}</p>
    ${err ? `<p role="alert" style="color:var(--ic-red)"><b>${esc(err)}</b></p>` : '<video id="scanv" playsinline muted style="width:100%;max-height:320px;border-radius:16px;background:#000"></video>'}
    <p class="mut" style="margin:12px 0 4px;font-size:.85rem">No camera? Paste the check-in link:</p>
    <input type="text" data-in="scan.code" value="${esc(O.scan.code)}" placeholder="https://…/#/checkin/…" aria-label="Check-in link" autocomplete="off">
    <div class="row" style="margin-top:8px">
        <button class="btn pink sm" data-a="scanManual">Use link</button>
        <button class="btn ghost sm" data-a="close">Close</button>
    </div>`;

const scanResult = c => {
    const m = attMsg(c);
    const ok = ['checked_in', 'duplicate', 'disputed'].includes(c);

    return `<div class="authst"><span class="okc ${ok ? '' : 'bad'}">${I(ok ? 'check' : 'x', '26px')}</span><h2>${m[0]}</h2><p class="mut">${m[1]}</p></div>
        ${ok ? '' : '<button class="btn pink wide" data-a="scanOpen">Scan again</button>'}
        <p style="text-align:center"><button class="btn ghost sm" data-a="close">Close</button></p>`;
};

/* both the scanner and the pasted-link / camera-app route end in the same attCheckIn() */
function scanHandle(text) {
    if (O.scan.busy)
        return;

    const x = attParse(text);

    if (!x) {
        modal(scanSheet('', ''));
        return modal(scanResult('invalid'));
    }

    O.scan.busy = true;

    try {
        const c = attCheckIn(x.id, x.token, 'in_app_scanner');

        modal(scanResult(c));
        render();
    }
    finally {
        O.scan.busy = false;
    }
}

const attActions = {
    attStart(e) {
        const p = pl(e.dataset.v);
        const r = attStart(p);

        if (r != 'ok')
            return toast(({ forbidden: 'Only the host can do that.', state: 'Check-in is only for open plans.', nocrypto: 'This browser can\'t make a secure code.', save: 'Couldn\'t save. Try again.' })[r] || 'Couldn\'t start check-in.');

        render();
        modal(qrSheet(p));
    },
    attQr(e) {
        const p = pl(e.dataset.v);

        if (isHost(p) && p.checkin)
            modal(qrSheet(p));
    },
    attClose(e) {
        const r = attClose(pl(e.dataset.v));

        toast(r == 'ok' ? 'Check-in closed' : 'Couldn\'t close check-in');
        render();
    },
    attMark(e) {
        const [id, uid, st] = String(e.dataset.k).split('|');
        const r = attManual(pl(id), uid, st, st == 'present' ? 'Verified by the organizer' : 'Marked as not attending');

        toast(({ ok: st == 'present' ? 'Marked present' : 'Marked absent', unchanged: 'Already set', forbidden: 'Only the host can do that.', save: 'Couldn\'t save. Try again.' })[r] || 'Couldn\'t update');
        render();
    },
    attClaim(e) {
        const r = attClaim(pl(e.dataset.v));

        toast(({ ok: 'Sent. The host will verify it.', duplicate: 'Already sent', notmember: 'You\'re not in this squad', save: 'Couldn\'t save. Try again.' })[r] || 'Couldn\'t send');
        render();
    },
    compOk(e) { attCompAct(e, 'confirm'); },
    compNo(e) { attCompAct(e, 'dispute'); },
    compUndo(e) { attCompAct(e, 'withdraw'); },
    checkinSignIn() {
        requireAuth({ hash: location.hash }, () => render(), 'Sign in to check in');
    },
    checkinGo(e) {
        if (O.scan.busy)
            return;

        const [id, token] = String(e.dataset.k).split('|');

        O.scan.busy = true;
        render();

        /* link / phone-camera route: method native_camera; same attCheckIn() as the in-app scanner */
        const c = attCheckIn(id, token, 'native_camera');

        O.scan.busy = false;
        O.ci = { id, res: c };
        render();
    },
    async scanOpen() {
        O.scan.code = '';
        modal(scanSheet('Starting the camera…'));

        const tok = O.tok;
        const nav = typeof navigator != 'undefined' ? navigator : null;

        if (!nav || !nav.mediaDevices || !nav.mediaDevices.getUserMedia)
            return modal(scanSheet('', SCAN_ERR.unsupported));

        const hasDetector = typeof BarcodeDetector != 'undefined';

        if (!hasDetector && typeof jsQR == 'undefined')
            return modal(scanSheet('', SCAN_ERR.nodecoder));

        let stream;

        try {
            stream = await nav.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
        }
        catch (x) {
            const n = x && x.name;

            return O.tok == tok && modal(scanSheet('', SCAN_ERR[n == 'NotAllowedError' || n == 'SecurityError' ? 'denied' : n == 'NotFoundError' || n == 'OverconstrainedError' ? 'nocam' : 'camfail']));
        }

        /* the sheet was closed while the permission prompt was open: release the camera right away */
        if (O.tok != tok) {
            stream.getTracks().forEach(t => t.stop());
            return;
        }

        const m = $('#modal');
        const v = m.querySelector('#scanv');

        m._cameraStream = stream;   /* modal() stops it on every close / sheet change */

        if (!v)
            return;

        v.srcObject = stream;

        try {
            await v.play();
        }
        catch (x) { }

        const det = hasDetector ? new BarcodeDetector({ formats: ['qr_code'] }) : null;
        const cv = document.createElement('canvas');

        const tick = async () => {
            if (O.tok != tok)
                return;

            let text = '';

            try {
                if (det) {
                    const r = await det.detect(v);

                    text = r && r[0] ? r[0].rawValue : '';
                }
                else if (v.videoWidth) {
                    cv.width = v.videoWidth;
                    cv.height = v.videoHeight;

                    const cx = cv.getContext('2d');

                    cx.drawImage(v, 0, 0);

                    const d = cx.getImageData(0, 0, cv.width, cv.height);
                    const r = jsQR(d.data, d.width, d.height);

                    text = r ? r.data : '';
                }
            }
            catch (x) { }

            if (O.tok != tok)
                return;

            if (text)
                return scanHandle(text);

            setTimeout(tick, 250);
        };

        tick();
    },
    scanManual() {
        scanHandle(O.scan.code);
    }
};

function attCompAct(e, act) {
    const p = pl(e.dataset.v);
    const r = compMember(p, act);

    if (['forbidden', 'state', 'auth', 'save'].includes(r))
        return toast(r == 'save' ? 'Couldn\'t save. Try again.' : 'That isn\'t available right now.');

    if (r == 'completed')
        attFinish(p);
    else
        toast(r == 'disputed' ? 'Noted. The meetup stays open until this is resolved.' : act == 'confirm' ? 'Thanks for confirming' : 'Updated');

    render();
}

/* once a plan is completed: tell verified attendees feedback is open (once per person and plan) */
function attFinish(p) {
    p.members.filter(m => m != 'me' && attPresent(p, m)).forEach(m => {
        if (!S.notifs.some(n => n.to == m && n.planId == p.id && n.key == 'fb'))
            notify(m, { type: 'plan', ic: 'star', c: 'gold', t: `How was ${p.title}?`, b: 'Share quick, anonymous feedback', planId: p.id, userId: 'me', key: 'fb' });
    });

    if (!(p.sysDone))
        sys(p.id, 'Plan wrapped ✅');

    p.sysDone = 1;
    save();
    toast('Meetup confirmed completed 🎉');
}

/* once the organizer confirms: ask verified attendees to confirm (once per person and plan) */
function attAskConfirm(p) {
    compVerifiers(p).forEach(m => {
        if (!S.notifs.some(n => n.to == m && n.planId == p.id && n.key == 'comp'))
            notify(m, { type: 'plan', ic: 'check', c: 'gold', t: `Did ${p.title} happen?`, b: 'The host says it ended. Please confirm.', planId: p.id, userId: 'me', key: 'comp' });
    });

    save();
}
