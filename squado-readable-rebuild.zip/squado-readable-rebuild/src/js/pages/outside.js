function outside() {
    const o = O.os;
    const s = o.step;

    /* "Nearby" discovery radius for Still Outside (km). Matches the existing
       "Already happening nearby" behaviour in step 4 so both use one value.
       The user's position is still kept to a rough ~1 km area for privacy. */
    const NEARBY_KM = 8;

    const M = [
        '☕ Chai',
        '🍕 Food',
        '💃 Garba',
        '🪔 Pandal Hopping',
        '📸 Photos',
        '🚶 Walk',
        '🧭 Explore',
        '✨ Custom'
    ];

    const os = c => c.replace(
        /data-a="set"/g,
        'data-a="osset"'
    );

    /* Find People mode: spontaneous plans that are live now AND nearby,
       shown inside the Still Outside flow using the existing plan card + join flow.
       Reuses vis() (open, visible, in-city plans), d() (approx distance), and card().

       Radius note: the privacy model already rounds the user's position to a rough
       ~1 km area (see geoBar / locate()), so coordinates are never exact. The nearby
       *discovery* radius here matches the app's existing "Already happening nearby"
       convention used below in step 4 (NEARBY_KM) so that genuinely live plans in the
       user's area actually surface. A 1 km discovery radius was too tight for the
       locality geography (localities sit 2–8 km apart), which made live plans fail to
       render from most areas even though they exist. */
    if (o.find) {
        /* Reference point for "nearby": the user's rough GPS area if location is on,
           otherwise the area they picked manually from the chips (LC[o.loc]).
           Supporting both means manual area selection works even without GPS, which
           is the documented fallback. Coordinates are never shown on public cards. */
        const ref = geoOn()
            ? S.geo
            : (o.loc && LC[o.loc] ? LC[o.loc] : null);

        /* distance from the chosen reference to a plan's locality (km), or null if unknown.
           Uses the same Haversine helper (hv) and locality map (LC) as d(). */
        const refDist = p =>
            ref && LC[p.loc]
                ? Math.max(.1, Math.round(hv(ref, LC[p.loc]) * 10) / 10)
                : null;

        const nearby = ref
            ? vis()
                .filter(
                    p =>
                        p.live &&                       /* genuinely live/spontaneous */
                        p.status == 'open' &&           /* not cancelled or completed */
                        !p.members.includes('me') &&    /* not already in it */
                        p.members.length < p.max &&     /* not full */
                        refDist(p) != null &&           /* a real, known distance */
                        refDist(p) <= NEARBY_KM         /* within the nearby radius */
                )
                .sort((a, b) => (refDist(a) ?? 1e9) - (refDist(b) ?? 1e9))
            : [];

        /* Location / area selector — rendered ONCE, at the TOP of the section, before results.
           GPS button (rough ~1 km area, privacy-safe) + the existing manual area chips.
           Changing the area fires osset -> re-render -> results refresh for the new area. */
        const selector = `
            <div class="card" style="margin:0 0 14px">
                <b>Your area</b>
                <p class="mut" style="margin:4px 0 10px;font-size:.9rem">
                    ${geoOn()
                        ? 'Showing plans near ' + esc(S.area || 'you') + '.'
                        : ref
                            ? 'Showing plans near ' + esc(o.loc) + '.'
                            : 'Use your location, or pick an area, to see who\'s live nearby.'}
                    We use only your rough area (about 1 km). Nobody else ever sees it.
                </p>
                <button class="btn sm pink" data-a="geo">📍 Use my location</button>
                <p class="mut" style="margin:12px 0 6px;font-size:.85rem">Or pick your area:</p>
                ${os(chips(localitiesOf(S.me.city), 'os.loc', o.loc))}
            </div>
        `;

        /* Results below the selector. */
        let results;

        if (!ref) {
            results = `<p class="mut">Live plans near you show here once your location or area is set.</p>`;
        }
        else {
            results = nearby.length
                ? `<div class="grid">${nearby.map(card).join('')}</div>`
                : `<div class="empty">
                        <h3>No one nearby is live right now.</h3>
                        <p class="mut">Make a plan and get your squad out.</p>
                        <button class="btn" data-a="osMake">Make a plan</button>
                    </div>`;
        }

        return `
            <main style="max-width:560px">
                <a class="back" href="#/home">
                    ← Back
                </a>

                <h1>Who's still out nearby?</h1>

                <p class="mut">
                    Live plans near you right now. Pull up.
                </p>

                ${selector}

                ${results}
            </main>
        `;
    }

    let b = '';

    if (!s)
        b = `
            <h1>You're still out?</h1>
            <div class="row">
                <button class="btn pink" data-a="osn">
                    🫠 Yeah, I'm staying
                </button>
            </div>
        `;

    if (s == 1)
        b = `
            <h1>What's the move?</h1>
            ${os(chips(M, 'os.move', o.move))}
            ${
                o.move == '✨ Custom'
                    ? `
                        <input
                            type="text"
                            style="margin-top:12px"
                            maxlength="24"
                            data-in="os.cname"
                            value="${esc(o.cname || '')}"
                            placeholder="What are we doing?"
                            aria-label="Custom"
                        >
                        <p>
                            <button class="btn pink" data-a="osnext">
                                Next
                            </button>
                        </p>
                    `
                    : ''
            }
        `;

    if (s == 2)
        b = `
            <h1>Who's down?</h1>
            <p class="mut">Max squad size</p>
            ${os(
                chips(
                    ['2', '3', '4', '5', '6'],
                    'os.size',
                    String(o.size)
                )
            )}
        `;

    if (s == 3)
        b = `
            <h1>Where are you?</h1>
            <p>
                <button
                    class="btn pink sm"
                    data-a="geoPick"
                    data-k="os.loc"
                >
                    📍 Use my location
                </button>
            </p>
            ${os(chips(localitiesOf(S.me.city), 'os.loc', o.loc))}
            <p class="mut" style="margin-top:10px">
                Shown as an area only.
            </p>
        `;

    if (s == 4) {
        const mv = o.move.replace(/^\S+ /, '');
        const ty = MT[mv];

        const mt = vis()
            .filter(
                p =>
                    !p.members.includes('me') &&
                    p.members.length < p.max &&
                    (p.type == ty || p.type == 'outside') &&
                    d(p) != null &&
                    d(p) <= NEARBY_KM
            )
            .sort(
                (a, b) =>
                    b.live - a.live ||
                    byDist(a, b)
            )
            .slice(0, 2);

        b = `
            <h1>Post it.</h1>

            <p class="mut">
                ${esc(mv == 'Custom' ? o.cname : mv)}
                · up to ${o.size}
                · ${esc(o.loc)}
            </p>

            ${
                mt.length
                    ? `
                        <h2>Already happening nearby 👀</h2>
                        <div class="grid">
                            ${mt.map(card).join('')}
                        </div>
                        <h2>Or start your own squad</h2>
                    `
                    : ''
            }

            <input
                type="text"
                maxlength="120"
                data-in="os.desc"
                value="${esc(o.desc)}"
                placeholder="Friends left. I'm not done."
                aria-label="Note"
            >

            <p>
                <b>Who can join?</b>
            </p>

            ${chips(
                ['Everyone', 'Girls only', 'Boys only'],
                'os.who',
                o.who || 'Everyone'
            )}

            <p style="margin-top:16px">
                <button class="btn pink wide" data-a="postOut">
                    🔴 Go live
                </button>
            </p>
        `;
    }

    return `
        <main style="max-width:560px">
            <a class="back" href="#/home">
                ← Back
            </a>
            ${b}
        </main>
    `;
}