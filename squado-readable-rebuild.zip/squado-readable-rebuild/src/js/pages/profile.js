function profile() {
    const m = S.me;
    const r = relOf(m);

    /* ── Personal QR: built from the same attUrl() used on the plan page.
          appBaseUrl must be configured for a real QR to generate.
          When unconfigured, shows an honest placeholder instead of a broken image. ── */
    function profileQrSection() {
        /* attUrl requires a plan with an open check-in session.
           On the profile we show the user's identity QR only when a base URL is set.
           We generate it as a static link encoding only the user id — no session token,
           no private data. The host's scanner reads this to identify the member. */
        const base = String((window.SQUADO_CONFIG || {}).appBaseUrl || '').trim();
        let qrHtml = '';

        if (!base) {
            qrHtml = `<p class="mut" style="font-size:.85rem">
                QR code generation requires a deployed address.
                Set <code>appBaseUrl</code> in <code>src/js/config.js</code> to enable it.
            </p>`;
        } else {
            try {
                const u = new URL(base);

                if (u.protocol === 'https:' && u.hostname.includes('.')) {
                    const payload = u.toString().replace(/\/$/, '') + '#/user/' + encodeURIComponent(S.acct || 'me');
                    let svg = '';

                    try {
                        const q = qrcode(0, 'M');

                        q.addData(payload);
                        q.make();
                        svg = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
                    } catch (e) { }

                    qrHtml = svg
                        ? `<div role="img" aria-label="Your personal QR code" style="background:#fff;padding:10px;border-radius:16px;max-width:200px">${svg}</div>
                           <p class="mut" style="font-size:.8rem;margin:8px 0 0">Show this to the host so they can scan you in. Reusable across meetups.</p>`
                        : `<p class="mut" style="font-size:.85rem">QR library loading… (needs an internet connection for the CDN script)</p>`;
                } else {
                    qrHtml = `<p class="mut" style="font-size:.85rem">
                        <code>appBaseUrl</code> must be a public <code>https://</code> address to generate your QR.
                    </p>`;
                }
            } catch (e) {
                qrHtml = `<p class="mut" style="font-size:.85rem">Invalid <code>appBaseUrl</code> in config.</p>`;
            }
        }

        return `
            <div class="card" style="margin:18px 0 0">
                <b>Personal QR code</b>
                <p class="mut" style="margin:4px 0 10px;font-size:.9rem">
                    Your reusable check-in identity. Show it to the meetup host.
                </p>
                ${qrHtml}
            </div>
        `;
    }

    return `
        <main style="max-width:640px">

            <!-- ── A. PROFILE HEADER ── -->
            <div class="row">
                ${av('me', 72)}

                <div>
                    <h1 style="margin:0">
                        ${esc(m.name)}
                    </h1>

                    <span class="mut">
                        @${esc(m.username)} · ${esc(m.gender)}${m.ageRange ? ' · ' + esc(m.ageRange) : ''} · 📍 ${esc(m.city)}
                    </span>

                    <br>

                    ${trust(m)}
                </div>
            </div>

            ${m.bio
                ? `<p style="margin:12px 0">${esc(m.bio)}</p>`
                : '<p class="mut" style="margin:12px 0">No bio yet.</p>'
            }

            <!-- Interests: show ONLY the user's selected interests (read-only pills).
                 The full selectable list lives in Edit Profile (EditProfileSheet). -->
            ${m.interests && m.interests.length
                ? `<div class="row" style="margin-bottom:14px">${m.interests.map(i => `<span class="pill">${lbl(i)}</span>`).join('')}</div>`
                : `<p class="mut" style="margin:0 0 14px">No interests yet — add a few in Edit profile for plans that match you 👀</p>`
            }

            <div class="row">
                <button class="btn sm" data-a="edit">
                    Edit profile
                </button>
            </div>

            <!-- ── B. PERSONAL QR ── -->
            ${profileQrSection()}

            <!-- ── C. RELIABILITY OVERVIEW ── -->
            <div class="card" style="margin:18px 0 0">
                <b>Reliability</b>

                <div class="row" style="margin:10px 0 14px;gap:12px">
                    <div style="text-align:center;flex:1">
                        <b style="font-size:1.6rem">${r.hosted}</b>
                        <br><span class="mut" style="font-size:.8rem">hosted</span>
                    </div>
                    <div style="text-align:center;flex:1">
                        <b style="font-size:1.6rem">${r.joined}</b>
                        <br><span class="mut" style="font-size:.8rem">joined</span>
                    </div>
                    <div style="text-align:center;flex:1">
                        <b style="font-size:1.6rem">${r.attended !== undefined ? r.attended : r.completed}</b>
                        <br><span class="mut" style="font-size:.8rem">attended</span>
                    </div>
                    ${r.noshow
                        ? `<div style="text-align:center;flex:1">
                            <b style="font-size:1.6rem">${r.noshow}</b>
                            <br><span class="mut" style="font-size:.8rem">no-shows</span>
                        </div>`
                        : ''
                    }
                </div>

                <h3 style="margin:0 0 8px;font-size:1rem">Squad feedback</h3>

                ${fbs(m)}
            </div>

            <!-- ── D. SETTINGS ── -->
            <div class="card" style="margin:18px 0 0">
                <b>Settings</b>

                <!-- Appearance -->
                <h3 style="font-size:.9rem;margin:14px 0 8px;color:var(--mut);text-transform:uppercase;letter-spacing:.05em">Appearance</h3>

                <button class="chip" data-a="theme">
                    🌗 Switch theme
                </button>

                <!-- Notifications -->
                <h3 style="font-size:.9rem;margin:14px 0 8px;color:var(--mut);text-transform:uppercase;letter-spacing:.05em">Notifications</h3>

                <button class="chip" aria-pressed="${S.notif}" data-a="notif">
                    🔔 Plan notifications
                </button>

                <!-- Privacy & Safety -->
                <h3 style="font-size:.9rem;margin:14px 0 8px;color:var(--mut);text-transform:uppercase;letter-spacing:.05em">Privacy &amp; Safety</h3>

                <button class="chip" aria-pressed="${geoOn()}" data-a="${geoOn() ? 'geoOff' : 'geo'}">
                    📍 Location
                </button>

                <div style="margin-top:14px">
                    <b style="font-size:.9rem">Blocked</b>
                    ${
                        S.blocked.length
                            ? '<div style="margin-top:8px">' + S.blocked.map(b =>
                                `<div class="li">${av(b, 30)}<b style="flex:1">${esc(usr(b).name)}</b><button class="btn sm ghost" data-a="unblock" data-v="${b}">Unblock</button></div>`
                              ).join('') + '</div>'
                            : '<p class="mut" style="margin:6px 0 0;font-size:.9rem">Nobody blocked.</p>'
                    }
                </div>

                <p class="mut" style="font-size:.75rem;margin-top:18px">
                    Icons by Lucide · Emoji art by Twemoji (CC-BY 4.0)
                </p>
            </div>

            <!-- ── E. LOG OUT ── -->
            <p style="margin:20px 0 8px">
                <button class="btn ghost" data-a="logout">
                    ${I('log-out')} Log out
                </button>
            </p>

        </main>
    `;
}