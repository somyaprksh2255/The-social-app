/* QR check-in, attendance records and meetup completion.
   Chain: membership -> attendance record -> completion (organizer + attendee confirmations) -> feedback eligibility -> ratings / profile stats.

   Records (persisted in S.attendance, one per member per plan; every write path below goes through attTxn):
     { id, planId, uid, status:'present'|'absent'|'claimed', method:'native_camera'|'in_app_scanner'|'manual'|'organizer',
       at, token (first 8 chars of the session token, a reference only), dispute?:{at,note,via}, audit:[{at,by,action,from,to,reason}] }
     present = verified (valid QR check-in, or the organizer marked them)   absent = organizer marked "didn't attend"
     claimed = member says they were there but didn't scan; unverified until the organizer marks them present.
   No record at all means "not checked in yet", never "absent".

   Check-in session on the plan: p.checkin = { token (128-bit random hex), openedAt, expiresAt, closed, n, old:[revoked tokens] }.
   Completion on the plan: p.completion = { by, at, confirms:[uid], disputes:[{u,at}] }; p.status 'ended' only once rules are met.

   Scope of trust: this app has no server. These functions are the single trusted gate every UI path uses and they enforce every rule,
   but the data lives in this browser's localStorage, so anyone with access to the device can edit it, and a check-in from another
   phone cannot reach this device's data. A real deployment needs these same rules in a backend (see README "QR attendance"). */

const cfgNum = (k, d) => {
    const v = +((window.SQUADO_CONFIG || {})[k]);

    return v > 0 ? v : d;
};

/* count settings may be 0 (organizer alone); hours must be > 0 */
const cfgCount = (k, d) => {
    const v = (window.SQUADO_CONFIG || {})[k];

    return Number.isInteger(v) && v >= 0 ? v : d;
};

const ATT_SCAN = ['native_camera', 'in_app_scanner'];

if (!S.attendance)
    S.attendance = [];

const attGet = (p, uid) => S.attendance.find(a => a.planId == p.id && a.uid == uid) || null;

/* verified attendance: present, still in the squad, not under dispute */
const attPresent = (p, uid) => {
    const a = attGet(p, uid);

    return !!a && a.status == 'present' && !a.dispute && p.members.includes(uid);
};

const attCount = p => p.members.filter(m => attPresent(p, m)).length;

const attSessionState = p => {
    const s = p.checkin;

    if (!s)
        return 'none';

    if (s.closed)
        return 'closed';

    return Date.now() >= s.expiresAt ? 'expired' : 'open';
};

const attRand = () => {
    const c = typeof crypto != 'undefined' ? crypto : null;

    if (!c || !c.getRandomValues)
        return '';

    const b = new Uint8Array(16);

    c.getRandomValues(b);

    return [...b].map(x => x.toString(16).padStart(2, '0')).join('');
};

const attEq = (a, b) => {
    a = String(a);
    b = String(b);

    let d = a.length ^ b.length;

    for (let i = 0; i < Math.max(a.length, b.length); i++)
        d |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);

    return d === 0;
};

/* all-or-nothing write: fn mutates and returns a result code; only 'ok'-style results are kept and saved */
function attTxn(p, fn, keep = ['ok']) {
    const snap = JSON.stringify({ a: S.attendance, p });
    const r = fn();

    if (!keep.includes(r)) {
        const s = JSON.parse(snap);

        S.attendance = s.a;
        Object.keys(p).forEach(k => delete p[k]);
        Object.assign(p, s.p);

        return r;
    }

    if (!save()) {
        const s = JSON.parse(snap);

        S.attendance = s.a;
        Object.keys(p).forEach(k => delete p[k]);
        Object.assign(p, s.p);

        return 'save';
    }

    return r;
}

const attId = () => 'a' + Date.now() + Math.random().toString(36).slice(2, 6);

function attUpsert(p, uid, status, method, by, action, reason) {
    let a = attGet(p, uid);
    const from = a ? a.status : 'none';

    if (!a) {
        a = { id: attId(), planId: p.id, uid, status, method, at: Date.now(), token: '', audit: [] };
        S.attendance.push(a);
    }

    a.status = status;
    a.method = method;
    a.at = Date.now();
    delete a.dispute;
    a.audit.push({ at: Date.now(), by, action, from, to: status, reason: reason || '' });

    return a;
}

/* ---- organizer: check-in session ---- */

/* open a session, or rotate to a new code (the old code stops working at once). 'ok' | 'forbidden' | 'state' | 'nocrypto' | 'save' */
function attStart(p) {
    if (!isHost(p))
        return 'forbidden';

    if (p.status != 'open')
        return 'state';

    const token = attRand();

    if (!token)
        return 'nocrypto';

    return attTxn(p, () => {
        const prev = p.checkin;
        const old = prev ? [...(prev.old || []), prev.token].slice(-5) : [];
        const now = Date.now();

        p.checkin = { token, openedAt: now, expiresAt: now + cfgNum('checkInHours', 6) * 36e5, closed: false, n: prev ? prev.n + 1 : 1, old };

        /* the organizer is present at their own meetup */
        if (!attGet(p, p.creator))
            attUpsert(p, p.creator, 'present', 'organizer', p.creator, 'organizer_present', 'Organizer opened check-in');

        return 'ok';
    });
}

function attClose(p) {
    if (!isHost(p))
        return 'forbidden';

    if (!p.checkin || p.checkin.closed)
        return 'state';

    return attTxn(p, () => {
        p.checkin.closed = true;
        return 'ok';
    });
}

/* the link a QR code carries: meetup + session token only (no personal data). Needs the real deployed https address from config. */
function attUrl(p) {
    const base = String((window.SQUADO_CONFIG || {}).appBaseUrl || '').trim();

    if (!base)
        return { err: 'nobase' };

    let u;

    try {
        u = new URL(base);
    }
    catch (e) {
        return { err: 'badbase' };
    }

    if (u.protocol != 'https:' || /^(localhost|127\.|0\.0\.0\.0|\[::1\]|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(u.hostname) || !u.hostname.includes('.'))
        return { err: 'badbase' };

    if (!p.checkin)
        return { err: 'nosession' };

    u.hash = '';
    u.search = '';

    return { url: u.toString() + '#/checkin/' + encodeURIComponent(p.id) + '/' + p.checkin.token };
}

/* ---- member: check-in (the ONE validation used by the native-camera link and the in-app scanner) ---- */

/* validation only, nothing is written. Returns 'ok' or a failure code. */
function attCheck(p, token) {
    if (S.me.guest)
        return 'auth';

    if (!p)
        return 'noplan';

    if (p.status == 'cancelled')
        return 'cancelled';

    if (p.status == 'ended')
        return 'ended';

    const s = p.checkin;

    if (!s)
        return 'nosession';

    if (!/^[0-9a-f]{32}$/.test(String(token)))
        return 'invalid';

    if (!attEq(token, s.token))
        return (s.old || []).some(o => attEq(o, token)) ? 'revoked' : 'invalid';

    if (s.closed)
        return 'closed';

    if (Date.now() >= s.expiresAt)
        return 'expired';

    if (!p.members.includes('me'))
        return 'notmember';

    return 'ok';
}

/* 'checked_in' | 'duplicate' | 'disputed' | attCheck failure | 'method' | 'save' */
function attCheckIn(planId, token, method) {
    if (!ATT_SCAN.includes(method))
        return 'method';

    const p = pl(planId);
    const c = attCheck(p, token);

    if (c != 'ok')
        return c;

    const a = attGet(p, 'me');

    if (a && a.status == 'present' && !a.dispute)
        return 'duplicate';

    return attTxn(p, () => {
        if (a && a.status == 'absent') {
            /* the organizer said absent: a scan doesn't overrule that, it opens a dispute they must resolve */
            a.dispute = { at: Date.now(), via: method, note: 'Member scanned the meetup code' };
            a.audit.push({ at: Date.now(), by: 'me', action: 'dispute', from: 'absent', to: 'absent', reason: 'Scanned the meetup code' });
            return 'disputed';
        }

        const r = attUpsert(p, 'me', 'present', method, 'me', 'check_in', '');

        r.token = p.checkin.token.slice(0, 8);

        return 'checked_in';
    }, ['checked_in', 'disputed']);
}

/* "I was there but couldn't scan" (no record yet) or "I was there" (marked absent): needs the organizer to resolve. 'ok' | ... */
function attClaim(p) {
    if (S.me.guest)
        return 'auth';

    if (!p || p.status == 'cancelled')
        return 'cancelled';

    if (!p.members.includes('me'))
        return 'notmember';

    const a = attGet(p, 'me');

    if (a && (a.status == 'present' || a.status == 'claimed' || a.dispute))
        return 'duplicate';

    return attTxn(p, () => {
        if (!a)
            attUpsert(p, 'me', 'claimed', 'manual', 'me', 'claim', 'Member says they attended but did not scan');
        else {
            a.dispute = { at: Date.now(), via: 'claim', note: 'Member says they attended' };
            a.audit.push({ at: Date.now(), by: 'me', action: 'dispute', from: 'absent', to: 'absent', reason: 'Member says they attended' });
        }

        return 'ok';
    });
}

/* ---- organizer: manual attendance / corrections (same records, same counts) ---- */

/* status 'present' | 'absent'. 'ok' | 'unchanged' | 'forbidden' | 'notmember' | 'cancelled' | 'status' | 'save' */
function attManual(p, uid, status, reason) {
    if (!isHost(p))
        return 'forbidden';

    if (p.status == 'cancelled')
        return 'cancelled';

    if (!['present', 'absent'].includes(status))
        return 'status';

    if (!p.members.includes(uid))
        return 'notmember';

    if (uid == p.creator && status == 'absent')
        return 'forbidden';

    const a = attGet(p, uid);

    if (a && a.status == status && !a.dispute)
        return 'unchanged';

    return attTxn(p, () => {
        attUpsert(p, uid, status, status == 'present' && uid == p.creator ? 'organizer' : 'manual', 'me', 'manual', String(reason || 'Marked by the organizer').trim().slice(0, 120));
        return 'ok';
    });
}

/* ---- completion (separate from attendance) ---- */

const compDisputes = p =>
    ((p.completion && p.completion.disputes) || []).filter(d => {
        const a = attGet(p, d.u);

        return p.members.includes(d.u) && a && (a.status == 'present' || a.status == 'claimed');
    });

/* scheduled | awaiting_completion | completion_pending | completed | cancelled | disputed.
   There is no machine-readable start/end time on plans (`when` is free text), so no state is ever derived from the clock. */
function lifeState(p) {
    if (p.status == 'cancelled')
        return 'cancelled';

    if (p.status == 'ended')
        return 'completed';

    if (p.completion)
        return compDisputes(p).length ? 'disputed' : 'completion_pending';

    return p.checkin ? 'awaiting_completion' : 'scheduled';
}

/* people other than the organizer whose attendance is verified: the only people who can confirm */
const compVerifiers = p => p.members.filter(m => m != p.creator && attPresent(p, m));

/* required independent confirmations = min(config completionConfirmations (default 1), verified attendees). Nobody to ask -> organizer alone. */
const compNeed = p => Math.min(cfgCount('completionConfirmations', 1), compVerifiers(p).length);

const compHave = p => (p.completion.confirms || []).filter(u => compVerifiers(p).includes(u)).length;

/* completes the plan when every rule is met. Returns 'completed' | 'pending' | 'disputed' */
function compSettle(p) {
    if (compDisputes(p).length)
        return 'disputed';

    if (compHave(p) >= compNeed(p)) {
        p.status = 'ended';
        p.endedAt = Date.now();
        p.roster = p.members.filter(m => attPresent(p, m));

        return 'completed';
    }

    return 'pending';
}

/* organizer says the meetup happened and ended. Does NOT mark anyone present. 'completed' | 'pending' | 'disputed' | 'forbidden' | 'state' | 'save' */
function compHost(p) {
    if (!isHost(p))
        return 'forbidden';

    if (p.status != 'open')
        return 'state';

    return attTxn(p, () => {
        if (!p.completion)
            p.completion = { by: p.creator, at: Date.now(), confirms: [], disputes: [] };

        if (!attGet(p, p.creator))
            attUpsert(p, p.creator, 'present', 'organizer', p.creator, 'organizer_present', 'Organizer confirmed the meetup ended');

        return compSettle(p);
    }, ['completed', 'pending', 'disputed']);
}

/* a verified attendee confirms it happened / disputes it / withdraws their dispute */
function compMember(p, act) {
    if (S.me.guest)
        return 'auth';

    if (!p || p.status != 'open' || !p.completion)
        return 'state';

    if (p.creator == 'me')
        return 'forbidden';

    const a = attGet(p, 'me');

    if (!p.members.includes('me') || !a || !['present', 'claimed'].includes(a.status))
        return 'forbidden';

    if (act == 'confirm' && !attPresent(p, 'me'))
        return 'forbidden';

    return attTxn(p, () => {
        const c = p.completion;

        c.confirms = c.confirms.filter(u => u != 'me');
        c.disputes = c.disputes.filter(d => d.u != 'me');

        if (act == 'confirm')
            c.confirms.push('me');
        else if (act == 'dispute')
            c.disputes.push({ u: 'me', at: Date.now() });

        return compSettle(p);
    }, ['completed', 'pending', 'disputed']);
}

/* ---- profile statistics: derived from records, never incremented ---- */

/* Real accounts: hosted = plans you created; joined = plans you're a member of (not your own; may be upcoming);
   attended = distinct completed plans with verified attendance; organized = your plans that reached completed; noshow = marked absent on completed plans.
   `completed` is kept as the name used by the Reliable badge and equals `attended`.
   Built-in demo people keep their fixed demo numbers (they have no real history on this device). */
function relOf(u) {
    const zero = { hosted: 0, joined: 0, completed: 0, cancel: 0, noshow: 0 };

    if (!u)
        return zero;

    if (!(u.real || u.id == 'me')) {
        const r = u.rel || zero;

        return { ...zero, ...r, attended: r.completed };
    }

    if (u.guest)
        return { ...zero, attended: 0, organized: 0 };

    const id = u.id;
    const mine = S.plans.filter(p => p.creator == id);
    const ended = S.plans.filter(p => p.status == 'ended');
    const attended = ended.filter(p => attPresent(p, id)).length;

    return {
        hosted: mine.length,
        joined: S.plans.filter(p => p.creator != id && p.members.includes(id)).length,
        attended,
        completed: attended,
        organized: mine.filter(p => p.status == 'ended').length,
        cancel: (u.rel && u.rel.cancel) || 0,
        noshow: ended.filter(p => { const a = attGet(p, id); return a && a.status == 'absent' && !a.dispute; }).length
    };
}
