const A = {
    set(e) {
        queueMicrotask(() => O.editing && editSheet());
        const [t, k] = path(e.dataset.k);
        t[k] = e.dataset.v;
        if (e.dataset.k == 'W.size')
            O.W.size = +e.dataset.v;
    },
    osset(e) {
        const [t, k] = path(e.dataset.k);
        t[k] = k == 'size' ? +e.dataset.v : e.dataset.v;
        if (O.os.step > 0 && O.os.step < 4 && !(k == 'move' && t[k] == '✨ Custom'))
            O.os.step++;
    },
    osnext() {
        if (!(O.os.cname || '').trim())
            return toast('Name your thing first');
        O.os.step = 2;
    },
    tog(e) {
        queueMicrotask(() => O.editing && editSheet());
        const [t, k] = path(e.dataset.k);
        const a = t[k], v = e.dataset.v, i = a.indexOf(v);
        i < 0 ? a.push(v) : a.splice(i, 1);
        if (e.dataset.k == 'me.interests')
            save();
    },
    obNext() {
        const o = O.ob;
        if (!obOk())
            return;
        if (o.step == 5) {
            finishOb();
            return;
        }
        o.step++;
        o.an = 1;
        saveObProgress();
    },
    obCancel() {
        S.in = true;
    },
    obPrev() {
        O.ob.step--;
        O.ob.an = 1;
        saveObProgress();
    },
    osn() {
        O.os.step = 1;
    },
    /* Still Outside — Find people: show live + nearby spontaneous plans inside the outside flow */
    osFind() {
        O.os.find = 1;
        goHash('#/outside');
    },
    /* Still Outside — Make a plan: enter the creation wizard (never the find view) */
    osMake() {
        O.os.find = 0;
        O.os.step = 1;
        goHash('#/outside');
    },
    geo() {
        locate(n => {
            if (!S.in && n) {
                O.ob.city = O.ob.city || cityOfLoc(n);
                O.ob.locOk = 1;
            }
        });
    },
    geoOff() {
        S.geo = null;
        S.area = null;
        save();
        toast('Location off');
    },
    geoPick(e) {
        const k = e.dataset.k;
        locate(n => {
            if (!n)
                return;
            const [t, f] = path(k);
            t[f] = n;
            if (k == 'os.loc')
                O.os.step = 4;
        });
    },
    home() {
        toast('Get home safe 🫡');
    },
    post() {
        const w = O.W;
        let miss = !w.type ? 'what we\'re doing' : w.type == 'custom' && !(w.custom || '').trim() ? 'a name for it' : !w.loc ? 'where' : !w.when ? 'when' : !w.size ? 'squad size' : '';
        if (miss)
            return toast('Pick ' + miss + ' first');
        if (cityOfLoc(w.loc) != S.me.city || !isCity(S.me.city))
            return toast(isCity(S.me.city) ? 'Pick a place in ' + S.me.city : 'Choose a supported location in your profile first');
        const who = w.who || 'Everyone';
        if (!hostOk(who))
            return toast(who + ' plans need a matching profile gender');
        if (!capacityOk(Number(w.size)))
            return toast('Pick a squad size between ' + squadMin() + ' and ' + squadMax());
        let when = w.when;
        if (when == 'Custom') {
            const t = (w.time || '21:00').split(':'), H = +t[0];
            when = (H % 12 || 12) + ':' + t[1] + ' ' + (H >= 12 ? 'PM' : 'AM');
        }
        const live = when == 'Now',
            id = newPlanId(),
            ev = w.event && S.events.find(e => e.id == w.event),
            cr = (w.carry || []).filter(c => !S.blocked.includes(c)).slice(0, w.size - 1);
        S.plans.unshift({
            id,
            creator: 'me',
            type: w.type,
            custom: w.type == 'custom' ? w.custom.trim() : null,
            title: ev ? `Anyone going to ${ev.title}?` : {
                garba: 'Garba gang, assemble',
                pandal: 'Pandal hop, no plans',
                bhandara: 'Anyone wanna go to this Bhandara?',
                food: 'Food run?',
                chai: 'Chai & yap?',
                photo: 'Photo walk, pics first',
                shopping: 'Shopping spree?',
                city: 'City explore',
                outside: 'Still out, still down',
                custom: (w.custom || '').trim()
            }[w.type],
            desc: w.desc.trim() || 'No plans, just vibes.',
            vibe: w.vibe,
            loc: w.loc,
            city: S.me.city,
            when: live ? 'LIVE NOW' : when,
            live,
            max: Number(w.size),
            members: ['me', ...cr],
            who,
            reqs: [],
            status: 'open',
            day: w.day || 'Today',
            auto: w.mode == 'Auto-accept',
            from: w.from || null,
            event: w.event || null,
            spot: 'Pin goes to the squad in the group chat',
            simAt: Date.now() + 7000,
            created: Date.now()
        });
        S.me.rel.hosted++;
        if (cr.length)
            sys(id, 'Squad carried over from the last stop 🔁');
        O.W = {
            type: '',
            vibe: [],
            loc: '',
            when: '',
            size: 0,
            desc: ''
        };
        save();
        confetti();
        goHash('#/posted/' + id);
    },
    postOut() {
        const o = O.os,
            mv = o.move.replace(/^\S+ /, ''),
            lb = mv == 'Custom' ? o.cname.trim() : mv,
            id = newPlanId(),
            who = o.who || 'Everyone';
        if (!capacityOk(Number(o.size)))
            return toast('Pick a squad size between ' + squadMin() + ' and ' + squadMax());
        if (cityOfLoc(o.loc) != S.me.city || !isCity(S.me.city))
            return toast(isCity(S.me.city) ? 'Pick a place in ' + S.me.city : 'Choose a supported location in your profile first');
        if (!hostOk(who))
            return toast(who + ' plans need a matching profile gender');
        S.plans.unshift({
            id,
            creator: 'me',
            type: 'outside',
            custom: 'Still out · ' + lb,
            title: {
                Chai: 'Chai & yap?',
                Food: 'Food run?',
                Garba: 'Anyone still dancing?',
                'Pandal Hopping': 'Pandal hop, right now?',
                Photos: 'Photo walk, right now?',
                Walk: 'Walk & talk?',
                Explore: 'Let\'s explore'
            }[mv] || lb,
            desc: o.desc.trim() || 'Friends left. I\'m not done.',
            vibe: ['🫠 No plans, just vibes'],
            loc: o.loc,
            city: S.me.city,
            when: 'LIVE NOW',
            live: true,
            max: Number(o.size),
            members: ['me'],
            who,
            reqs: [],
            status: 'open',
            spot: 'Pin goes to the squad in the group chat',
            simAt: Date.now() + 7000,
            created: Date.now()
        });
        S.me.rel.hosted++;
        O.os = {
            step: 0,
            move: '',
            size: 0,
            loc: '',
            desc: '',
            cname: ''
        };
        save();
        confetti();
        goHash('#/posted/' + id);
    },
    join(e) {
        const p = pl(e.dataset.v), g = S.me.gender;
        if (!p)
            return toast('This plan is no longer available.');
        if ((p.who == 'Girls only' && g != 'Girl') || (p.who == 'Boys only' && g != 'Boy'))
            return toast('This one\'s ' + p.who.toLowerCase() + ' 🫶');
        modal(`\<h2 style="margin-top:0">Ask to join the squad 👀\</h2>\<p>\<b>${esc(p.title)}\</b>\<br>\<span class="mut">${esc(p.loc)} · ${p.live ? 'Live now' : p.when} · ${p.members.length} / ${p.max} people${p.who != 'Everyone' ? ' · ' + p.who : ''}\</span>\</p>\<p class="mut">${esc(usr(p.creator).name)} checks your profile, then accepts or passes.\</p>\<button class="btn pink wide" data-a="cjoin" data-v="${p.id}">Send request\</button>\<p style="text-align:center">\<button class="btn ghost sm" data-a="close">Nvm\</button>\</p>`);
    },
    cjoin(e) {
        const p = pl(e.dataset.v);
        const c = joinCheck(p);
        if (c != 'ok') {
            modal('');
            if (c == 'auth' || c == 'onboarding' || c == 'member')
                return;
            return toast(JOIN_MSG[c] ? JOIN_MSG[c](p) : 'This plan is no longer available.');
        }
        const r = memRequest(p, 'me');
        if (!r.ok) {
            modal('');
            return toast(JOIN_MSG[r.why] ? JOIN_MSG[r.why](p) : 'This plan is no longer available.');
        }
        if (r.state == 'accepted') {
            S.me.rel.joined++;
            sys(p.id, `${S.me.name} joined the squad 👋`);
            notify(p.creator, {
                type: 'member',
                ic: 'user-plus',
                c: 'green',
                t: `${S.me.name} joined your squad`,
                b: p.title,
                planId: p.id,
                userId: 'me'
            });
            save();
            confetti();
            return modal(`<div class="authst"><span class="okc">${I('check', '26px')}</span><h2>You're in 🎉</h2><p class="mut">This host auto-accepts. The GC is unlocked.</p></div><a class="btn pink wide" href="#/gc/${p.id}" data-a="close">Enter the GC</a>`);
        }
        notify(p.creator, {
            type: 'join_request',
            ic: 'user-plus',
            c: 'pink',
            t: `${S.me.name} wants to join your squad`,
            b: `${p.title} · tap to review`,
            planId: p.id,
            userId: 'me'
        });
        save();
        modal(`<h2 style="margin-top:0">Request sent ⏳</h2><p class="mut">You're not in yet. The host decides after seeing your profile.</p><button class="btn pink wide" data-a="close">Cool</button>`);
    },
    unreq(e) {
        const p = pl(e.dataset.v);
        if (!p || membership(p, 'me') != 'pending')
            return toast('That request is no longer there.');
        if (!memCancelRequest(p, 'me').ok)
            return toast('That request is no longer there.');
        resolveJoinNotifs(p.id, 'me');
        save();
    },
    accept(e) {
        const parts = (e.dataset.v || '').split('|');
        const p = pl(e.dataset.k || parts[0]);
        const u = e.dataset.k ? e.dataset.v : parts[1];
        if (!p || !idOk(u))
            return toast('This join request is no longer available.');
        const r = memApprove(p, u, 'me');
        if (!r.ok)
            return toast({
                admin: 'Only the host can approve requests.',
                closed: 'This plan is no longer open.',
                removed: 'This person was removed from the squad.',
                blocked: 'You blocked this person. Unblock them in Settings first.',
                full: 'Squad full 🔥 Free up a spot to approve this request.'
            }[r.why] || 'This join request is no longer available.');
        if (usr(u).rel)
            usr(u).rel.joined++;
        sys(p.id, `${usr(u).name} joined the squad 👋`);
        resolveJoinNotifs(p.id, u);
        notify(u, {
            type: 'join-approved',
            ic: 'party-popper',
            c: 'green',
            t: 'You\'re in!',
            b: `${S.me.name} accepted you for ${p.title}`,
            planId: p.id,
            userId: 'me'
        });
        if (p.members.length >= p.max) {
            sys(p.id, 'Squad full 🔥');
            confetti();
        }
        save();
        modal('');
        toast(usr(u).name + ' is in 🫡');
        render();
    },
    reject(e) {
        const parts = (e.dataset.v || '').split('|');
        const p = pl(e.dataset.k || parts[0]);
        const u = e.dataset.k ? e.dataset.v : parts[1];
        if (!p || !idOk(u))
            return toast('This join request is no longer available.');
        const r = memReject(p, u, 'me');
        if (!r.ok)
            return toast({
                admin: 'Only the host can decline requests.',
                closed: 'This plan is no longer open.'
            }[r.why] || 'This join request is no longer available.');
        resolveJoinNotifs(p.id, u);
        /* silent by design: the requester is not notified; they only see their own request status on the plan page */
        save();
        modal('');
        toast('Passed 🫶');
        render();
    },
    going(e) {
        const ev = S.events.find(x => x.id == e.dataset.v), i = ev.going.indexOf('me');
        if (i < 0) {
            ev.going.push('me');
            confetti();
        }
        else {
            ev.going.splice(i, 1);
        }
        save();
    },
    evPlan(e) {
        const ev = S.events.find(x => x.id == e.dataset.v);
        O.W = {
            type: ev.tag,
            vibe: [],
            loc: ev.loc,
            when: '',
            size: 0,
            desc: `Anyone going to ${ev.title} tonight?`,
            event: ev.id
        };
        modal('');
        goHash('#/create');
    },
    drop(e) {
        O.W.carry = O.W.carry.filter(c => c != e.dataset.v);
    },
    nextSheet(e) {
        const id = e.dataset.v;
        modal(`\<h2 style="margin-top:0">Next stop ➜\</h2>\<p class="mut">Keep the squad together. What's next?\</p>\<div class="opt">${['garba', 'chai', 'food', 'pandal', 'city', 'photo', 'bhandara', 'custom'].map(k => `\<button class="chip" data-a="nextGo" data-k="${id}" data-v="${k}">${T[k][0]} ${T[k][1]}\</button>`).join('')}\</div>`);
    },
    nextGo(e) {
        const p = pl(e.dataset.k), ty = e.dataset.v;
        O.W = {
            type: ty,
            vibe: [],
            loc: p.loc,
            when: 'Now',
            size: p.max,
            desc: '',
            carry: p.members.filter(m => m != 'me'),
            from: p.id
        };
        sys(p.id, `Next stop: ${T[ty][1]}`);
        save();
        modal('');
        goHash('#/create');
    },
    /* Permanent removal from THIS squad only: not a platform ban, no other squad is touched. The person keeps their
       history (messages, attendance, ratings stay as records) but loses access, and cannot ask to join this squad again. */
    remove(e) {
        const p = pl(e.dataset.k), m = e.dataset.v;
        if (!p || !idOk(m))
            return toast('That person isn\'t in this squad.');
        const r = memRemove(p, m, 'me');
        if (!r.ok)
            return toast({
                admin: 'Only the host can remove people.',
                host: 'The host can\'t be removed.'
            }[r.why] || 'That person isn\'t in this squad.');
        resolveJoinNotifs(p.id, m);
        sys(p.id, `${usr(m).name} was removed by the host`);
        notify(m, {
            type: 'removed',
            ic: 'user-minus',
            c: 'red',
            t: 'You were removed from a squad',
            b: p.title,
            planId: p.id,
            userId: 'me'
        });
        save();
        modal('');
        toast('Removed');
    },
    cancel(e) {
        const p = pl(e.dataset.v);
        if (!p || !isAdmin(p))
            return toast('Only the host can cancel this plan.');
        p.status = 'cancelled';
        S.me.rel.cancel++;
        sys(p.id, 'Plan cancelled by the host');
        p.members.filter(m => m != 'me').forEach(m => notify(m, {
            type: 'plan',
            ic: 'circle-x',
            c: 'red',
            t: 'Plan cancelled',
            b: `${S.me.name} cancelled ${p.title}`,
            planId: p.id,
            userId: 'me'
        }));
        save();
        modal('');
        toast('Plan cancelled');
        goHash('#/groups');
    },
    /* organizer confirms the meetup happened and ended. This alone neither marks anyone present nor, when attendees exist, completes it:
       completion needs the rules in state/attendance.js (organizer + attendee confirmations, no open dispute) */
    end(e) {
        const p = pl(e.dataset.v);
        const r = compHost(p);

        if (r == 'forbidden' || r == 'state')
            return;

        if (r == 'save')
            return toast('We couldn\'t save that. Please try again.');

        if (r == 'completed') {
            attFinish(p);
            confetti();
            fbEligible(p) ? fbStart(p.id) : modal('');
        }
        else {
            attAskConfirm(p);
            modal('');
            toast(r == 'disputed' ? 'A verified attendee disputes this. It stays open.' : 'Saved. Waiting for attendee confirmation.');
        }

        render();
    },
    fbOpen(e) {
        fbStart(e.dataset.v);
    },
    fbStar(e) {
        if (!O.fm || O.fm.busy)
            return;
        O.fm.rating = +e.dataset.v;
        O.fm.error = '';
        fbMeetupSheet(O.fm.id);
    },
    fbTag(e) {
        if (!O.fm || O.fm.busy)
            return;
        const t = e.dataset.v, i = O.fm.tags.indexOf(t);
        i < 0 ? O.fm.tags.push(t) : O.fm.tags.splice(i, 1);
        fbMeetupSheet(O.fm.id);
    },
    fbSubmit() {
        const f = O.fm;
        if (!f || f.busy || f.done)
            return;
        if (!f.rating) {
            f.error = FB_ERR.rating;
            return fbMeetupSheet(f.id);
        }
        f.busy = true;
        f.error = '';
        fbMeetupSheet(f.id);
        /* let the "Sending…" state paint before the work runs */
        setTimeout(() => {
            const r = fbSaveMeetup(pl(f.id), f);
            const open = O.fm === f && O.tok == f.tok;
            f.busy = false;
            if (r == 'ok') {
                f.done = true;
                delete S.fbLater[f.id];
                save();
            }
            else
                f.error = FB_ERR[r] || FB_ERR.save;
            if (open)
                fbMeetupSheet(f.id);
            else if (r == 'ok')
                toast('Thanks, feedback sent');
            render();
        }, 0);
    },
    fbLater(e) {
        S.fbLater[e.dataset.v] = Date.now() + 864e5;
        save();
        O.fm = null;
        modal('');
        toast('No problem, we\'ll ask again tomorrow');
        render();
    },
    fbPeople(e) {
        const p = pl(e.dataset.v);
        if (!fbEligible(p) || !fbUnreviewed(p).length)
            return toast('Nothing left to review for this plan.');
        O.fb = null;
        fbSheet(p.id);
    },
    /* step 1: choose (or un-choose) a person to review */
    fbPick(e) {
        const F = O.fb, m = e.dataset.v;
        if (!F || F.id != e.dataset.k || F.busy)
            return;
        const i = F.sel.indexOf(m);
        i < 0 ? F.sel.push(m) : F.sel.splice(i, 1);
        F.error = '';
        fbPickSheet(pl(F.id));
    },
    fbCont(e) {
        const F = O.fb;
        if (!F || F.id != e.dataset.v || F.busy)
            return;
        if (!F.sel.length) {
            F.error = FB_PERR.empty;
            return fbPickSheet(pl(F.id));
        }
        F.error = '';
        fbRateSheet(pl(F.id));
    },
    fbBack(e) {
        const F = O.fb;
        if (!F || F.busy)
            return;
        F.error = '';
        fbPickSheet(pl(F.id));
    },
    fbPStar(e) {
        const F = O.fb;
        if (!F || F.busy)
            return;
        const [id, m] = e.dataset.k.split('|');
        if (F.id != id || !F.sel.includes(m))
            return;
        F.d[m] = F.d[m] || { r: 0, t: [], c: '' };
        F.d[m].r = +e.dataset.v;
        F.error = '';
        fbRateSheet(pl(id));
    },
    fbTog(e) {
        const F = O.fb;
        if (!F || F.busy)
            return;
        const [id, m] = e.dataset.k.split('|'),
            x = F.d[m] = F.d[m] || { r: 0, t: [], c: '' },
            v = e.dataset.v,
            i = x.t.indexOf(v);
        i < 0 ? x.t.push(v) : x.t.splice(i, 1);
        fbRateSheet(pl(id));
    },
    fbSend(e) {
        const F = O.fb, p = pl(e.dataset.v);
        if (!F || F.busy || F.id != p.id)
            return;
        /* only the people still picked are sent */
        const d = {};
        F.sel.forEach(m => d[m] = F.d[m]);
        F.busy = true;
        F.error = '';
        fbRateSheet(p);
        /* let the "Sending…" state paint before the work runs */
        setTimeout(() => {
            const r = fbSavePeople(p, d);
            const open = O.fb === F && O.tok == F.tok;
            F.busy = false;
            if (r == 'ok') {
                O.fb = null;
                if (open)
                    modal('');
                toast('Thanks 🫶 Anonymous, totals only');
            }
            else {
                F.error = FB_PERR[r] || FB_PERR.save;
                if (open)
                    fbRateSheet(p);
            }
            render();
        }, 0);
    },
    /* "didn't show": an organizer-marked absent attendance record (same record as QR check-ins and manual marks) */
    noshow(e) {
        const p = pl(e.dataset.k), m = e.dataset.v;
        const r = attManual(p, m, 'absent', 'Marked as not attending');

        if (r != 'ok')
            return toast(r == 'unchanged' ? 'Already marked.' : 'Couldn\'t mark that.');

        toast('Noted. Reliability only changes after a few plans.');
        fbSheet(p.id);
    },
    edit() {
        const m = S.me;
        O.ed = {
            name: m.name,
            username: m.username,
            bio: m.bio || '',
            gender: m.gender,
            city: m.city,
            age: m.ageRange || '',
            photo: m.photo || '',
            interests: [...m.interests]
        };
        editSheet();
    },
    saveEd() {
        const e = O.ed, u = (e.username || '').toLowerCase();
        if (!e.name.trim())
            return toast('Name can\'t be empty');
        if (unOk(u, S.me.username) != 'ok')
            return toast('Pick a free username');
        if (!isCity(e.city))
            return toast('Pick a supported location');
        Object.assign(S.me, {
            name: e.name.trim(),
            username: u,
            bio: e.bio.trim(),
            gender: e.gender,
            ageRange: e.age,
            city: e.city,
            photo: e.photo,
            interests: e.interests
        });
        save();
        modal('');
        toast('Profile updated ✨');
    },
    close() {
        modal('');
    },
    attachments(e) {
        O.media = null;
        modal(mediaSheet(e.dataset.v));
    },
    send(id) {
        const i = $('#mi'),
            x = (i && i.value || O.chat.draft || '').trim().slice(0, chatMaxLen());
        if (!x || !idOk(id) || !groupAccess(pl(id)))
            return;
        O.chat.draft = '';
        msgs(id).push({
            by: 'me',
            x,
            t: hm()
        });
        save();
        render();
        scrollTo(0, 1e6);
        const mi = $('#mi');
        mi && mi.focus();
        const o = pl(id).members.filter(m => m != 'me' && !S.blocked.includes(m) && !usr(m).real);
        const sid = O.sess;
        if (o.length)
            setTimeout(() => {
                /* the sample reply belongs to the session that sent the message: never into a signed-out or different account */
                if (O.sess !== sid || !groupAccess(pl(id)))
                    return;
                const by = o[Math.random() * o.length | 0];
                msgs(id).push({
                    by,
                    x: ['I\'m down 🕺', 'omw 😭', 'Where exactly?', 'Full send 🔥', 'Save me a spot!'][Math.random() * 5 | 0],
                    t: hm()
                });
                save();
                if (location.hash == '#/gc/' + id) {
                    render();
                    scrollTo(0, 1e6);
                }
                else {
                    unreadBump(id);
                    save();
                    render();
                }
            }, 1300);
    },
    sendMedia(e) {
        const id = e.dataset.k;
        const m = O.media;
        const p = pl(id);
        if (!m || m.id != id || !p || !groupAccess(p))
            return;
        const message = {
            by: 'me',
            type: m.type == 'photo' && m.loc ? 'photo-location' : m.type,
            t: hm()
        };
        if (m.src)
            message.src = m.src;
        if (m.loc)
            message.loc = m.loc;
        msgs(id).push(message);
        O.media = null;
        save();
        modal('');
        render();
        scrollTo(0, 1e6);
    },
    react(e) {
        if (!groupAccess(pl(e.dataset.k)))
            return;
        const m = msgs(e.dataset.k)[+e.dataset.v],
            c = ['🔥', '🕺', '😭', ''];
        if (!m || m.sys)
            return;
        const i = c.indexOf(m.r || '');
        m.r = c[(i + 1) % 4];
        save();
        render();
    },
    members(e) {
        const p = pl(e.dataset.v);
        if (!groupAccess(p))
            return toast('Only squad members can see the squad.');
        const h = isAdmin(p);
        modal(`<h2 style="margin-top:0">The squad ${p.members.length} / ${p.max}</h2>${p.members.map(m => `<div class="li">${av(m, 36)}<b style="flex:1">${esc(usr(m).name)}${m == p.creator ? ' 👑' : ''}${S.blocked.includes(m) ? ' <span class="mut">· blocked</span>' : ''}</b>${m != 'me' && !S.blocked.includes(m) ? `<button class="btn ghost sm" data-a="user" data-v="${m}">View</button>` : ''}${h && m != 'me' ? `<button class="btn ghost sm" data-a="ask" data-do="remove" data-k="${p.id}" data-v="${m}">${I('user-minus')} Remove</button>` : ''}</div>`).join('')}<div class="row">${h ? '' : `<button class="btn ghost sm" data-a="ask" data-do="leave" data-v="${p.id}">${I('log-out')} Leave squad</button>`}<button class="btn ghost sm" data-a="report" data-k="plan" data-v="${p.id}">${I('flag')} Report plan</button>${h && p.status == 'open' ? `<button class="btn sm" data-a="end" data-v="${p.id}">Confirm it ended</button><button class="btn ghost sm" data-a="ask" data-do="cancel" data-v="${p.id}">${I('circle-x')} Cancel plan</button>` : ''}</div>`);
    },
    /* Voluntary departure: recorded as p.left (they may ask to join again, like anyone new); never as removal. */
    leave(e) {
        const p = pl(e.dataset.v);
        if (!p || !groupAccess(p))
            return toast('You\'re not in this squad.');
        if (isAdmin(p))
            return toast('Hosts can\'t leave their own plan. Cancel it instead.');
        const r = memLeave(p, 'me');
        if (!r.ok)
            return toast('You\'re not in this squad.');
        /* leaving by choice is not a cancellation: the reliability counter (rel.cancel) is for hosts cancelling a plan */
        sys(p.id, `${S.me.name} left. Bro escaped 💀`);
        notify(p.creator, {
            type: 'member',
            ic: 'user-minus',
            c: 'pink',
            t: `${S.me.name} left your squad`,
            b: p.title,
            planId: p.id,
            userId: 'me'
        });
        save();
        modal('');
        toast('You escaped successfully 💀');
        goHash('#/groups');
    },
    user(e) {
        if (!canViewProfile(e.dataset.v))
            return toast('That profile isn\'t available.');
        modal(profileSheet(e.dataset.v));
    },
    block(e) {
        const id = e.dataset.v;
        if (!idOk(id) || id == 'me' || !S.users.some(u => u.id == id))
            return toast('That person isn\'t available.');
        if (!S.blocked.includes(id))
            S.blocked.push(id);
        save();
        modal('');
        toast(usr(id).name + ' blocked');
        render();
    },
    unblock(e) {
        S.blocked = S.blocked.filter(b => b != e.dataset.v);
        save();
        render();
    },
    report(e) {
        O.rep = {
            k: e.dataset.k,
            id: e.dataset.v
        };
        modal(`\<h2 style="margin-top:0">Report ${e.dataset.k}\</h2>${['Fake or spam', 'Made me uncomfortable', 'Inappropriate', 'Unsafe plan or place', 'Underage or lying about age', 'Something else'].map((r, i) => `\<label class="r">\<input type="radio" name="rr" value="${r}" ${i ? '' : 'checked'}>${r}\</label>`).join('')}\<button class="btn pink wide" data-a="submitRep">Send report\</button>`);
    },
    submitRep() {
        const r = document.querySelector('input[name=rr]:checked').value,
            x = O.rep;
        S.reports.push({
            ...x,
            r,
            at: Date.now()
        });
        if (x.k == 'plan')
            pl(x.id).review = true;
        save();
        modal('');
        toast('Report sent. We\'ll take a look.');
        render();
    },
    notif() {
        S.notif = !S.notif;
        save();
    },
    theme() {
        const d = document.documentElement,
            t = d.dataset.theme == 'dark' ? 'light' : 'dark';
        d.dataset.theme = t;
        try {
            localStorage.setItem('squado-theme', t);
        }
        catch (e) { }
    },
    logout() {
        signOutUser();
    }
};
Object.assign(A, attActions);
/* ---- frontend-only extensions (confirmations, notifications, loading states) ---- */
A.ask = e => {
    if (!hasOwn(CONF, e.dataset.do))
        return;
    O.confirm = {
        do: e.dataset.do,
        k: e.dataset.k,
        v: e.dataset.v
    };
    confirmSheet();
};
A.confirmed = () => {
    const c = O.confirm;
    modal('');
    O.confirm = null;
    if (!c || !hasOwn(CONF, c.do))
        return;
    const sid = O.sess;
    setTimeout(() => O.sess === sid && A[c.do]({
        dataset: {
            k: c.k,
            v: c.v
        }
    }), 120);
};
A.notifs = () => {
    modal(notifSheet());
    myNotifs().forEach(n => n.u = 0);
    save();
};
A.notifGo = e => {
    const n = myNotifs().find(x => x.id == e.dataset.v);
    const r = n ? notifView(n).route : '';
    modal('');
    if (!r)
        return toast('That one is no longer available.');
    if (location.hash == r)
        render();
    else
        goHash(r);
};
{
    const _c = A.cjoin;
    A.cjoin = e => {
        modal(`\<div class="authst">\<span class="spin">\</span>\<h2>Sending your request…\</h2>\<p class="mut">Letting the host know\</p>\</div>`);
        setTimeout(() => _c(e), 700);
    };
}
{
    const _p = A.post;
    A.post = e => {
        if (O.posting)
            return;
        const m = postMissing();
        if (m)
            return toast('Pick ' + m + ' first');
        O.posting = true;
        render();
        setTimeout(() => {
            O.posting = false;
            _p(e);
        }, 650);
    };
}
A.gopts = e => modal(groupOptions(e.dataset.v));
/* Group Info is role-aware:
     host           -> groupInfoHost: important details + host-only attendance scanner entry point
     accepted member-> groupInfo: the simpler, important-details-only sheet (restored)
   Both are modal sheets, so closing them returns the host/member to the same conversation.
   The 'ginfo' guard (RULES: ['group','v']) already blocks pending/rejected/left/removed/guests. */
A.ginfo = e => {
    const p = idOk(e.dataset.v) ? pl(e.dataset.v) : null;

    if (!p)
        return;

    modal(isAdmin(p) ? groupInfoHost(p.id) : groupInfo(p.id));
};
A.goPlan = e => {
    modal('');
    if (idOk(e.dataset.v))
        goHash('#/plan/' + e.dataset.v);
};
A.goBack = () => {
    if (typeof history.back == 'function' && history.length > 1)
        history.back();
    else
        goHash('#/home');
};
A.reviewRequest = e => reviewRequest(e);
A.openMediaCamera = e => openMediaCamera(e);
A.mediaGallery = e => mediaGallery(e);
A.capturePhoto = e => capturePhoto(e);
A.mediaRetry = e => mediaRetry(e);
A.attachLocation = e => attachLocation(e);
A.openMediaLocation = e => openMediaLocation(e);
A.detachLocation = e => detachLocation(e);