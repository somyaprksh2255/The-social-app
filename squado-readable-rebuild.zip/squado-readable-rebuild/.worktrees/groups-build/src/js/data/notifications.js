/* Notifications are delivered to a specific person (n.to) while the app runs, never pre-seeded:
   a new account starts with none. See state/notify.js for the record shape. */
const NOTIFS0 = [];
