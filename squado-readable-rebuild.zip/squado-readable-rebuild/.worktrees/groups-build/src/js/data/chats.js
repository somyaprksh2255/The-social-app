/* Sample squad conversations between the sample people (keyed by plan id).
   Unread counts belong to the signed-in account, so none are pre-seeded. */

const CHATS0 = {
    p9: [
        {
            sys: 1,
            x: 'Aditi started the plan'
        },
        {
            by: 'u1',
            x: 'Gates open at 7:30. I\'ll be near the left gate in a yellow dupatta',
            t: '6:40 PM'
        },
        {
            by: 'u3',
            x: 'Perfect, reaching around 8. Traffic is wild 😭',
            t: '6:52 PM'
        },
        {
            by: 'u5',
            x: 'Forgot my dandiya sticks again 💀',
            t: '7:05 PM'
        },
        {
            by: 'u8',
            x: 'Photos at the entrance first, then garba? 📸',
            t: '7:12 PM'
        },
        {
            by: 'u1',
            x: 'Yes. Group pic at 8:15 before it gets crowded',
            t: '7:14 PM'
        },
        {
            by: 'u3',
            x: 'Chai after? There\'s a stall near the parking',
            t: '7:20 PM'
        }
    ],

    p10: [
        {
            sys: 1,
            x: 'Meera started the plan'
        },
        {
            by: 'u6',
            x: 'Bittan Market, the stall with the green tent',
            t: '5:10 PM'
        },
        {
            by: 'u2',
            x: 'Saved. Poha jalebi after?',
            t: '5:25 PM'
        }
    ]
};

const UNREAD0 = {};