const hv = (a, b) => {
    const r = Math.PI / 180;
    const x = (b[0] - a[0]) * r;
    const y = (b[1] - a[1]) * r;

    const q =
        Math.sin(x / 2) ** 2 +
        Math.cos(a[0] * r) *
        Math.cos(b[0] * r) *
        Math.sin(y / 2) ** 2;

    return 12742 * Math.asin(Math.sqrt(q));
};

/* the locality nearest to the user's position, only if it is inside a supported city */
const near = () => {
    if (!S.geo)
        return null;

    let b = null;
    let m = 1e9;

    CITY_DATA.forEach(c => {
        if (hv(S.geo, c.center) > c.radiusKm)
            return;

        for (const k in c.localities) {
            const x = hv(S.geo, c.localities[k]);

            if (x < m) {
                m = x;
                b = k;
            }
        }
    });

    return b;
};

const geoOn = () => !!near();

/* distance in km from the user's approximate position to the plan's locality.
   null when either is unknown or the user is outside every supported city: never an invented number */
const d = p =>
    geoOn() && LC[p.loc]
        ? Math.max(
              .1,
              Math.round(hv(S.geo, LC[p.loc]) * 10) / 10
          )
        : null;

const byDist = (a, b) =>
    (d(a) ?? 1e9) - (d(b) ?? 1e9);

const kmTxt = p =>
    d(p) == null ? '' : ` · ~${d(p)} km`;

function locate(cb) {
    if (!navigator.geolocation)
        return toast('Location isn\'t available here. Pick an area.');

    toast('Finding you... 📍');

    navigator.geolocation.getCurrentPosition(
        p => {
            S.geo = [
                Math.round(p.coords.latitude * 100) / 100,
                Math.round(p.coords.longitude * 100) / 100
            ];

            const n = near();

            if (!n) {
                S.geo = null;
                S.area = null;
            }
            else
                S.area = n;

            save();

            toast(
                n
                    ? 'Location on. Showing plans near you 📍'
                    : 'Squado is only in ' + CITIES.join(', ') + ' for now. Pick an area manually.'
            );

            cb && cb(n);
            render();
        },
        e =>
            toast(
                e.code == 1
                    ? 'Location blocked. Allow it in your browser, or pick an area.'
                    : 'Couldn\'t get location. Pick an area instead.'
            ),
        {
            timeout: 10000,
            maximumAge: 6e5
        }
    );
}

/* a saved city we don't support (older data) is kept, but the person is asked to pick a supported one */
const cityNotice = () =>
    !S.me.guest && S.me.city && !isCity(S.me.city)
        ? `<div class="card" style="margin:14px 0"><b>Squado is live in ${esc(CITIES.join(', '))} for now</b><p class="mut" style="margin:4px 0 10px">Your saved location (${esc(S.me.city)}) isn't supported yet.</p><button class="btn sm pink" data-a="edit">Choose a supported location</button></div>`
        : '';

const geoBar = () =>
    cityNotice() +
    (geoOn()
        ? `<p class="mut" style="margin:12px 0">📍 Plans sorted near ${esc(S.area || 'you')} · rough area only <button class="chip" style="padding:2px 10px" data-a="geoOff">Turn off</button></p>`
        : `<div class="card" style="margin:14px 0"><b>Want plans near you?</b><p class="mut" style="margin:4px 0 10px">We only use your rough area (about 1 km). Nobody else ever sees it.</p><button class="btn sm pink" data-a="geo">📍 Use my location</button></div>`);