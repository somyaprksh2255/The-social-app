SQUADO - UPDATE NOTES
=====================
Everything below was actually changed in this version. Verified with `npm test` (118 checks on a simulated DOM,
including page refresh and two real accounts on one device), `npm run build` (syntax + references). It was NOT
tried in a real browser, so camera/geolocation prompts, the native file picker and phone keyboard behaviour
should get a quick manual pass on a device (camera/location need https or localhost).

(The authentication notes in this first section are superseded by "UPDATE 2" at the bottom: sign-in is now real Google.)

CHAT
----
- Composer is now exactly: attachment button, message input, send button. Removed the notification bell and the
  separate location pin (location lives in the attachment sheet).
- Attachment sheet: Camera, Gallery, Location, Cancel (existing sheet, kept).
- Camera: permission is requested only after tapping Camera; preview, Take photo, Retake, Send. Denied/unavailable
  shows an explanation with Try again and "Choose from gallery instead". The stream is released on Cancel, on
  tapping outside the sheet, on route change, after capture/send, and if the browser answers after the sheet was closed.
- Gallery: file picker, preview (resized to max 1280px JPEG so local storage doesn't fill up), Send / Choose another.
- Location: requested only after tapping Location; confirmation preview (coordinates, accuracy, Maps check link);
  sent only on "Share location". Denied/timeout shows instructions + Try again. Sent locations render with an
  "Open in Maps" link.
- Photo + location: only when "Attach my current location" is tapped on the preview (can be removed again).
  Camera/Gallery never request location by themselves.
- Replaced native confirm() dialogs with the app's own sheets. Pending attachment is kept in memory (O.media)
  instead of huge data attributes. Chat list preview no longer shows "undefined" for photos/locations.

NOTIFICATIONS
-------------
- Notifications are now addressed to a person (n.to) - the bell, unread dot and overlay show only the signed-in
  user's. New notify()/myNotifs()/notifRoute() in state/notify.js.
- Fixed the overlay: items no longer use href="#" (which closed the sheet through hashchange); approve/reject used to
  create records with no title/icon, which broke the overlay. Added a Close button.
- Opening the overlay still marks everything read (existing behaviour); the dot updates immediately.
- Routing is derived from planId/eventId, nothing hard-coded: join request (host) -> that squad chat;
  approved -> chat; rejected -> plan page; message/membership -> chat (plan page if you are not in it);
  plan update -> plan page; event -> event page; missing target -> "no longer available".
- New producers: host removal and plan cancellation notify the affected people.
- Relative times ("now", "5m") are computed from a timestamp instead of a stored label.

JOIN REQUESTS
-------------
- Pending requests (plan.reqs) are separate from members. Removed the "Pending requests" block from View Members.
- Host gets a notification when someone asks (stored for the real host, whoever that is).
- Host sees a "<name> wants to join the squad - Review request" strip above the conversation in that squad's chat
  (components/squads/JoinRequestSheet.js joinRequestBar). Members and requesters never see it.
- Review request opens the existing profile sheet (extracted into components/profile/ProfileSheet.js and reused by
  every "View/Profile" button) in review mode with Accept / Reject.
- Accept: leaves pending, joins members, count updates, "<name> joined the squad" system message, requester
  notified, host's pending notification resolved, saved, sheet closes, strip disappears. If the squad is full the
  request stays pending (before, it was silently deleted).
- Reject: leaves pending, not added, remembered (plan page shows "Host passed this time"), requester notified, saved.
- Only the plan's host can accept/reject/review; checked in the actions, not just hidden in the UI.
- Taking back a request removes the host's notification. Sending a request twice, to a full/ended plan, or after
  being passed on is handled; the "Sending your request..." spinner no longer gets stuck in those cases.

AUTHENTICATION / DEMO REMOVAL
-----------------------------
- Removed "Reset demo data" (button and handler) and the "Prototype:" text in the sign-in sheet. Removed the unused
  "shared a photo (preview coming soon)" and meetup-location placeholder handlers.
- Every account now has its own id. Inside the app the signed-in person is still 'me'; on logout their data is
  re-labelled to the account id and the profile stored in S.users (real:1); on login it is restored. Squads,
  requests, messages, notifications, unread counts and blocked list therefore belong to one account only
  (store.js swapId, app/auth.js enterAccount/leaveAccount).
- Signup: validates username format and uniqueness against other accounts too, never loads another user, never
  touches other data; resumes the action the user started.
- Login: see UPDATE 2. Profile edits are no longer lost (the old separate profile snapshot is gone).
- Logout clears the session; protected pages stay gated when logged out; refresh keeps logged-in / logged-out state.
  A stored session without a usable profile shows the error screen (Try again now works; Log out cleans it up).
- Fixtures no longer give a new user pre-joined squads, messages written "by them", unread counts, or notifications
  claiming they host a plan. Sample people still exist, and sample requesters/replies still come only from them,
  never from real accounts.
- Saved data from the previous version is migrated on first load (logged-in user kept; logged-out saved profile
  becomes an account; pristine guest state restarts clean; old seed/malformed notifications dropped).
- A failed save (storage full) now shows a message instead of failing silently.

FILES
-----
New:      src/js/state/notify.js; src/js/components/profile/ProfileSheet.js; update-readme.txt
Modified: index.html (2 script tags); README.md (3 lines);
  src/js/state/store.js (schema, account helpers, migration, save warning), selectors.js, mockSim.js;
  src/js/data/notifications.js, chats.js, plans.js (fixtures); src/js/app/actions.js, auth.js, events.js;
  src/js/components/auth/AuthGate.js, common/NotificationSheet.js, squads/GroupChat.js, GroupList.js,
  JoinRequestSheet.js, MediaSheet.js, ui/overlay.js, ui/avatar.js; src/js/utils/media.js; src/js/pages/settings.js;
  src/styles/pages.css (join-request strip, Maps link); tests/e2e.test.js (rewritten).
Removed:  stray file "quads#Uf022" (pasted git-grep output, not part of the app).
Not changed: design system, routing, existing pages, plan detail page's own "Who wants in" list.


=====================================================================
UPDATE 2 - REAL GOOGLE SIGN-IN, ONBOARDING RESUME, BHOPAL LOCATION CONSISTENCY
=====================================================================
Tested: `npm test` = 169 checks, all executed and passing, on a simulated DOM; `npm run build` OK; every script
passes `node --check`. NOT tested: a real Google popup, a real browser, real geolocation, real device storage limits.
In the tests Google's popup and its two token endpoints are replaced by a scripted test double of the PROVIDER; the
app code is the real code. Please do one manual run with your client ID before release.

ROOT CAUSES FOUND
-----------------
1. "Continue with Google" was a timer animation: it never contacted Google, showed "Welcome back" without verifying
   anything, and the on-device "Choose an account" list let anyone open any stored profile with no authentication.
2. The profile was created only at the very end of onboarding, so there was no "incomplete profile" to resume.
3. Locations: six cities were selectable but only Bhopal localities/coordinates existed (in two different files);
   any GPS fix, even 800 km away, was used for distances; fixed sample distances (and invented 0.5 / 0.2 km values on
   new plans) were shown as if measured; "near you" pings ran without any known position; onboarding hardcoded
   "Bhopal" on any location hit; plans carried no city and nothing checked locality vs city.

AUTHENTICATION (src/js/app/auth.js, components/auth/AuthGate.js, config.js, index.html)
---------------------------------------------------------------------------------------
- Real Google Identity Services (OAuth token popup, account picker forced each time). The sign-in:
  1. "Signing you in..." - Google popup.  2. "Verifying your account..." - the token is checked with Google's
  tokeninfo (must have been issued to THIS app's client ID) and userinfo (same person); an email Google does not
  report as verified is refused.  3. "Checking your profile..." - look up the profile saved for Google's stable id
  ("sub").  4. new person only: "Setting up your profile..." - one record is created, onboarding not done.
  Each message shows only while that step runs; no artificial delays; no fake success screens.
- New user -> onboarding (name prefilled from Google) -> profile saved -> Home. The profile is marked complete only
  after the save succeeded; if saving fails, an error is shown and they can retry (no duplicate record).
- Returning + complete -> Home (or the action they started). Returning + incomplete -> onboarding at the saved
  step with the data already entered; refreshing mid-onboarding does the same. An unfinished profile cannot reach the
  app (Home/other routes show onboarding); "Sign out" is offered instead of "Back to browsing".
- Errors with their own message and Try again: cancelled/closed popup, access denied, blocked pop-up, provider
  failure, offline, unverified email, wrong client, profile lookup failure (nothing is created), profile save failure.
  Double clicks are ignored while signing in; a 2-minute cap prevents an endless loading state; closing the sheet
  discards a late answer.
- Missing/empty client ID -> "Google sign-in isn't set up" (no sign-in, nothing simulated). Google script not
  loaded -> "Couldn't reach Google".
- One Google account = one profile (keyed by sub); repeated sign-in never duplicates it. Accounts stay separate on
  the device (previous update's per-account data swap). Logout clears the live session. No demo account anywhere.
- Removed the device "Choose an account" list (it granted access without authentication).
- Profiles saved by the previous version have no Google id. They stay on the device and are NOT reachable by
  clicking; after a Google sign-in the person may "Link an existing profile" (once) or create a new one.
- Email verification: Google accounts are accepted only when Google reports the email verified; no second email is
  sent. The project has no email/password system, so none was added.
- Session persistence: the signed-in profile persists on this device (localStorage) across refresh/reopen. There is no
  server session, so Google tokens are used once and discarded, and sessions are not shared across devices.

LIMITS (honest)
---------------
Without a backend, identity is checked in the browser against Google's endpoints and profiles live in localStorage:
this is not tamper-proof against someone with access to the device's browser storage, and usernames are unique per
device only. A real multi-user product needs a server that verifies the Google token and stores profiles in a database.
That is outside this fix; the code is structured so account lookup (by sub) can be swapped for an API call.

CONFIGURATION STILL REQUIRED
----------------------------
Create a Google OAuth *Web application* client ID, add your site origins (localhost and your Pages URL) as Authorized
JavaScript origins, and put the ID in src/js/config.js (googleClientId). Then test sign-in once in a browser.

LOCATION (data/locations.js new; utils/geo.js, constants/options.js, state/selectors.js,
 pages/create.js, outside.js, home.js, explore.js, detail.js, settings.js, components/plans/planCard.js,
 onboarding/steps.js + Onboarding.js, profile/EditProfileSheet.js, app/actions.js, utils/discovery.js)
--------------------------------------------------------------------------------------------------------
- One shared source: data/locations.js lists cities with state, centre, radius, and localities WITH coordinates.
  CITIES, LC, localitiesOf, cityOfLoc, isCity, cityLabel derive from it. Only Bhopal, Madhya Pradesh is listed, so
  onboarding, profile editing and every other selector offer only Bhopal. Adding a city later = one more entry.
- Locality choosers (Create plan, Still Outside) list only the signed-in person's city's localities; posting
  checks the locality belongs to that city; new plans store their city; onboarding and profile saves reject a city
  that isn't supported. "Use my location" in onboarding sets the city from the nearest supported locality.
- Distances: computed only from a real position inside a supported city to a locality with coordinates; otherwise
  nothing is shown (no invented numbers; the fixed sample distances and the 0.5/0.2 km defaults are no longer used).
  A GPS fix outside every supported city is refused with a message and not stored. "Near you" pings need a real position.
- Discovery (vis) shows only plans whose city is supported (and the viewer's city); plans with unknown/legacy places are
  kept in saved data but not offered.
- People whose saved city is unsupported (older data) keep it untouched; Home/Discover show a notice with
  "Choose a supported location", and the profile editor explains and only allows supported choices.
- Privacy unchanged: position is requested only when the person taps a location button, stored rounded (~1 km), never
  shown to others; denied/unavailable cases show messages.

FILES (this update)
-------------------
New:      src/js/config.js; src/js/data/locations.js
Modified: index.html; README.md; .env.example; update-readme.txt; tests/e2e.test.js;
  src/js/app/auth.js, actions.js, events.js; src/js/components/auth/AuthGate.js, onboarding/Onboarding.js, steps.js,
  profile/EditProfileSheet.js, plans/planCard.js; src/js/constants/options.js; src/js/pages/create.js, outside.js,
  home.js, explore.js, detail.js, settings.js; src/js/state/store.js, selectors.js; src/js/utils/geo.js, discovery.js
Build/deploy setup (package.json, scripts/, .github/workflows) is unchanged and still works.


=====================================================================
UPDATE 3 - FEEDBACK & REVIEWS
=====================================================================
Tested: `npm test` = 212 checks (169 earlier checks for auth/onboarding/location/join/media + the new feedback suite), all
executed and passing on a simulated DOM; `npm run build` OK; all scripts pass `node --check`. Not tested in a real
browser / on a phone.

AUDIT (what existed)
--------------------
- components/squads/FeedbackSheet.js: anonymous per-person tags + "hang out again", opened only for the host right after
  "Wrap it up". Plan lifecycle is status open | cancelled | ended; end() is the only place a plan ends.
- Problems fixed rather than duplicated: one plan-wide flag (p.fbDone) meant the first person to submit stopped everyone
  else from ever being asked; submitting wrote counters straight into OTHER people's profiles with no record of who
  reviewed whom (so duplicates, self-review and non-participants could not be refused); "Didn't show" could be tapped
  repeatedly by anyone; no meetup rating existed.

ELIGIBILITY RULE (attendance is not tracked by the app, so this is explicit)
----------------------------------------------------------------------------
Feedback is open only when (1) the host has wrapped the plan up (status 'ended'; never open/future or cancelled plans),
(2) the person was an accepted member at that moment (p.roster, snapshotted by end()), (3) the host has not marked them
"Didn't show", (4) at least two people were in the squad, (5) they are signed in. Leaving the squad afterwards does not
remove eligibility. Plans ended by the previous version have no roster: if they were already reviewed (p.fbDone) nobody is
prompted again, otherwise the current members are used.

TWO KINDS OF FEEDBACK (state/feedback.js, persisted in S.feedback)
-------------------------------------------------------------------
A. Meetup feedback (new): 1-5 stars (required), any of six tags (Felt safe, Friendly vibe, Fun experience, Good
   communication, Well organized, Would meet again), optional comment (max 500 chars). One per person per plan. Stored with
   plan id, reviewer, rating, tags, comment, timestamp.
B. Individual review (existing sheet, reworked onto records): optional tags + "hang out again" about another participant.
   One per reviewer + plan + person; only for other eligible participants; self-reviews and non-participants are refused in
   the save function (not just hidden in the UI). Offered after the meetup form, or later from the plan page.
Revisions/edits are not supported; submitted feedback is final.

WHERE IT APPEARS
----------------
- Host wrapping up a plan: feedback form opens; every other participant gets a notification ("How was ...?") that opens the
  plan page (existing notification system/routing, no new one).
- Home: "How was ...?" cards for plans still awaiting your feedback, with "Give feedback" and "Later".
- Plan page of an ended plan: "How was it?" -> after sending: "Feedback sent" + optional squadmate reviews + anonymous totals.
- "Later" hides the prompt for 24h without marking anything submitted; it stays reachable from the plan page. Submitted =
  a stored record exists, and only then do prompts stop.
- Profile feedback totals are now computed from stored reviews (plus a person's pre-existing sample totals) instead of
  being written into their profile.

FORM STATES (components/squads/FeedbackSheet.js)
------------------------------------------------
Star group (keyboard/ARIA radio), multi-select tag chips, optional textarea; missing rating -> clear message; "Sending..."
state with controls disabled and double-submit ignored; success screen; save failure -> understandable error, all answers
kept, button becomes "Try again", and nothing partial is stored; closing the sheet during sending does not reopen it.

PRIVACY DECISIONS
-----------------
The product text already promised anonymous, totals-only feedback, so that is kept: reviewer ids are stored only to enforce
rules (duplicates/self/eligibility) and are never displayed. Written comments are never shown to anyone else (not even the
host). Plan totals (average, response count, top tags) appear only to participants/host and only once 3+ people answered.
No public star ratings for people, no reviewer names. Existing Report actions are unchanged and reused.

BUG FOUND AND FIXED WHILE TESTING
---------------------------------
store.js swapId re-labelled members/creator/requests on sign-out but not the new roster / noShows lists, which would have
made the next signed-in person look like a participant. Now covered, with a regression test.

FILES (this update)
-------------------
New:      src/js/state/feedback.js
Modified: index.html; update-readme.txt; tests/e2e.test.js; src/styles/pages.css (stars);
  src/js/app/actions.js (end, feedback actions, no-show), auth.js (per-account "later" state), events.js;
  src/js/components/squads/FeedbackSheet.js; src/js/components/profile/trust.js; src/js/constants/options.js (tags);
  src/js/utils/icons.js (tag icons); src/js/pages/detail.js, home.js; src/js/state/store.js (feedback data, swapId)
Not changed: authentication, onboarding, location/distance logic, build and deploy setup.

KNOWN LIMITATIONS
-----------------
- Data lives in this browser's storage like the rest of the app: not server-enforced, readable by someone with access to the
  device's storage, and feedback does not sync between devices. Real enforcement needs a backend.
- Attendance is inferred (see rule), not verified; hosts' "Didn't show" is the only attendance signal.
- No editing/deleting of submitted feedback; no moderation queue for comments (they are private to the author).


=====================================================================
UPDATE 4 - OPTIONAL INDIVIDUAL MEMBER RATINGS & FAIR REPUTATION
=====================================================================
Tested: `npm test` = 226 checks, all executed and passing on a simulated DOM (no real browser, no phone, no second real
device); `npm run build` OK. Not tested: real browser rendering/touch targets, screen readers, multi-device sync (impossible: data is
local).

AUDIT RESULT (the zip already contained UPDATE 3, so this builds on it instead of redoing it)
-----------------------------------------------------------------------------------------------
Already correct and kept unchanged: plan lifecycle (feedback only after the host wraps a plan up; never open/future or cancelled
plans), eligibility from the roster snapshot minus host-marked no-shows, one meetup rating per person per plan, in-app prompts on Home /
plan page / notification (sent once, at wrap-up), anonymous totals shown only once 3+ answered, comments never displayed.
Gaps against the feedback brief that this update closes:
1. Individual reviews had no star rating or note and were only tags + "hang out again"; nothing could be averaged.
2. The review sheet listed EVERY squadmate with inline controls; there was no "pick who you want to review" step.
3. Sample people carried invented review totals (users.js `fb`: counts, tags, "again" numbers) that were shown on profiles as if real.
4. Profile showed tag counts and a "% would hang out again", never a rating and count; no neutral "not rated" state.

WHAT CHANGED
------------
Flow (components/squads/FeedbackSheet.js, app/actions.js):
- After the meetup rating: "Anyone you'd like to review? Share a quick rating for people you interacted with. You don't need to rate
  everyone." with "Rate members" and "Skip for now". Skipping stores nothing and has no effect on anyone.
- Step 1 (pick): other eligible participants as selectable cards (avatar + name; nobody preselected, you are never listed). Continue is
  disabled until at least one person is picked. The host's "didn't show" action stays here.
- Step 2 (rate): only the picked people, on one compact screen: 1-5 stars (required), optional tags (Friendly vibe, Respectful,
  Good communicator, Made everyone feel welcome, Would meet again, Reliable), optional note (300 chars). Back/forward keeps everything typed.
- Send is all-or-nothing: a picked person without stars blocks sending with a message (nothing stored); a failed save keeps all input
  and offers "Try again"; double taps are ignored while sending; success is only shown after the write succeeded.
- Plan page of an ended plan: "Your rating: N", "Member reviews: x of y sent (optional)" (or "You skipped them for now") and a single quiet
  "Rate members / Review more members (optional)" button while anyone is left. No repeated prompts: the Home prompt only concerns the group rating.

Data (state/feedback.js; persisted in S.feedback, localStorage key squado-v5):
  meetup  { id, kind:'meetup', planId, by, rating, tags[], comment, at }
  person  { id, kind:'person', planId, by, to, rating 1-5, tags[], comment, at }
Records from before this update (tag-only, with `again`) are kept: their tags still count, but with no rating they are never in the average.
Group and individual records are different kinds and are never mixed in any calculation.

Rules enforced inside fbSavePeople (not only hidden in the UI): signed in, plan ended, reviewer on the roster, target on the roster and
not a no-show, target is not the reviewer, rating is a number 1-5, one record per reviewer + plan + person (a repeat returns 'duplicate',
nothing is changed; there is no editing), tags filtered to the allowed list, note trimmed and capped, notes rendered escaped.

REPUTATION (fbAgg / fbs in profile/trust.js)
--------------------------------------------
- average = plain mean of the star ratings people gave that person, rounded to one decimal; count = number of those ratings. Example: 4.7 ★ · 12 ratings.
- Computed from stored records only. Invented sample totals were removed from the fixtures and from new guest profiles.
- Shown from 3 ratings on, because reviews are anonymous and 1-2 ratings would reveal who wrote them. Below that: "Not rated yet" (0) or
  "Not enough ratings to show yet" (1-2). Never a zero, never a penalty, never "untrustworthy" wording.
- Skipping reviews changes nothing for the reviewer or for people they did not rate. Belonging to a bigger squad adds nothing.
- Meetup (group) ratings are not part of anyone's reputation. Safety reports stay the existing Report/Block flow; there is no safety tag.

FILES (this update)
-------------------
Modified: src/js/state/feedback.js; src/js/components/squads/FeedbackSheet.js; src/js/components/profile/trust.js;
  src/js/app/actions.js, events.js; src/js/constants/options.js (individual tags); src/js/utils/icons.js (one tag icon);
  src/js/data/users.js and state/store.js (removed invented review totals); tests/e2e.test.js; update-readme.txt
Not changed: design system / CSS (existing .opt, .chip, .stars, .card, .pill reused), auth, onboarding, location, chat, routing, build/deploy.

HOW TO TEST
-----------
`npm test` (suite "feedback & reviews"), `npm run build`. Manually: sign in, host a plan, get one member in, "Wrap it up", send the group
rating, pick one member, rate, refresh, open that person's profile after 3 ratings exist (needs 3 different real accounts on a device).

PERSISTENCE AND WHAT IS STILL NEEDED (honest)
---------------------------------------------
This project has NO Firebase and no backend: data lives in this browser's localStorage, per device. Feedback does not sync across devices,
eligibility/duplicate/self-review rules run in the browser and can be bypassed by someone editing local storage, and reviewer ids are stored
(never displayed). Real shared reputation needs: a database (e.g. Firestore if you choose it later), server-side or Security-Rules checks for
the same rules (authenticated reviewer; reviewer and target both in the plan's roster; plan ended; reviewer != target; rating 1-5; one document
per reviewer+plan+target, e.g. id `${planId}_${reviewer}_${target}`; clients may not write aggregates), and aggregates computed on the server.
Attendance is not verified: the roster is "accepted members when the host wrapped up" minus host-marked no-shows.
No push notifications or background jobs exist; only the in-app prompts/notifications described above. No editing or deleting of submitted reviews.


=====================================================================
UPDATE 5 - GOOGLE SIGN-IN: DIAGNOSIS, DIAGNOSTICS AND LOCAL TESTING
=====================================================================
Tested: `npm test` = 239 checks (226 earlier incl. the whole feedback system + 13 new), all executed and passing; `npm run build` OK.
The tests replace Google's popup and token endpoints with a scripted double. THAT DOES NOT PROVE REAL GOOGLE SIGN-IN WORKS. I had no
browser, no network access to Google and no credentials, so a real login was NOT performed. You must do the manual test below.

SOURCE ZIP NOTE: no new ZIP was attached to this request (only the original upload was present), so I worked from the previous
returned project (feedback system included). If your local copy differs, tell me.

AUDIT (app/auth.js, components/auth/AuthGate.js, config.js, index.html, store.js)
-------------------------------------------------------------------------------
- Library: Google Identity Services token client (https://accounts.google.com/gsi/client, loaded async in index.html). initTokenClient +
  requestAccessToken, then the token is verified with Google's tokeninfo (audience must equal our client ID) and userinfo (verified email).
  The architecture is sound and was kept. No mock/dev login exists anywhere in the shipped code, and none was added.
- Client ID comes from src/js/config.js, read at click time (no timing problem). Session = profile in localStorage keyed by Google "sub".
ACTUAL CAUSE
  1. src/js/config.js ships with googleClientId: '' . With an empty ID the app (correctly) shows "Google sign-in isn't set up" and never opens
     Google. This is the reason sign-in does nothing. Because config.js is part of every ZIP, each newly extracted ZIP would reset it to empty
     again, so the ID had to be re-entered every time.
  2. Contributing, code side: failures that happen inside Google's own window (origin_mismatch, invalid_client) are reported to the page only as
     "window closed", which the app presented as a plain cancel, hiding the real reason; a malformed ID was sent to Google unchecked; clicking before
     Google's async script finished loading was reported as "check your connection".
  3. Contributing, environment: Google's popup cannot open inside VS Code's embedded Live Preview panel (reported as pop-up blocked).
  Not verifiable by me: whether your Google Cloud client has http://127.0.0.1:3000 registered, which only you can check.

WHAT CHANGED
------------
- app/auth.js: client ID is trimmed and format-checked (*.apps.googleusercontent.com) before anything is sent to Google; on 127.0.0.1/localhost
  ONLY, a device-local fallback ID (localStorage key squado-dev-google-client-id) is used when config.js is empty (config.js wins; ignored on any other
  host, so it cannot be a production bypass); file:// pages get a specific message; the page waits up to 5 s for Google's script with a visible
  "Connecting to Google..." step instead of reporting a network error; closing the sheet during that wait cancels cleanly; removed an unused stale
  `fb` counter object from newly created profiles. The Google flow, identity checks, session, onboarding and logout code are untouched.
- components/auth/AuthGate.js: new diagnostics: not-set-up / malformed ID screens show the exact origin to authorize and (local hosts only) a field to paste the
  ID; cancelled / failed / blocked screens add "if Google showed origin_mismatch or invalid_client, authorize <origin>"; blocked pop-up text mentions
  embedded previews.
- state/store.js (O.dev), app/events.js (two actions), config.js (comment), README.md, update-readme.txt, tests/e2e.test.js.
- Not changed: design/CSS, onboarding, profile, plans, chat, notifications, feedback/ratings, routing, build and deploy.

WHAT YOU NEED TO DO IN GOOGLE CLOUD CONSOLE (I cannot do this, and have not)
--------------------------------------------------------------------------
1. console.cloud.google.com > select/create a project > APIs & Services > OAuth consent screen: set it up (External). While publishing status is "Testing",
   add the Google accounts you will sign in with under Test users.
2. APIs & Services > Credentials > Create credentials > OAuth client ID > Application type: Web application.
3. Authorized JavaScript origins > Add URI: http://127.0.0.1:3000   (exactly; no /index.html, no ?vscode-livepreview=true, no trailing slash).
   Also add http://localhost:3000 only if you will use that spelling. Authorized redirect URIs are NOT needed for this popup flow.
   Production (GitHub Pages): https://<your-user>.github.io  (no repository path). Changes can take a few minutes to apply.
4. Copy the Client ID (xxxx.apps.googleusercontent.com).

HOW TO TEST THE RETURNED ZIP
----------------------------
1. Extract the ZIP to a new folder; open that folder in VS Code (File > Open Folder).
2. Start Live Preview (Show Preview Server), and note the address in its status bar. Your known one: http://127.0.0.1:3000
3. IMPORTANT: use the external browser (Live Preview: "Open in Browser", or paste http://127.0.0.1:3000/index.html in Chrome/Edge). The embedded VS Code panel
   cannot open Google's popup. Allow pop-ups for 127.0.0.1.
4. Confirm the origin: it is scheme + host + port of the address bar, e.g. http://127.0.0.1:3000. If Live Preview picked another port (3001...), that
   is a different origin: either change the port in the Live Preview settings (livePreview.portNumber) back to 3000, or add the new origin in Google Cloud.
   Opening via localhost instead of 127.0.0.1 is also a different origin.
5. Add the client ID, either (a) in src/js/config.js: googleClientId: 'xxxx.apps.googleusercontent.com' (stays in that copy only; re-add after each new ZIP), or
   (b) click Continue with Google, and in the "isn't set up" screen paste the ID and Save ID. (b) is kept for that origin, so later ZIPs served at the
   same origin need nothing. "Remove saved ID" clears it.
6. Click Continue with Google. Expect: "Signing you in..." > Google account chooser > "Verifying your account..." > new person: onboarding (name prefilled);
   returning with finished profile: Home; unfinished profile: onboarding at the saved step. Sign out and sign in again to check restoration.
7. If something fails, the message tells you why: "isn't set up" (no ID), "looks wrong" (bad format), "Pop-up blocked" (browser/embedded preview), "Sign-in
   cancelled" + origin hint (window closed or Google showed origin_mismatch / invalid_client / access_denied for a non-test user), "Couldn't sign you in"
   (token not issued to this client ID). Browser DevTools console/network show Google's detail.

VERIFIED BY AUTOMATED TESTS (against a scripted Google double): missing ID, malformed ID, local-only fallback and its isolation from other hosts,
origin text without path/query, file://, late-loading Google script, cancel/blocked/denied/failed/network/unverified/wrong-audience handling, new user
onboarding, returning and incomplete-onboarding resume, logout/re-login, no duplicate accounts, feedback system after sign-in, full regression suite, build.
NOT VERIFIED (needs you): a real Google popup and token exchange, your Cloud Console origin/consent-screen/test-user configuration, GitHub Pages origin,
real browser/popup-blocker behaviour.


=====================================================================
UPDATE 6 - QR ATTENDANCE, COMPLETION VERIFICATION, ATTENDEE-ONLY FEEDBACK
=====================================================================
Tested: `npm test` = 296 checks, all executed and passing on a simulated DOM with scripted camera / Google doubles; `npm run build` OK.
NOT tested (impossible here): a real phone camera scanning a real QR code, real QR rendering (library loads from a CDN; the test uses a stub), real
camera permission prompts, jsQR/BarcodeDetector decoding, the deployed GitHub Pages URL, two real devices.

THE BIG LIMITATION: this project has no backend (localStorage per browser, Google sign-in only identifies the person). A QR code scanned on ANOTHER phone opens
Squado there, but that phone has no copy of the meetup, so it shows "Meetup not found on this device". All the rules are implemented and enforced in one
trusted module, and the full flow works for accounts on the same device/browser (what the tests exercise), but real multi-phone check-in cannot work until the data
is shared. Required for that (not invented here): a shared database (e.g. Firestore), the same checks run server-side or in Security Rules (authenticated user;
user is a plan member; token matches an open, unexpired, unrevoked session of THAT plan; one attendance doc per plan+user, e.g. id `${planId}_${uid}`; server timestamp;
only the organizer writes manual marks/sessions/completion; feedback writes require attendance verified + plan completed), and server-computed stats.

AUDIT (before changes): no attendance records, no QR, no completion rules. The organizer's "Wrap it up" completed the plan immediately and made EVERY member eligible
for feedback; "didn't show" was a separate list plus a counter; profile numbers were counters incremented in actions (joined/completed went up for everyone on wrap-up).
There is no machine-readable meetup date/time (`when` is free text), so no state is derived from the clock. Manual attendance existed only as that "didn't show" mark; it is
kept, now as an absent attendance record.

WHAT WAS ADDED / CHANGED
- state/attendance.js (new): sessions (secure random 128-bit token, expiry, close, rotation with revoked-token detection), attCheck / attCheckIn (single validation for
  both scan routes), attClaim, attManual (audited, idempotent), completion (compHost / compMember / compSettle, lifeState), attUrl (deployed https base only), relOf (derived stats),
  all writes via attTxn (all-or-nothing, rolled back if the save fails).
- components/squads/AttendanceSheet.js (new): organizer panel, QR sheet, check-in page (route #/checkin/<plan>/<token>), in-app scanner with fallbacks, status/lock messages.
- state/feedback.js: eligibility = completed plan + verified attendance (replaces the old roster snapshot and noShows list). Roster/no-show data on old plans is not used.
- app/actions.js: `end` now = organizer confirmation under the completion rules (notifications once per person); `noshow` = absent record; actions wired in.
- app/router.js, pages/detail.js (panel), components/squads/FeedbackSheet.js (lock reason), components/profile/trust.js + ProfileSheet.js + pages/profile.js (derived stats),
  app/auth.js (sign-in wrappers), app/events.js, state/store.js (S.attendance, identity swap on sign-out/in), config.js, index.html (two CDN scripts: qrcode-generator, jsQR), tests, README.
- Not changed: design/CSS (existing classes only), auth flow, onboarding, chat, join requests, notifications system, build/deploy.

RULES AS IMPLEMENTED (see README for the user-facing version)
- Records are unique per (plan, person); manual marks and scans update the same record; every change is appended to its audit trail.
- Check-in is refused for: guests, unknown/cancelled/completed plans, no session, malformed/wrong/other-plan/revoked tokens, closed or expired sessions, non-members. A duplicate scan is a no-op.
- A scan by someone the organizer marked absent becomes a dispute, never an override. Disputed or merely claimed attendance does not unlock feedback.
- Completion needs organizer confirmation + `completionConfirmations` verified attendees (default 1; capped by how many exist; 0 = organizer alone; nobody else verified = organizer alone).
  Organizer confirmation never marks anyone present; an attendee confirmation never completes it by itself. A dispute by a verified/claimed attendee blocks completion until withdrawn or corrected by the organizer.
- Notifications: attendees are asked once to confirm; verified attendees are told once when feedback opens. No new notification system.
- Stats: relOf() derives hosted / joined / attended / organized / absent from records (idempotent). Reliable badge uses attended. Legacy `rel` counters are no longer used for real accounts (except `cancel`, which counts leaving/cancelling).
- Plans completed BEFORE this update have no attendance records, so nobody is eligible for feedback on them until the organizer marks attendance by hand (nothing was fabricated).

HOW TO TEST LOCALLY
1. `npm test`, `npm run build`.
2. Manual (one browser): set `appBaseUrl` in config.js to your deployed https address (QR codes are refused otherwise). Create a plan, get a second account accepted
   (use a private window with a different Google account on the same origin? NO: data is per browser profile, so use two accounts signing in/out in the same browser).
   Host: plan page > Start check-in > QR. Sign out, sign in as the member, open the printed/copied link or use Scan QR (camera needs https or localhost) > Check me in.
   Sign back in as host > Confirm it ended; as the member > Yes, it happened; then give feedback.
3. Real phone: only meaningful once shared persistence exists (see above).



UPDATE 7 - SECTION 01: AUTHENTICATION, ROUTE PROTECTION AND PRIVACY
AUDIT (baseline: build OK, 296 tests passing). Gaps found: protected actions (user, members, attachments, react, remove, cancel,
leave, nextGo, media actions) ran for anyone who could fire a data-a; guests saw member/attendee avatars with names; removal only
filtered p.members so the person could ask again; a rejected request notified the requester; a stored profile counted as a session;
the intent replay used unvalidated hashes and auto-sent join requests and auto-published plans; posted/members/etc. threw on bad ids;
no render error boundary; mock chat replies could land after sign-out; old notifications could preview private squads.
CHANGES: new state/access.js, app/guards.js, components/common/AccessFallback.js; router rewritten around a route table;
auth.js (session marker, onboarding resume clamp, safe replay, account-switch/sign-out clearing); actions.js (membership rules,
silent reject, permanent remove, voluntary leave); plan/event/card/chat/list/notification views made access-aware; tests updated and 58 added (356 total).
DECISIONS: rejection is silent; removal is per-squad and permanent; leaving may re-request; join resumes at the confirmation sheet.
NOT VERIFIED: real Google sign-in, real browsers/devices, bfcache and cross-tab behaviour (simulated only), camera.
REVIEW FIX (Section 01): the 700 ms Home/Discover loading timer is now started only after the page builds, and only once, so a page
that throws renders once instead of queueing repeated renders (a deliberate throw used to print 23 traces). The test runner now always
ends with one "RESULT:" line and a real exit code, reports a crash or hang (300 s watchdog) as a failure, and captures the expected
error in the error-boundary test instead of printing it.


UPDATE 8 - SECTION 02: GROUP MEMBERSHIP LIFECYCLE (frontend only, temporary local state)
TEST RUNNER: the reported stall after ~298 assertions could NOT be reproduced (fresh extraction, 3 runs, exit 0, ~56 s; the original 298
assertions finish at ~37 s). Cause unconfirmed; a wall-clock limit in the runner used is a hypothesis, not a finding. Added: a stall
detector (45 s without a finished assertion fails the run and names the last completed test). A time-scaled fast mode was tried and
removed: it broke the test that measures real elapsed time inside the app.
MODEL: new state/membership.js is the only place membership changes (request, approve, reject, withdraw, leave, remove), with
preconditions, idempotence, a history log (plan.mlog) and deterministic reconciliation. Existing lists kept; mapping in README.
CHANGES: handlers, join check and sample-request simulation use the module; capacity validated (2-8) and unique plan ids on creation;
host notified once when a member leaves; Groups no longer has a "Waiting on the host" section; Profile never had "My Squads";
swapId relabels plan.mlog (found by an existing test).
TESTS: 441 total (356 before + 85 new: 84 S02 tests, plus one existing test split in two). Mutation check: five deliberate breakages (removal not permanent, capacity ignored, leave recorded
as removal, stale simulated reply unguarded, reject on non-pending) each made the suite fail.
NOT VERIFIED: real browsers/devices, real Google sign-in, cross-device or concurrent behaviour (not possible with local state).


UPDATE 9 - SECTION 03: GROUP CHAT AND MEDIA (frontend only, local messages)
BASELINE (fresh extraction of squado-section02.zip): build OK (67 scripts), 70 JS files pass node --check, 441 passed / 0 failed, exit 0, ~78 s.
The three earlier-reported failures (nav structure, plan route stops, Groups active/unread) are covered by existing tests that pass here; not reproduced.
FOUND AND FIXED: leaving an open squad incremented the reliability cancellation counter (and the Section 02 test asserted that); extra route segments
were ignored (#/gc/abc/../xyz opened abc); the unread total summed raw/stale/negative values and inaccessible squads; gallery had no type allowlist or size limit
(SVG passed image/*) and its async callback was not re-authorized; Enter during IME composition sent; chat height relied on 100dvh only (iOS keyboard).
CHANGES: unreadFor/unreadTotal/unreadSanitize, mediaValidate, config chatMaxLen/maxImageMB/imageTypes, app/viewport.js (--vvh), empty-conversation state, strict route shape.
TESTS: 503 total (441 + 62 S03). Mutation check: seven deliberate breakages (counter increment, no type check, unread ignores access, unauthorized gallery callback,
no length clamp, extra route segments, IME Enter) each made the suite fail. Existing assertions kept; one S02 assertion that encoded the counter bug was corrected.
NOT VERIFIED: real browsers/phones (keyboard, camera, file picker, themes), real Google sign-in, cross-device behaviour.
