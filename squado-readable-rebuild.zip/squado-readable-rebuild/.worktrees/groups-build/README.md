# Squado

Find people who are still down. **Plans, not events. Squads, not attendees.**
Squado is a social planning web app built around spontaneous real-world plans (Navratri-flavoured: garba, pandal hopping, bhandara, chai, "Still Outside?").

## Features
- Browse as a guest: Home, Discover (filters + search, Live Now), plan details, event details.
- "I'm Down" (join request to a small squad) and "I'm Going" (events), with host review flow, capacity, Girls-only / Boys-only plans.
- Real "Continue with Google" (Google Identity Services, needs a client ID, see Google sign-in setup) → onboarding for new users (resumes if unfinished), straight in for returning users, then back to the exact action the user started. Each account has its own squads, requests and notifications.
- 6-step onboarding (name, username, location, gender, age group, optional interests) with progress.
- Create Plan (day, time, approximate place, squad size, who can join, host controls, live preview), Still Outside flow, plan continuation ("Tonight's route"), Groups tab (squad list with last message, unread and plan context; full-screen chat on mobile, list | conversation on desktop), meetup feedback + optional anonymous member ratings, report/block/leave/cancel with confirmations, notifications.
- Poppins + Lucide icons (coloured by semantic tokens) + Twemoji for expressive emoji, light/dark theme, theme-aware opaque surfaces, fixed stroke-only doodle wallpaper, responsive bottom-bar / sidebar navigation, motion that respects `prefers-reduced-motion`.

## Tech stack
Plain HTML + CSS + JavaScript (no framework, no bundler, **zero npm dependencies**). Node ≥ 18 is only used for the dev server, build check and tests.
Runtime CDN assets (pinned): Lucide `0.469.0` (jsDelivr), Twemoji `15.1.0` SVGs (jsDelivr), Poppins (Google Fonts).

## Install / develop / build
```bash
npm install        # no dependencies; creates nothing but keeps tooling consistent
npm run dev        # http://localhost:5173  (PORT=… to change)
npm run build      # verifies every referenced file + JS syntax, outputs dist/
npm run preview    # serves dist/
npm test           # end-to-end flow test (simulated DOM)
```

## Project structure
```
index.html                 script/style manifest (load order matters: plain scripts share one scope)
public/assets/             logo, favicon, official Google "G" mark
src/styles/                base · icons (icon colour tokens) · doodle · nav · pages (motion, auth states)
src/js/
  constants/               activities + interests, form option lists
  data/                    users · plans · events · notifications · chats (sample content) · locations (cities, localities, coordinates)
  state/                   store (S/O + localStorage, per-account identity), access (who may see/do what), membership (the squad lifecycle), selectors, chat, notify (per-person notifications + routing), mockSim (sample people)
  utils/                   icons (Lucide/Twemoji system), helpers, time, geo, discovery, validate, photo
  components/
    ui/ common/            avatar, toast/modal/confetti, chips; DoodleBackground, NotificationSheet
    navigation/            navigationConfig (shared items) + Navigation (one responsive <nav>)
    auth/ onboarding/      AuthGate (Continue with Google, loading, success); step renderers + Onboarding
    plans/ events/         planCard, nightRoute; eventCard
    squads/                GroupList, GroupChat (+ options/info sheets), FeedbackSheet
    profile/ safety/       trust badges + EditProfileSheet; ConfirmSheet
  layouts/                 AppLayout (shell)
  pages/                   home, explore, create, outside, posted, detail, event, groups (list | chat), profile, settings
  app/                     router, actions, auth (frontend-only auth + intent preservation), guards, events, viewport (chat keyboard height), boot
tests/e2e.test.js          flow tests (guest → auth → onboarding → intent replay, create plan, search, confirmations, quality gates)
scripts/                   dev-server.js, build.js
```
There is no `hooks/` folder: without React there are no hooks; shared logic lives in `state/` and `utils/`.

## Google sign-in setup
1. Google Cloud Console > APIs & Services > Credentials > Create OAuth client ID > *Web application*. (First time: configure the OAuth consent screen; while it is in "Testing", add your Google account under *Test users*.)
2. Under *Authorized JavaScript origins* add every origin you use. An origin is scheme + host + port only, with no path and no query:
   - local (VS Code Live Preview): `http://127.0.0.1:3000` (use `http://localhost:3000` too if you ever open that spelling; they are different origins)
   - GitHub Pages: `https://<your-user>.github.io` (never `/repo-name`)
3. Put the client ID (ends in `.apps.googleusercontent.com`; public, not a secret) in `src/js/config.js` (`googleClientId`).
   On `127.0.0.1` / `localhost` only, you can instead paste it into the "Google sign-in isn't set up" screen: it is stored in that origin's local storage, so a freshly extracted copy of the project served from the same origin keeps working. `config.js` wins when both exist. This fallback is ignored on every other host.
Until an ID is set, "Continue with Google" says sign-in isn't set up; nothing is simulated. See update-readme.txt (UPDATE 5) for local testing steps and troubleshooting.

## QR attendance, completion and feedback
Chain: **membership -> attendance record -> completion -> feedback eligibility -> ratings / profile stats** (code: `state/attendance.js`, `state/feedback.js`, `components/squads/AttendanceSheet.js`).
- **Configure** in `src/js/config.js`: `appBaseUrl` = your real deployed https address, e.g. `https://<user>.github.io/<repo>/` (include the repo path; no `#`). While it is empty, or if it is localhost / a private address / plain http, **no QR code is made**. Also `checkInHours` (default 6) and `completionConfirmations` (default 1, 0 = organizer alone).
- **Organizer** (plan page, "Attendance"): *Start check-in* shows a QR code (a link: base URL + `#/checkin/<planId>/<random 128-bit token>`, nothing personal). *Close check-in* or *New code* stops the old code at once; codes also expire.
- **Native phone camera**: the camera app reads the QR and opens that link in the phone's browser (no app install). Signed out -> sign-in -> back to the same check-in page. Opening it records nothing; the member taps **Check me in** (method `native_camera`).
- **In-app scanner** (plan page, "Scan QR to check in"): asks for the camera only after you tap, stops it when closed / after a scan, and has a paste-the-link fallback. Uses the browser's `BarcodeDetector` or the small jsQR library (CDN). Records method `in_app_scanner`.
- Both routes call the same `attCheckIn()`: signed in, plan exists and open (not cancelled / completed), token valid and not revoked, session open and unexpired, person is a squad member. One record per person per plan; repeats change nothing. Timestamps are taken by the app, never sent by a client.
- **Manual attendance** (organizer): *Present* / *Absent* per member, on the same records, with an audit trail (who, when, why) and no duplicates. A member who couldn't scan can tap "I was there": that is an unverified claim until the organizer marks them present. "Not checked in yet" is never treated as absent. A member who scans after being marked absent only opens a dispute; the organizer resolves it by marking present/absent.
- **Completion is separate**: states `scheduled`, `awaiting_completion` (check-in started), `completion_pending`, `completed`, `disputed`, `cancelled` (derived; the plan `status` stays open/ended/cancelled). The organizer taps *Confirm it ended* (marks nobody present). The plan becomes completed only when the organizer has confirmed AND `completionConfirmations` verified attendees (capped at how many there are) confirmed it, with no open dispute. A verified attendee can confirm or dispute; an organizer can resolve a dispute by correcting attendance. Silence means unverified, not absent or completed.
- **Feedback** (group rating + optional member ratings, see UPDATE 4 in update-readme.txt) only for people with verified attendance (QR check-in or organizer-marked present, not disputed) at a completed plan; checked again inside every save function. The plan page says why it is locked.
- **Profile stats** are derived from records, never incremented: hosted, joined (may include upcoming), attended (distinct completed plans with verified attendance), organized (your plans that completed), absent marks. Built-in demo profiles keep their fixed demo numbers.
- **Limits (read this)**: there is no backend. Everything lives in the browser's localStorage per device, so (1) a check-in from another person's phone cannot reach the organizer's data: real multi-device check-in needs a shared database plus server-side/Security-Rule enforcement of the same rules; (2) a person with access to the device can edit its data. See update-readme.txt UPDATE 6.

## Access control (Section 01)
One central layer decides who may see and do what; routes, pages, action handlers, notifications and sheets all ask it:
- `state/access.js`: `tier()` (guest / onboarding / ready), `membership()` (host, member, pending, rejected, removed, left), `groupAccess()`, `isAdmin()`, `joinCheck()`, `canViewProfile()`, `notifView()`, route table, safe return destinations, `clearPrivateUi()`.
- `app/router.js`: guests on protected routes go Home with the sign-in sheet; ids are validated; a page that throws becomes a styled fallback (`components/common/AccessFallback.js`).
- `app/guards.js`: every protected action is re-authorized when it runs (a hidden button is not a check); also handles back/forward-cache restores, expiring sessions and another tab switching account.
- **Session**: a stored profile is not a session. Signing in with Google writes `S.session`; without a current one the person is signed out locally (profile kept). `sessionDays` in `config.js`.
- **Intent**: a guest's attempted action is remembered (validated, 30 minutes, used once) and resumed after sign-in/onboarding. Joining re-opens the confirmation sheet; nothing is sent, published or marked automatically.
- **Membership**: accepted members only see private chat, member lists, exact spot and attachments. Pending and rejected applicants see only public info and their own status; rejections are silent (no notification). Host removal is permanent for that squad only (`plan.removed`, can't ask again, history kept); leaving by choice (`plan.left`) can ask again. The host is the only administrative role (there is no separate admin role in the project).
- Guests and non-members see anonymous avatars and counts, never member or attendee identities.
- **Limits**: these are frontend safeguards. With no backend, anyone with access to the device can edit local storage, and real enforcement (and cross-device removal, sessions, blocking) needs a server.

## Group membership lifecycle (Section 02)
Frontend-only and temporary: everything below lives in browser-local state (simulated data). It is **not shared, authoritative data**, a user can edit their own local storage, and frontend guards are **not** a substitute for backend security. The later backend phase (Supabase with Google Sign-In and PostgreSQL) must enforce the same rules authoritatively; nothing of that is integrated here.

**One module, `state/membership.js`**, is the only place a person's relationship to a squad changes. Handlers call `memRequest / memApprove / memReject / memCancelRequest / memLeave / memRemove`; each checks its preconditions, changes nothing when refused (so repeated, stale or forged actions are harmless and idempotent), and records the transition in `plan.mlog` (history only, never used to grant access). `memReconcile` repairs conflicting or invalid records on load and on every render.

| Lifecycle state | Stored as | Meaning |
|---|---|---|
| accepted | `plan.members` | approved member; the host (`plan.creator`) is always accepted |
| pending | `plan.reqs` | asked to join, awaiting the host; **not** a member |
| rejected | `plan.rej` | host passed; silent: no notification, the person only sees "Host passed this time" |
| left | `plan.left` | left by choice; may ask to join again |
| removed | `plan.removed` | permanently removed by the host from **this** squad only; cannot ask again; not a platform ban |

Conflicting records resolve deterministically: removed > accepted > pending > rejected > left, with no duplicates. Removal cannot be undone by deleting a visible row elsewhere.

**Roles** (the only administrative role is the host; there is no separate admin): the host approves/rejects requests and removes members; an accepted member reaches the private chat and member list and may leave; a pending, rejected, departed or removed person has no private access; a guest only sees public content and must sign in first. Every rule is decided once in `state/access.js` and `state/membership.js` and re-checked inside the action handlers (`app/guards.js`), not only in the UI.

**Flows.** Join: guest signs in, the join sheet asks for confirmation, a pending request is created (auto-accept squads accept at once, still capacity-checked); the host is notified once. Approve: host only, request must still be pending, squad open and not full, person not removed or blocked; the requester gets one "You're in" notice. Reject: pending only, silent. Leave: confirmation, becomes `left`, private access ends at once, the host gets one notice. Remove: host only, confirmation explaining the consequences, becomes `removed`; attendance and feedback records are kept but grant no membership. Rejoining: a person who left may ask again (the host decides); a removed person may not. Capacity (2 to 8, `minSquad`/`maxSquad` in `config.js`) is checked on creation and on every approval.

**Frontend-only limits.** Browser-local state cannot guarantee atomic capacity enforcement across people or devices; the simulated "simultaneous approvals" tests only prove the rule in a single browser. Two tabs, two devices, edited local storage or a cleared cache are outside what a frontend can protect. Cross-device removal, notifications to other devices and authoritative counts need the backend.

**Tests.** `npm run build`, then `npm test` (about 90 seconds, real timers). The run ends with one `RESULT:` line and exits 0 on success, 1 on any failure, crash, or stall (a watchdog names the last completed test). Section 02 tests are the ones starting with `S02`.

**Manual verification (simulated users).** Use two or three Google sign-ins (or the test accounts) in the same browser profile.
A. Approval: host creates a squad; User A requests; host approves; User A can open the chat.
B. Rejection: User B requests; host rejects; User B sees "Host passed this time", cannot open the chat, has no notification.
C. Leaving: an accepted member confirms "Leave"; private access disappears; they may request again.
D. Removal: host removes an accepted member; access disappears; they cannot request that squad again, but can request other squads.
E. Unauthorized: as an ordinary member, try Accept/Reject/Remove (hidden buttons, a hand-made `data-a` element); each is refused.
F. Capacity: fill a squad, then approve another request; it is refused and stays pending.
G. Stale chat: open a chat, have the host remove you, and watch the composer and screen being replaced; no delayed reply appears.
H. Account switching: member signs out, another account signs in; no previous private content or draft.

## Group chat and media (Section 03)
Frontend-only: messages and photos live in this browser's local state. **Nothing is synchronized, stored securely or delivered to other devices**, and the app never shows a message as "delivered" or "synced". The sample replies in a chat are simulated.

- **Access.** A conversation opens only for the host and accepted members (`groupAccess()` in `state/access.js`). Pending, rejected, departed and removed people, guests and unknown or malformed ids get the "No access" panel, with no messages, composer or member names. Every protected action (send, react, attach, camera, gallery, member list) re-checks access when it runs, and a late camera/gallery answer or simulated reply is dropped if access was lost meanwhile. Routes must have exactly the segments they define (`#/gc/abc/extra` is invalid).
- **Composer.** Empty or whitespace-only text is never sent; text is cut to `chatMaxLen` (300, `config.js`) and rendered escaped; Enter sends, but not Enter that confirms an IME composition or a held-down repeat; repeated clicks send once; a draft never follows you into another squad. Empty conversations show an empty state.
- **Mobile.** Full-screen conversation with a back control to the list; on desktop the list stays beside it. While a chat is open `app/viewport.js` publishes the visible height (`visualViewport`) as `--vvh`, which the chat layout uses instead of `100dvh`, so the composer stays above the keyboard on iOS; other browsers keep `100dvh`.
- **Attachments.** Camera and location are requested only after you tap them; denial, no camera and unsupported browsers show instructions and a gallery fallback. Gallery images must be JPG, PNG, WebP, GIF (or HEIC/HEIF if the browser can decode it) and at most `maxImageMB` (10); other files are refused before they are read. Images are re-encoded to at most 1280 px, kept as data URLs (no object URLs are created, so nothing to leak) and stay in this browser only.
- **Unread.** `unreadFor()` / `unreadTotal()` (`state/selectors.js`) are the only readers: whole numbers, never negative, only for squads you can open now; invalid or inaccessible entries are pruned on every render. Opening a conversation clears that squad only.
- **Reliability.** Leaving a squad by choice does **not** change the cancellation counter (`rel.cancel`); removal by the host records no cancellation for anyone; a host cancelling their own plan still counts, as before.

**Local-state boundary (for the future backend).** Message data is read and written only in `state/chat.js` (`msgs`, `sys`), `app/actions.js` (`send`, `sendMedia`, `react`), `components/squads/GroupChat.js` / `GroupList.js` (read) and `state/store.js` (persistence). A backend replaces those. Contracts it must provide: list/append messages per squad with authorization by accepted membership (enforced server-side, e.g. row-level security), attachment storage with signed access limited to members, server-side file type and size validation, per-member read state, and authoritative membership. Not implemented here: Supabase, storage buckets, realtime, push notifications, virus scanning, retention or moderation.

**Needs a real browser or phone** (not covered by the automated tests): the on-screen keyboard behaviour (`--vvh`) on iOS and Android, a real camera permission prompt and capture, the native file picker (including HEIC), touch scrolling and safe-area insets, and the visual check of light and dark themes.

## Environment variables
None required (see `.env.example`).

## Current scope
This repository contains **only the frontend**. All data is local (`src/js/data` sample content, `localStorage`); accounts are Google-verified but their profiles are stored on this device, and there is no backend, database, OAuth or API.

## Credits
Icons: [Lucide](https://lucide.dev) (ISC). Emoji art: [Twemoji](https://github.com/jdecked/twemoji) (CC-BY 4.0). Google "G" mark: official brand asset.
