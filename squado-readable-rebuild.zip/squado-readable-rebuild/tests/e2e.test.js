/* End-to-end flow tests on a simulated DOM (no browser, no dependencies).
   boot(P) loads the real scripts from index.html into a fresh context; passing the same persistence object P
   to boot() again is a "page refresh" (localStorage / sessionStorage survive, everything else is rebuilt). */
const vm = require('vm'), fs = require('fs');
const order = [...fs.readFileSync('index.html', 'utf8').matchAll(/src="src\/js\/([^"]+)"/g)].map(m => m[1]);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let ok = 0, bad = 0, last = '(none yet)', lastAt = Date.now();
const t = (n, c) => { c ? ok++ : bad++; last = n; lastAt = Date.now(); console.log((c ? 'PASS ' : 'FAIL ') + n); };
const norm = s => String(s).replace(/>\s+/g, '>').replace(/\s+</g, '<').replace(/\s+/g, ' ');
const mk = () => ({ innerHTML: '', style: {}, classList: { toggle() { } }, dataset: {}, value: '', focus() { }, setAttribute() { }, remove() { }, scrollTop: 0, addEventListener() { }, append() { } });
const newP = () => ({ store: {}, ss: {} });
const st = (q, P) => ({ getItem: k => q[k] || null, setItem: (k, v) => { if (P && P.fail && k == 'squado-v5') throw new Error('quota'); q[k] = v; }, removeItem: k => delete q[k] });

function boot(P, opt = {}) {
    const L = {}, W = {}, toasts = [];
    let h = '';
    const app = mk(), mod = mk();
    const loc = { pathname: '/', search: '' };
    if ('host' in opt) { loc.hostname = opt.host; loc.protocol = opt.proto || 'http:'; loc.origin = (opt.proto || 'http:') + '//' + opt.host + (opt.port ? ':' + opt.port : ''); }
    Object.defineProperty(loc, 'hash', { get: () => h, set: v => { h = v[0] == '#' ? v : '#' + v; setTimeout(() => W.hashchange && W.hashchange(), 0); } });
    const env = { toasts, geoCalls: 0, camCalls: 0, gCalls: 0, fetches: [], streams: [], files: [], opened: [], pos: [23.2599, 77.4126] };
    const canvas = () => ({ width: 0, height: 0, getContext: () => ({ fillRect() { }, drawImage() { }, fillStyle: '' }), toDataURL: () => 'data:image/jpeg;base64,QUJD' });
    const input = () => ({ style: {}, files: null, onchange: null, addEventListener() { }, remove() { }, click() { env.opened.push('picker'); const f = env.files.shift(); if (f) { this.files = [f]; this.onchange(); } } });
    const video = { srcObject: null, videoWidth: 640, videoHeight: 480, play: () => Promise.resolve() };
    mod.querySelector = s => s == 'video' && /<video/.test(mod.innerHTML) ? video : null;
    const ctx = {
        document: {
            querySelector: s => s == '#app' ? app : s == '#modal' ? mod : null,
            addEventListener: (a, f) => (L[a] = L[a] || []).push(f),
            createElement: tag => tag == 'canvas' ? canvas() : tag == 'input' ? input() : mk(),
            body: { append(el) { toasts.push(norm(el.innerHTML || '')); } },
            documentElement: { dataset: {} },
            activeElement: { tagName: 'BODY' }
        },
        localStorage: st(P.store, P), sessionStorage: st(P.ss), location: loc,
        history: { replaceState(a, b, u) { h = '#' + (u.split('#')[1] || ''); } },
        addEventListener: (a, f) => W[a] = f, scrollTo() { }, scrollY: 0, setTimeout, clearTimeout, setInterval: () => 0, queueMicrotask,
        navigator: {}, console, innerHeight: 800, innerWidth: 1200, screen: { height: 900 },
        FileReader: class { readAsDataURL() { this.result = 'data:image/png;base64,QUJD'; this.onload(); } },
        Image: class { set src(v) { this.naturalWidth = 3000; this.naturalHeight = 2000; setTimeout(() => this.onload(), 0); } },
        lucide: { icons: new Proxy({}, { get: (_, k) => typeof k == 'string' ? [['path', { d: 'x' }]] : undefined }), createElement: () => { const a = {}; return { setAttribute: (k, v) => a[k] = v, get outerHTML() { return '<svg class="' + a.class + '"></svg>'; } }; } }
    };
    ctx.window = ctx;
    ctx.crypto = require('crypto').webcrypto; ctx.URL = URL;
    ctx.qrcode = () => ({ addData(d) { env.qrData = d; }, make() { }, createSvgTag: () => '<svg data-qr="1"></svg>' });
    /* camera / location: scripted per test through env.cam / env.geo */
    ctx.navigator.mediaDevices = {
        getUserMedia: () => {
            env.camCalls++;
            return new Promise((res, rej) => {
                const go = () => {
                    const r = env.cam || { ok: 1 };
                    if (r.ok) { const s = { stopped: 0, getTracks: () => [{ stop() { s.stopped = 1; } }] }; env.streams.push(s); res(s); }
                    else rej({ name: r.name });
                };
                env.camDelay ? setTimeout(go, env.camDelay) : go();
            });
        }
    };
    ctx.navigator.geolocation = {
        getCurrentPosition: (ok2, err) => {
            env.geoCalls++;
            const r = env.geo || { ok: 1 };
            r.ok ? ok2({ coords: { latitude: env.pos[0], longitude: env.pos[1], accuracy: 18 } }) : err({ code: r.code });
        }
    };
    /* stand-in for Google's popup and token endpoints, scripted per test through env.gmode / env.ident / env.net */
    const CID = 'test-client.apps.googleusercontent.com';
    ctx.google = { accounts: { oauth2: { initTokenClient: cfg => ({
        requestAccessToken: o => {
            env.gCalls++; env.gOpts = o;
            const run = () => {
                const m = env.gmode || 'ok';
                if (m == 'ok') cfg.callback({ access_token: 'tok-' + env.ident.sub });
                else if (m == 'cancel') cfg.error_callback({ type: 'popup_closed' });
                else if (m == 'blocked') cfg.error_callback({ type: 'popup_failed_to_open' });
                else if (m == 'denied') cfg.callback({ error: 'access_denied' });
                else cfg.callback({ error: 'server_error' });
            };
            env.hold ? env.release = run : setTimeout(run, 0);
        } }) } } };
    ctx.fetch = async url => {
        env.fetches.push(url);
        if (env.net == 'down') throw new Error('offline');
        const i = env.ident;
        if (/tokeninfo/.test(url)) return { ok: true, json: async () => ({ aud: env.aud || CID, sub: i.sub }) };
        return { ok: true, json: async () => ({ sub: i.sub, email: i.email, email_verified: i.email_verified, name: i.name }) };
    };
    env.CID = CID;
    vm.createContext(ctx);
    for (const f of order)
        vm.runInContext(fs.readFileSync('src/js/' + f, 'utf8'), ctx, { filename: f });
    Object.assign(env, {
        ctx, app, mod, L, W,
        ev: s => vm.runInContext(s, ctx),
        click: (a, d = {}) => { const el = { dataset: { a, ...d }, tagName: 'BUTTON' }; L.click.forEach(f => f({ target: { closest: s => s == '[data-a]' ? el : null } })); },
        type: (k, v) => { const q = { target: { dataset: { in: k }, value: v } }; L.input.forEach(f => f(q)); },
        go: async x => { loc.hash = x; await sleep(/#\/(home|explore)/.test(x) && !env.warm ? 800 : 80); },
        html: () => norm(app.innerHTML),
        sheet: () => norm(mod.innerHTML),
        said: x => toasts.some(m => m.includes(x))
    });
    ctx.SQUADO_CONFIG.googleClientId = opt.noClient ? '' : CID;
    Object.defineProperty(env, 'h', { get: () => h });
    return env;
}

const onboard = (E, name, user) => {
    E.type('ob.name', name); E.click('obNext');
    E.type('ob.username', user); E.click('obNext');
    E.click('set', { k: 'ob.city', v: 'Bhopal' }); E.click('obNext');
    E.click('set', { k: 'ob.gender', v: 'Girl' }); E.click('obNext');
    E.click('set', { k: 'ob.age', v: '18–20' }); E.click('obNext');
    E.click('obNext');
};

const onboardUpTo = (E, name, user) => {
    E.type('ob.name', name); E.click('obNext');
    E.type('ob.username', user); E.click('obNext');
    E.click('set', { k: 'ob.city', v: 'Bhopal' }); E.click('obNext');
    E.click('set', { k: 'ob.gender', v: 'Girl' }); E.click('obNext');
    E.click('set', { k: 'ob.age', v: '18–20' }); E.click('obNext');
};

/* Google identities used by the tests (the provider double answers with whichever is set in E.ident) */
const ID = {
    somya_t: { sub: 'g-somya', email: 'somya@example.com', email_verified: true, name: 'Somya Google' },
    riya_b: { sub: 'g-riya', email: 'riya@example.com', email_verified: true, name: 'Riya Google' },
    sam_s: { sub: 'g-sam', email: 'sam@example.com', email_verified: true, name: 'Sam Google' },
    zed_z: { sub: 'g-zed', email: 'zed@example.com', email_verified: true, name: 'Zed Google' },
    carol_c: { sub: 'g-carol', email: 'carol@example.com', email_verified: true, name: 'Carol Google' }
};
const gsign = async (E, ident) => { E.ident = ident; E.click('gGoogle'); await sleep(80); };
/* a brand-new Google user: authenticate, then finish onboarding through the real screens */
async function signUp(E, name, user) {
    await gsign(E, ID[user]);
    onboard(E, name, user);
    await sleep(100);
}
async function signIn(E, user) { await gsign(E, ID[user]); await sleep(50); }
const localitiesAll = h => [...h.matchAll(/data-k="W\.loc" data-v="([^"]+)"/g)].map(m => m[1]);
const myNotifsLen = E => E.ev('myNotifs().length');
const allSrcFiles = () => { const out = []; const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(e => e.isDirectory() ? walk(d + '/' + e.name) : /\.js$/.test(e.name) && out.push(d + '/' + e.name)); walk('src/js'); return out; };
const allSrc = () => allSrcFiles().map(f => fs.readFileSync(f, 'utf8')).join('\n');
const CSS_BASE = fs.readFileSync('src/styles/base.css', 'utf8').replace(/\r/g, '').replace(/\n\s*/g, '');
const CSS_PAGES = fs.readFileSync('src/styles/pages.css', 'utf8').replace(/\r/g, '').replace(/\n\s*/g, '');
const sentText = (E, id, txt) => E.ev(`(S.msgs['${id}']||[]).some(m=>m.x=='${txt}')`);
const logout = async E => { E.click('logout'); await sleep(100); };

async function main() {
    const P = newP();
    let E = boot(P);
    await sleep(100);

    /* ---------- guest browsing ---------- */
    t('boots modularly: guest dashboard, no backend globals', E.html().includes('So... what are we doing?') && E.ev('typeof firebase') == 'undefined' && E.ev('S.me.guest'));
    const N = E.html().match(/<nav[\s\S]*?<\/nav>/)[0];
    t('nav: Home · Discover · Create · Groups · Profile (icon+label)', ['Home', 'Discover', 'Create', 'Groups', 'Profile'].every(l => N.includes('<span>' + l + '</span>')) && (N.match(/<svg/g) || []).length == 5 && (N.match(/aria-current="page"/g) || []).length == 1);
    await E.go('#/groups');
    t('logged out: protected page redirects to home with the sign-in prompt', E.sheet().includes('Sign in to continue') && E.h == '#/home');
    t('auth prompt carries no demo/prototype wording', !/prototype|demo/i.test(E.sheet()));
    E.click('close');
    await E.go('#/explore');
    E.type('ui.q', 'poha');
    t('search filters plans', E.html().includes('Poha jalebi run') && !E.html().includes('Anyone still dancing?'));
    E.type('ui.q', '');
    await E.go('#/event/e1');
    t('event page: ticket style, I\'m Going, who\'s going, related plans', E.html().includes('card ev big') && E.html().includes("I'm Going") && E.html().includes("Who's going") && E.html().includes('Plans for this') && E.html().includes('Anyone still dancing?'));
    await E.go('#/plan/p5');
    t('plan page: night route Garba → Chai → Food → Pandal', E.html().includes("Tonight's route") && ['Garba', 'Chai', 'Food', 'Pandal Hopping'].every(x => E.html().includes('<span>' + x + '</span>')));

    /* ---------- signup (account A) ---------- */
    await E.go('#/plan/p1');
    E.click('join', { v: 'p1' });
    t("guest I'm Down -> Google prompt", E.sheet().includes('Want to join the squad?') && E.sheet().includes('Continue with Google') && !/phone|otp/i.test(E.sheet()));
    t('no Google client configured -> honest "not set up" message, no sign-in', await (async () => { const N0 = boot(newP(), { noClient: 1 }); N0.ident = ID.somya_t; N0.click('gGoogle'); await sleep(30); return N0.sheet().includes("Google sign-in isn't set up") && N0.gCalls == 0 && N0.ev('S.me.guest') && !N0.ev('S.users.some(u=>u.real)'); })());
    E.ident = ID.somya_t; E.hold = true;
    E.click('gGoogle');
    t('loading state names the step that is actually running', E.sheet().includes('Signing you in…') && E.sheet().includes('role="status"'));
    E.click('gGoogle');
    t('second click while signing in is ignored (no duplicate popup)', E.gCalls == 1);
    E.hold = false; E.release(); await sleep(80);
    t('new Google user: popup asked for an account picker, then lands in onboarding (not Home)', E.gOpts.prompt == 'select_account' && E.html().includes('What should we call you?') && E.ev('S.me.onboarded===false&&!S.in'));
    t('profile record is created once, keyed by the Google id, with verified email', E.ev("S.acct&&S.me.sub=='g-somya'&&S.me.email=='somya@example.com'&&S.me.guest===undefined&&!S.users.some(u=>u.sub=='g-somya')") && E.fetches.some(u => /tokeninfo/.test(u)));
    t('onboarding prefilled with the Google name and progress bar', E.html().includes('value="Somya Google"') && E.html().includes('role="progressbar"') && E.html().includes('Step 1 of 6'));
    await E.go('#/home');
    t('unfinished onboarding cannot be skipped by navigating to Home', E.html().includes('What should we call you?') && !E.html().includes('Hey '));
    E.type('ob.name', 'Somya'); E.click('obNext');
    E.type('ob.username', 'ab');
    t('signup validation: too-short username blocks Next', /data-a="obNext"[^>]*disabled/.test(E.html()) && E.ev("unMsg('ab','')").includes('3–20 letters'));
    E.type('ob.username', 'aditi');
    t('signup validation: username of an existing person is "taken"', E.ev("unMsg('aditi','')").includes('Already taken') && /data-a="obNext"[^>]*disabled/.test(E.html()));
    E.type('ob.username', 'somya_t'); E.click('obNext');
    E = boot(P); await sleep(100);
    t('refresh mid-onboarding resumes at the saved step with entered data', E.ev("!S.me.guest&&S.me.onboarded===false&&O.ob.step==2&&O.ob.name=='Somya'&&O.ob.username=='somya_t'") && E.html().includes('Where are you usually hanging out?'));
    E.click('obCancel'); await sleep(50);
    t('"Sign out" on unfinished onboarding signs out and keeps the progress', E.ev("S.me.guest&&S.users.some(u=>u.sub=='g-somya'&&u.onboarded===false&&u.ob.step==2)"));
    await E.go('#/plan/p1'); E.click('join', { v: 'p1' });
    await signIn(E, 'somya_t');
    t('returning user with incomplete onboarding resumes where they stopped', E.ev("S.me.onboarded===false&&O.ob.step==2&&O.ob.username=='somya_t'") && E.html().includes('Where are you usually hanging out?') && E.ev('S.users.filter(u=>u.sub=="g-somya").length') == 0);
    t('city choices offer only supported cities', E.html().includes('data-v="Bhopal"') && !/data-v="(Indore|Ahmedabad|Mumbai|Delhi|Pune)"/.test(E.html()) && E.html().includes('Bhopal, Madhya Pradesh'));
    E.click('set', { k: 'ob.city', v: 'Bhopal' }); E.click('obNext');
    E.click('set', { k: 'ob.gender', v: 'Girl' }); E.click('obNext');
    E.click('set', { k: 'ob.age', v: '18–20' }); E.click('obNext');
    t('profile not marked complete before the final step is submitted', E.ev("S.me.onboarded===false"));
    E.click('obNext');
    await sleep(1400);
    t('onboarding complete: flag set, progress data dropped', E.ev("S.me.onboarded===true&&S.me.ob===undefined&&S.me.username=='somya_t'&&S.me.city=='Bhopal'"));
    t("after signup: back on the SAME plan with the join confirmation open; nothing was sent automatically", E.h == '#/plan/p1' && E.sheet().includes('Ask to join the squad') && !E.ev("pl('p1').reqs.some(r=>r.u=='me')") && E.ev('!S.me.guest'));
    E.click('cjoin', { v: 'p1' }); await sleep(900);
    t("confirming the resumed join sends the request", E.ev("pl('p1').reqs.some(r=>r.u=='me')"));
    t('signup creates a real account id and authenticates', E.ev("S.acct&&S.acct!='me'&&AUTH.state=='authenticated'"));
    t('new account owns no demo squads, messages or notifications', E.ev("S.plans.filter(p=>p.members.includes('me')).length==0&&myNotifs().length==0&&unreadTotal()==0&&Object.values(S.msgs).every(L=>L.every(m=>m.by!='me'))"));
    t('request is pending, not a member', E.ev("!pl('p1').members.includes('me')"));

    /* ---------- refresh while logged in ---------- */
    E = boot(P); await sleep(100);
    t('refresh while logged in keeps the same user and account', E.ev("!S.me.guest&&S.me.name=='Somya'&&AUTH.state=='authenticated'&&!!S.acct") && E.html().includes('Hey Somya'));
    t('refresh keeps the pending request', E.ev("pl('p1').reqs.some(r=>r.u=='me')"));
    t('settings: no Reset demo data, no reset handler', (await E.go('#/settings'), !E.html().includes('Reset demo data') && !E.html().includes('data-a="reset"') && E.ev("typeof A.reset")=='undefined' && E.html().includes('Log out')));

    /* ---------- logout / protected pages / refresh ---------- */
    const acctA = E.ev('S.acct');
    await logout(E);
    t('logout clears the session and returns to guest home', E.ev('S.me.guest&&S.acct===null&&AUTH.state=="unauthenticated"') && E.h == '#/home' && E.html().includes('Browse first'));
    t('logout keeps the account on the device, with its data re-labelled to the account id', E.ev("accounts().length==1&&accounts()[0].username=='somya_t'") && E.ev(`pl('p1').reqs.some(r=>r.u=='${acctA}')&&!JSON.stringify(S.plans).includes('"me"')`));
    await E.go('#/settings');
    t('logged-out direct access to settings is blocked', E.h == '#/home' && E.sheet().includes('Sign in to continue'));
    E.click('close');
    await E.go('#/gc/p9');
    t('logged-out direct access to a chat is blocked', E.h == '#/home' && !E.html().includes('Message your squad'));
    E.click('close');
    E = boot(P); await sleep(100);
    t('refresh while logged out stays logged out', E.ev('S.me.guest&&S.acct===null') && !E.html().includes('Hey Somya'));

    /* ---------- login ---------- */
    await signIn(E, 'somya_t');
    t('returning user with a finished profile goes straight to the app (no onboarding), as the same person', E.ev("!S.me.guest&&S.me.onboarded===true&&S.me.name=='Somya'&&S.me.id=='me'&&S.in") && E.html().includes('Hey Somya') && !E.html().includes('What should we call you?'));
    t('login restores that account\'s data', E.ev("pl('p1').reqs.some(r=>r.u=='me')&&!S.users.some(u=>u.real&&u.sub=='g-somya')"));
    await logout(E); await signIn(E, 'somya_t'); await logout(E); await signIn(E, 'somya_t');
    await logout(E);
    t('repeated sign-in never creates another profile', E.ev("S.users.filter(u=>u.real&&u.sub=='g-somya').length==1&&S.users.filter(u=>u.real).length==1"));
    await signIn(E, 'somya_t');
    E.click('edit'); E.ev("O.ed.name='Somya R';O.ed.bio='hi'"); E.click('saveEd'); await sleep(50);
    await logout(E);
    await signIn(E, 'somya_t');
    t('profile edits survive logout / login (no stale snapshot)', E.ev("S.me.name=='Somya R'&&S.me.bio=='hi'"));

    /* corrupt session is rejected, not half-loaded */
    const badS = JSON.parse(P.store["squado-v5"]); badS.me.name = ""; badS.me.username = "";
    const P2 = { store: { 'squado-v5': JSON.stringify(badS) }, ss: {} };
    const E2 = boot(P2); await sleep(50);
    t('unusable stored session shows the error screen with working Try again / Log out', E2.html().includes("Couldn't load your profile") && E2.ev("typeof A.authRetry")=='function');
    E2.click('logout'); await sleep(50);
    t('Log out from the error screen returns to a clean guest session', E2.ev('S.me.guest&&S.acct===null&&!S.users.some(u=>u.real&&!u.name)'));

    /* ---------- authentication failures ---------- */
    await logout(E);
    const nAcc = () => E.ev('S.users.filter(u=>u.real).length');
    const fail = async (name, setup, text, undo) => {
        const before = nAcc();
        setup(); E.ident = ID.riya_b; E.click('gGoogle'); await sleep(80);
        t(name, E.sheet().includes(text) && E.ev('S.me.guest&&S.acct===null&&!AUTH.busy') && nAcc() == before && E.h != '#/gc/p9');
        E.click('close'); undo && undo(); E.gmode = 'ok'; E.net = ''; E.aud = ''; ID.riya_b.email_verified = true;
    };
    await fail('cancelled Google window: stays signed out, can retry', () => E.gmode = 'cancel', 'Sign-in cancelled');
    await fail('Google access denied is treated as cancelled', () => E.gmode = 'denied', 'Sign-in cancelled');
    await fail('blocked pop-up has its own message', () => E.gmode = 'blocked', 'Pop-up blocked');
    await fail('provider error: sign-in failed, nothing created', () => E.gmode = 'error', "Couldn't sign you in");
    await fail('network failure: clear message, nothing created', () => E.net = 'down', "Couldn't reach Google");
    await fail('unverified Google email is refused, no profile created', () => ID.riya_b.email_verified = false, 'Email not verified');
    await fail('token issued to a different app is refused', () => E.aud = 'someone-else', "Couldn't sign you in");
    await fail('failed profile lookup: error + retry, no duplicate account', () => E.ev("{const f=S.users.find;S.users.find=function(fn){if(/\\.sub/.test(String(fn)))throw new Error('boom');return f.call(this,fn)}}"), "Couldn't check your profile", () => E.ev('delete S.users.find'));
    P.fail = true;
    await fail('failed profile save: error shown, nothing half-created', () => { }, "Couldn't save your profile", () => { P.fail = false; });
    E.click('gGoogle'); await sleep(80);
    t('Try again after the failures works and gives exactly one profile', E.ev("S.me.sub=='g-riya'&&S.me.onboarded===false") && E.html().includes('What should we call you?'));
    const gc = E.gCalls;
    t('the auth screens never navigated Home or loaded a demo user', E.ev("S.acct&&S.users.every(u=>!u.real||u.sub)")&&gc>0);
    onboardUpTo(E, 'Riya B', 'riya_b');
    P.fail = true; E.click('obNext');
    t('failed save at the last step: error shown, onboarding NOT marked complete', E.said("couldn't save your profile") && E.ev("S.me.onboarded===false&&!S.in"));
    P.fail = false; E.click('obNext'); await sleep(80);
    t('after a successful retry onboarding completes and Home opens', E.ev("S.me.onboarded===true&&S.in") && E.html().includes('Hey Riya B'));
    await logout(E);
    await signIn(E, 'somya_t');

    /* ---------- create plan as A (host) ---------- */
    await E.go('#/create');
    t('create: date, host controls, preview, no login wall', E.html().includes('Which day?') && E.html().includes('Host controls') && E.html().includes('>Preview<'));
    E.click('set', { k: 'W.type', v: 'chai' });
    E.click('set', { k: 'W.loc', v: 'MP Nagar' });
    E.click('set', { k: 'W.when', v: '10:00 PM' });
    E.click('set', { k: 'W.size', v: '3' });
    E.click('post');
    t('post shows loading state', E.html().includes('Posting…') && E.html().includes('btn pink wide loading'));
    await sleep(800);
    const planId = E.ev('S.plans[0].id');
    E.ev(`pl('${planId}').simAt=0`);
    t('plan created -> posted page, host is the only member', E.h.startsWith('#/posted/') && E.ev(`S.plans[0].creator=='me'&&S.plans[0].members.length==1`));
    await logout(E);

    /* ---------- account B requests to join A's plan ---------- */
    await E.go('#/plan/' + planId);
    E.click('join', { v: planId });
    await signIn(E, 'riya_b');
    await sleep(1400);
    t('second account is its own person and inherits nothing from A', E.ev("S.me.name=='Riya B'&&S.acct&&S.plans.filter(p=>p.creator=='me').length==0&&myNotifs().length==0"));
    const acctB = E.ev('S.acct');
    t('accounts A and B coexist on the device', E.ev("accounts().length==1&&accounts()[0].username=='somya_t'") && acctA != acctB && E.ev("S.me.sub")=='g-riya');
    await E.go('#/plan/' + planId);
    E.click('cjoin', { v: planId });
    await sleep(800);
    t('sending twice does not duplicate the request', E.ev(`pl('${planId}').reqs.filter(r=>r.u=='me').length==1`));
    t('request sent: pending for the host, B is NOT a member, count unchanged', E.ev(`pl('${planId}').reqs.some(r=>r.u=='me')&&!pl('${planId}').members.includes('me')&&pl('${planId}').members.length==1`));
    t('host (A) is notified, requester (B) is not', E.ev(`S.notifs.some(n=>n.type=='join_request'&&n.to=='${acctA}'&&n.planId=='${planId}'&&n.userId=='me')&&myNotifs().length==0`));
    await E.go('#/gc/' + planId);
    t('requester cannot open the squad chat yet', E.html().includes('No access') && !E.html().includes('Message your squad'));
    await E.go('#/groups');
    t('Groups no longer lists a "Waiting on the host" section (pending status lives on the plan itself)', !E.html().includes('Waiting on the host') && !E.html().includes('Requested'));
    await E.go('#/plan/' + planId);
    t('requester sees their own pending status on the plan page', E.html().includes('Requested') || E.html().includes('Waiting'));
    await logout(E);

    /* ---------- host A reviews ---------- */
    await signIn(E, 'somya_t');
    await E.go('#/home');
    t('home: bell shows the unread indicator', E.html().includes('Notifications, unread') && E.html().includes('class="dotb"'));
    E.click('notifs');
    t('notification overlay opens from the home bell with the join request', E.sheet().includes('Riya B wants to join your squad') && E.sheet().includes('Review request') && E.sheet().includes('Notifications'));
    t('opening it marks notifications read and clears the dot', E.ev('unreadN()') == 0 && !E.html().includes('Notifications, unread'));
    t('overlay does not change the underlying route', E.h == '#/home' && E.html().includes('Hey Somya'));
    const nid = E.ev("myNotifs().find(n=>n.type=='join_request').id");
    E.click('notifGo', { v: nid });
    await sleep(100);
    t('join-request notification opens that squad chat (derived from its plan id)', E.h == '#/gc/' + planId && E.sheet() == '');
    t('chat shows the join-request component above the conversation', E.html().includes('class="jrq"') && E.html().indexOf('class="jrq"') < E.html().indexOf('class="gmsgs"') && E.html().includes('Riya B') && E.html().includes('wants to join the squad') && E.html().includes('Review request'));
    const compHtml = E.html().match(/<div class="comp">[\s\S]*?<\/div>(?=<\/section>)/)[0];
    t('composer = attachment + input + send only (no bell, no location pin)', (compHtml.match(/<button/g) || []).length == 2 && compHtml.includes('data-a="attachments"') && compHtml.includes('id="mi"') && compHtml.includes('data-a="send"') && !compHtml.includes('notifs') && !compHtml.includes('openMediaLocation') && /^<div class="comp"><button[^>]*data-a="attachments"/.test(compHtml));
    E.click('gopts', { v: planId }); E.click('members', { v: planId });
    t('View Members lists accepted members only: pending requester not shown, no inflated count', E.sheet().includes('The squad 1 / 3') && !E.sheet().includes('Riya B') && !E.sheet().includes('Pending requests') && !E.sheet().includes('Approve'));
    E.click('close');
    const reqUser = E.ev(`pl('${planId}').reqs[0].u`);
    E.click('reviewRequest', { k: planId, v: reqUser });
    t('Review opens the requester profile with Accept / Reject', E.sheet().includes('Riya B') && E.sheet().includes('@riya_b') && E.sheet().includes('Wants to join') && E.sheet().includes('Accept') && E.sheet().includes('Reject') && E.sheet().includes('Squad feedback'));
    E.click('accept', { k: planId, v: reqUser });
    t('accept: pending cleared, requester is now a member, count updates', E.ev(`pl('${planId}').reqs.length==0&&pl('${planId}').members.includes('${acctB}')&&pl('${planId}').members.length==2`) && E.sheet() == '');
    t('accept: system message posted, request component gone immediately', E.ev(`S.msgs['${planId}'].some(m=>m.sys&&/Riya B joined the squad/.test(m.x))`) && !E.html().includes('class="jrq"') && E.html().includes('Riya B joined the squad'));
    t('accept: requester notified, host\'s pending notification resolved, state persisted', E.ev(`S.notifs.some(n=>n.type=='join-approved'&&n.to=='${acctB}'&&n.planId=='${planId}')&&!S.notifs.some(n=>n.type=='join_request'&&n.planId=='${planId}')`) && JSON.parse(P.store['squado-v5']).plans.find(p => p.id == planId).members.length == 2);
    t('member count shown consistently', E.html().includes('2 members'));
    await logout(E);

    /* ---------- B sees approval ---------- */
    await signIn(E, 'riya_b');
    await E.go('#/home');
    t('requester: approval notification is unread and addressed to them', E.html().includes('Notifications, unread') && E.ev("myNotifs().some(n=>n.type=='join-approved')"));
    E.click('notifs');
    t('requester overlay shows "You\'re in!"', E.sheet().includes("You're in!") && E.sheet().includes('accepted you for'));
    E.click('notifGo', { v: E.ev("myNotifs().find(n=>n.type=='join-approved').id") });
    await sleep(100);
    t('approval opens the squad chat and B can use it', E.h == '#/gc/' + planId && E.html().includes('Message your squad') && E.html().includes('Somya'));
    t('non-host member sees no request component', !E.html().includes('class="jrq"'));

    /* ---------- permissions ---------- */
    E.ev(`pl('${planId}').reqs.push({u:'u6',at:Date.now()});pl('${planId}').max=5`);
    await E.go('#/gc/' + planId);
    t('normal member does not see pending requests in chat', !E.html().includes('class="jrq"'));
    E.click('reviewRequest', { k: planId, v: 'u6' });
    t('normal member cannot open the review', !E.sheet().includes('Accept') && E.said('no longer available'));
    E.click('accept', { k: planId, v: 'u6' });
    E.click('reject', { k: planId, v: 'u6' });
    t('normal member cannot accept or reject', E.ev(`pl('${planId}').reqs.some(r=>r.u=='u6')&&!pl('${planId}').members.includes('u6')`) && E.said('Only the host'));
    await logout(E);

    /* ---------- reject + full squad (host, simulated requester) ---------- */
    await signIn(E, 'somya_t');
    t('host sees the pending request in chat', (await E.go('#/gc/' + planId), E.html().includes('class="jrq"') && E.html().includes('Meera')));
    E.click('reviewRequest', { k: planId, v: 'u6' });
    E.click('reject', { k: planId, v: 'u6' });
    t('reject: removed from pending, NOT a member, remembered as passed', E.ev(`!pl('${planId}').reqs.some(r=>r.u=='u6')&&!pl('${planId}').members.includes('u6')&&pl('${planId}').rej.includes('u6')`) && E.sheet() == '' && !E.html().includes('class="jrq"'));
    t('reject is silent: nobody is notified that the request was passed on', E.ev(`!S.notifs.some(n=>n.type=='join-rejected')&&!S.notifs.some(n=>n.to=='u6')`));
    E.ev(`pl('${planId}').max=2;pl('${planId}').reqs.push({u:'u2',at:Date.now()})`);
    E.click('accept', { k: planId, v: 'u2' });
    t('accepting into a full squad keeps the request pending instead of losing it', E.ev(`pl('${planId}').reqs.some(r=>r.u=='u2')&&!pl('${planId}').members.includes('u2')`) && E.said('Squad full'));
    E.ev(`pl('${planId}').reqs=[];pl('${planId}').max=4`);

    /* simulated requester (fixture person) + routing of the notification */
    E.ev(`pl('${planId}').simAt=1`); E.ev('tick()');
    t('simulated requester: pending + host notification, no member change', E.ev(`pl('${planId}').reqs.length==1&&pl('${planId}').members.length==2&&myNotifs().some(n=>n.type=='join_request'&&n.planId=='${planId}')`));
    t('simulated requests never use real accounts', E.ev(`!pl('${planId}').reqs.some(r=>r.u=='${acctB}')`));
    E.click('unreq', { v: planId }); /* host has no such request: no effect */

    /* ---------- notification routing ---------- */
    E.ev(`S.notifs.length=0;
        notify('me',{type:'join-rejected',ic:'user-x',c:'red',t:'R',b:'b',planId:'p4'});
        notify('me',{type:'removed',ic:'user-minus',c:'red',t:'R',b:'b',planId:'p4'});
        notify('me',{type:'message',ic:'bell',c:'blue',t:'M',b:'b',planId:'${planId}'});
        notify('me',{type:'plan',ic:'bell',c:'gold',t:'P',b:'b',planId:'p2'});
        notify('me',{type:'event',ic:'bell',c:'gold',t:'E',b:'b',eventId:'e2'});
        notify('me',{type:'member',ic:'bell',c:'green',t:'X',b:'b',planId:'p9'});
        notify('me',{type:'plan',ic:'bell',c:'gold',t:'Gone',b:'b',planId:'nope'});`);
    const route = ty => E.ev(`notifRoute(S.notifs.find(n=>n.type=='${ty}'&&n.t!='Gone'))`);
    t('a join-rejected notification can never be created', E.ev("!S.notifs.some(n=>n.type=='join-rejected')"));
    t('routing: removal -> that plan page', route('removed') == '#/plan/p4');
    t('routing: message -> that chat', route('message') == '#/gc/' + planId);
    t('routing: plan update -> that plan', route('plan') == '#/plan/p2');
    t('routing: event -> that event', route('event') == '#/event/e2');
    t('routing: membership of a squad you are not in -> plan page, not a dead chat', route('member') == '#/plan/p9');
    E.click('notifs');
    t('every notification renders; one about a squad you cannot open shows no private preview', ['>R<', '>M<', '>P<', '>E<'].every(x => E.sheet().includes(x)) && !E.sheet().includes('>X<') && E.sheet().includes('Squad update') && !E.sheet().includes('undefined'));
    E.click('notifGo', { v: E.ev("S.notifs.find(n=>n.t=='Gone').id") });
    t('notification whose target is gone says so and does not navigate', E.said('no longer available') && E.sheet() == '');
    E.click('notifGo', { v: E.ev("S.notifs.find(n=>n.type=='event').id") });
    await sleep(100);
    t('clicking an event notification opens the event page', E.h == '#/event/e2');
    E.click('notifs'); E.click('close');
    t('overlay closes normally', E.sheet() == '' && E.h == '#/event/e2');
    await logout(E);

    /* ---------- chat media (as a signed-in squad member) ---------- */
    await signIn(E, 'somya_t');
    await E.go('#/gc/' + planId);
    E.click('attachments', { v: planId });
    t('attachment sheet: Camera, Gallery, Location, Cancel', ['Camera', 'Gallery', 'Location', 'Cancel'].every(x => E.sheet().includes('<b>' + x + '</b>') || E.sheet().includes('>' + x + '<')));
    t('opening the sheet asks for no permissions', E.camCalls == 0 && E.geoCalls == 0);
    /* camera: permission denied */
    E.cam = { name: 'NotAllowedError' };
    E.click('openMediaCamera', { v: planId }); await sleep(30);
    t('camera permission denied: instructions + Try again + gallery fallback', E.sheet().includes('Camera access is blocked') && E.sheet().includes('Try again') && E.sheet().includes('Choose from gallery instead') && E.geoCalls == 0);
    E.cam = { ok: 1 };
    E.click('mediaRetry', { v: planId }); await sleep(30);
    t('retry opens the camera preview', E.sheet().includes('<video') && E.sheet().includes('Take photo') && E.ev("$('#modal')._cameraStream")!==null);
    const s1 = E.streams[E.streams.length - 1];
    E.click('capturePhoto', { v: planId });
    t('capture shows a preview and stops the camera', E.sheet().includes('Preview') && E.sheet().includes('Retake') && E.sheet().includes('Send') && s1.stopped == 1);
    t('camera did not request location', E.geoCalls == 0);
    E.click('mediaRetry', { v: planId }); await sleep(30);
    t('retake reopens the camera', E.sheet().includes('<video'));
    const s2 = E.streams[E.streams.length - 1];
    E.click('close');
    t('cancel releases the camera', s2.stopped == 1 && E.sheet() == '');
    E.click('mediaRetry', { v: planId }); await sleep(30);
    const s3 = E.streams[E.streams.length - 1];
    E.mod.onclick({ target: { id: 'modal' } });
    t('tapping outside the sheet releases the camera', s3.stopped == 1);
    E.camDelay = 60;
    E.click('mediaRetry', { v: planId }); E.click('close'); await sleep(120);
    t('closing before the browser answers still releases the late camera stream', E.streams[E.streams.length - 1].stopped == 1 && E.sheet() == '');
    E.camDelay = 0;
    E.click('mediaRetry', { v: planId }); await sleep(30); E.click('capturePhoto', { v: planId });
    const before = E.ev(`S.msgs['${planId}'].length`);
    E.click('sendMedia', { k: planId });
    t('send photo adds a photo message, no location', E.ev(`S.msgs['${planId}'].length`) == before + 1 && E.ev(`S.msgs['${planId}'].slice(-1)[0].type=='photo'&&!S.msgs['${planId}'].slice(-1)[0].loc&&S.msgs['${planId}'].slice(-1)[0].by=='me'`) && E.sheet() == '');
    t('photo renders in the conversation', E.html().includes('alt="Photo shared in chat"'));
    /* gallery */
    E.files.push({ type: 'image/png' });
    E.click('mediaGallery', { v: planId }); await sleep(30);
    t('gallery: picker opens, selected image is previewed (resized), still no location request', E.opened.length == 1 && E.sheet().includes('Preview') && E.sheet().includes('Choose another') && E.geoCalls == 0);
    E.click('sendMedia', { k: planId });
    t('gallery photo sends', E.ev(`S.msgs['${planId}'].slice(-1)[0].type=='photo'`));
    /* photo + explicitly attached location */
    E.files.push({ type: 'image/png' });
    E.click('mediaGallery', { v: planId }); await sleep(30);
    E.click('attachLocation', { v: planId });
    t('photo + location only when the user attaches it', E.geoCalls == 1 && E.sheet().includes('will be sent with this photo') && E.sheet().includes('Remove location'));
    E.click('detachLocation', { v: planId });
    t('attached location can be removed again', !E.sheet().includes('will be sent with this photo') && E.sheet().includes('Attach my current location'));
    E.click('attachLocation', { v: planId });
    E.click('sendMedia', { k: planId });
    t('photo with location is sent as photo-location with coordinates', E.ev(`S.msgs['${planId}'].slice(-1)[0].type=='photo-location'&&S.msgs['${planId}'].slice(-1)[0].loc.lat>23`));
    t('location link renders under the photo', E.html().includes('Open in Maps') && E.html().includes('maps?q=23.2599,77.4126'));
    /* location */
    const g0 = E.geoCalls;
    E.click('attachments', { v: planId });
    E.click('openMediaLocation', { v: planId });
    t('Location requests geolocation only now, then shows a confirmation preview', E.geoCalls == g0 + 1 && E.sheet().includes('Share location') && E.sheet().includes('23.2599, 77.4126') && E.sheet().includes('about 18 m'));
    t('nothing is sent before confirming', E.ev(`S.msgs['${planId}'].slice(-1)[0].type`) != 'location');
    E.click('sendMedia', { k: planId });
    t('confirmed location is sent and rendered with an Open in Maps link', E.ev(`S.msgs['${planId}'].slice(-1)[0].type=='location'`) && E.html().includes('Location shared') && E.html().includes('Open in Maps'));
    E.geo = { code: 1 };
    E.click('attachments', { v: planId }); E.click('openMediaLocation', { v: planId });
    t('location denied: instructions + Try again', E.sheet().includes('Location access is blocked') && E.sheet().includes('Try again'));
    E.geo = { ok: 1 };
    E.click('openMediaLocation', { v: planId });
    t('location retry works', E.sheet().includes('Current location ready'));
    E.click('close');
    t('chat list preview names photos and locations', (await E.go('#/groups'), !E.html().includes('undefined') && E.html().includes('Shared a location')));
    t('chat shows sample replies only from sample people, never real accounts', E.ev(`S.msgs['${planId}'].every(m=>!m.by||m.by=='me'||!usr(m.by).real||m.sys)`));

    /* ---------- no demo-only controls / handler integrity ---------- */
    const srcAll = order.map(f => fs.readFileSync('src/js/' + f, 'utf8')).join('\n') + fs.readFileSync('index.html', 'utf8');
    t('no "Reset demo data", prototype wording or reset action anywhere in the source', !/reset demo|prototype:|data-a="reset"|A\.reset|\breset\(\)/i.test(srcAll));
    const used = [...new Set([...srcAll.matchAll(/data-a="([A-Za-z]+)"/g)].map(m => m[1]))];
    const missing = used.filter(a => E.ev(`typeof A['${a}']`) != 'function');
    t('every static data-a action used by the UI has a handler' + (missing.length ? ' — missing: ' + missing : ''), !missing.length);
    const dyn = ['geo', 'geoOff', 'cancel', 'leave', 'remove', 'block'];
    t('dynamic / confirm actions have handlers', dyn.every(a => E.ev(`typeof A['${a}']`) == 'function'));
    for (const r of ['#/home', '#/explore', '#/event/e1', '#/plan/p1', '#/create', '#/groups', '#/me', '#/settings', '#/gc/' + planId]) {
        await E.go(r);
        if (/\p{Extended_Pictographic}/u.test(E.html().replace(/<[^>]*>/g, ''))) { t('no native emoji as UI: ' + r, false); break; }
    }
    t('no native emoji used as UI on all pages', !/\p{Extended_Pictographic}/u.test(E.html().replace(/<[^>]*>/g, '')));
    t('Live removed: no liveNow page/route/nav item', !/liveNow|k=='live'|'#\/live'/.test(srcAll) && !/l:'Live'/.test(srcAll));
    t('no Firebase/Supabase; only Google identity endpoints are ever fetched', !/firebase\.|supabase|signInWith|XMLHttp|httpsCallable/i.test(srcAll) && [...srcAll.matchAll(/fetch\('(https:\/\/[^/']+)/g)].every(m => /^https:\/\/(oauth2|www)\.googleapis\.com$/.test(m[1])) && !/gstatic\.com\/firebasejs/.test(srcAll));
    t('no Telegram / phone / OTP', !/telegram|\botp\b|signInWithPhone/i.test(srcAll));

    /* ---------- plan lifecycle regressions (as host) ---------- */
    await E.go('#/home');
    t('home: your squads listed for the host', E.html().includes('Your squads'));
    E.click('ask', { do: 'cancel', v: planId });
    t('destructive action asks first', E.sheet().includes('Cancel this plan?') && E.ev(`pl('${planId}').status`) == 'open');
    E.click('confirmed'); await sleep(300);
    t('confirm performs the action and tells the squad', E.ev(`pl('${planId}').status`) == 'cancelled' && E.ev(`S.notifs.some(n=>n.type=='plan'&&n.to=='${acctB}')`));
    await logout(E);
    await signIn(E, 'riya_b');
    E.click('notifs');
    t('squad member is told the plan was cancelled and it opens that plan', E.sheet().includes('Plan cancelled'));
    E.click('notifGo', { v: E.ev("myNotifs().find(n=>n.type=='plan').id") }); await sleep(100);
    t('cancelled-plan notification routes to the plan page', E.h == '#/plan/' + planId);
    await E.go('#/groups');
    t('Groups: list with context, last message, time', E.html().includes('Your squads, all in one place.'));
    click_theme: { E.click('theme'); t('theme choice persists', ['light', 'dark'].includes(E.ctx.localStorage.getItem('squado-theme'))); }

    /* ---------- legacy state migration ---------- */
    const legacy = { in: true, me: { id: 'me', name: 'Old', username: 'old_user', gender: 'Girl', city: 'Bhopal', interests: [], rel: { hosted: 0, joined: 0, completed: 0, cancel: 0, noshow: 0 }, fb: { n: 0, tags: {}, again: [0, 0] } }, users: JSON.parse(JSON.stringify(E.ev('U'))), plans: E.ev("JSON.parse(JSON.stringify(P0))"), events: E.ev('JSON.parse(JSON.stringify(E0))'), notifs: [{ id: 'n1', type: 'join_request', t: 'Meera wants to join your squad', b: 'x', u: 1 }, { id: 'n99', type: 'join-approved', u: 'u6' }], msgs: {}, unread: {}, blocked: [], reports: [], notif: true };
    legacy.plans.find(p => p.id == 'p9').members.push('me');
    const P3 = { store: { 'squado-v5': JSON.stringify(legacy) }, ss: {} };
    const E3 = boot(P3); await sleep(50);
    t('old saved logged-in state migrates: a stored profile is not a session, so the person is signed out with the account kept, data re-labelled, demo/malformed notifications dropped', E3.ev("S.me.guest&&S.acct===null&&S.sv==2&&S.notifs.length==0&&!pl('p9').members.includes('me')&&legacyAccounts().length==1&&legacyAccounts()[0].name=='Old'&&pl('p9').members.includes(legacyAccounts()[0].id)"));
    const guestLegacy = { ...legacy, me: JSON.parse(JSON.stringify(legacy.me)) }; guestLegacy.me = { id: 'me', guest: 1, name: 'friend', username: '', interests: [], rel: legacy.me.rel, fb: legacy.me.fb };
    const P4 = { store: { 'squado-v5': JSON.stringify(guestLegacy) }, ss: {} };
    const E4 = boot(P4); await sleep(50);
    t('old pristine guest state restarts clean: no pre-joined demo squads', E4.ev("S.me.guest&&S.sv==2&&!pl('p9').members.includes('me')&&S.notifs.length==0"));
    const P5 = { store: { 'squado-v5': JSON.stringify(guestLegacy), 'squado-mock-profile': JSON.stringify({ id: 'me', name: 'Kept', username: 'kept_u', gender: 'Boy', city: 'Bhopal', interests: [], rel: legacy.me.rel, fb: legacy.me.fb }) }, ss: {} };
    guestLegacy.plans.find(p => p.id == 'p9').members.push('me');
    P5.store['squado-v5'] = JSON.stringify(guestLegacy);
    const E5 = boot(P5); await sleep(50);
    t('old logged-out state with a saved profile becomes a device account (not signed in) that keeps its data', E5.ev("legacyAccounts().length==1&&legacyAccounts()[0].username=='kept_u'&&!pl('p9').members.includes('me')&&pl('p9').members.includes(legacyAccounts()[0].id)&&S.me.guest") && !P5.store['squado-mock-profile']);
    /* a legacy profile is only reachable after Google sign-in, and only if the person chooses to link it */
    E5.ident = { sub: 'g-kept', email: 'kept@example.com', email_verified: true, name: 'Kept' };
    E5.click('gGoogle'); await sleep(80);
    t('legacy profiles: nothing opens without Google; after Google the person chooses to link one', E5.sheet().includes('Link an existing profile?') && E5.sheet().includes('@kept_u') && E5.ev('S.me.guest'));
    E5.click('linkAcct', { v: E5.ev('legacyAccounts()[0].id') }); await sleep(50);
    t('linking binds the profile to that Google id and signs in as them', E5.ev("S.me.sub=='g-kept'&&S.me.username=='kept_u'&&S.me.onboarded!==false&&S.in") && E5.html().includes('Hey Kept'));
    const E6 = boot(P5); await sleep(50);
    await E6.go('#/home');
    E6.click('logout'); await sleep(30);
    E6.ident = { sub: 'g-kept', email: 'kept@example.com', email_verified: true, name: 'Kept' };
    E6.click('gGoogle'); await sleep(80);
    t('linked profile is found by its Google id next time, without the link prompt', !E6.sheet().includes('Link an existing') && E6.ev("S.me.username=='kept_u'&&S.users.filter(u=>u.real&&u.sub=='g-kept').length==0"));

    /* ---------- location: one supported city, consistent everywhere ---------- */
    const LP = newP(); const L1 = boot(LP); await sleep(100);
    t('location data: Bhopal is the only city, with its localities and coordinates together', L1.ev("CITIES.join()=='Bhopal'&&localitiesOf('Bhopal').length==9&&localitiesOf('Mumbai').length==0&&cityLabel('Bhopal')=='Bhopal, Madhya Pradesh'&&Object.keys(LC).every(k=>cityOfLoc(k)=='Bhopal')"));
    t('no location permission is requested on load', L1.geoCalls == 0);
    t('every sample plan and event locality is a known Bhopal locality', L1.ev("S.plans.every(p=>cityOfLoc(p.loc)=='Bhopal')&&S.events.every(e=>cityOfLoc(e.loc)=='Bhopal')"));
    t('without a known position no distance is shown or invented', !/~[\d.]+ km/.test(L1.html()) && L1.ev("d(pl('p1'))")===null);
    L1.ev("S.geo=[23.2335,77.433]");
    t('inside Bhopal: distance is computed from real coordinates (km)', L1.ev("d(pl('p1'))")==0.1 && L1.ev("near()")=='Near DB Mall' && L1.ev("geoOn()") && L1.ev("d(pl('p4'))") > 0.1);
    L1.ev("S.geo=[19.07,72.87]");
    t('outside every supported city: position is not used for distances or nearby results', L1.ev("d(pl('p1'))")===null && !L1.ev('geoOn()') && L1.ev('pings().length')==0);
    L1.ev("S.geo=null");
    t('unknown / missing coordinates never produce a number', L1.ev("d({loc:'Nowhere'})")===null && L1.ev("d({})")===null && L1.ev("kmTxt({loc:'Nowhere'})")==='');
    L1.pos = [19.07, 72.87]; L1.click('geo'); await sleep(30);
    t('"Use my location" from far away is refused honestly and stores nothing', L1.geoCalls == 1 && L1.ev("S.geo===null&&S.area===null") && L1.said('only in Bhopal'));
    L1.pos = [23.216, 77.435]; L1.click('geo'); await sleep(30);
    t('"Use my location" in Bhopal sets the nearby area and distances appear', L1.ev("S.area=='Bittan Market'&&geoOn()") && L1.said('Location on'));
    L1.click('geoOff');
    t('turning location off clears it', L1.ev("S.geo===null"));
    /* plans in an unsupported/unknown place are kept but hidden from discovery */
    L1.ev("S.plans.push({id:'px',creator:'u1',type:'chai',title:'Legacy Indore plan',desc:'',vibe:[],loc:'Vijay Nagar',when:'9:00 PM',max:4,members:['u1'],who:'Everyone',reqs:[],status:'open',created:1})");
    t('plans at unsupported places stay in saved data but are not offered', L1.ev("S.plans.some(p=>p.id=='px')&&!vis().some(p=>p.id=='px')&&vis().length>5"));

    /* signed-in user: onboarding / create / profile consistency */
    const LP2 = newP(); const L2 = boot(LP2); L2.ident = { sub: 'g-loc', email: 'loc@example.com', email_verified: true, name: 'Loc' }; L2.click('gGoogle'); await sleep(80);
    L2.type('ob.name', 'Loc'); L2.click('obNext'); L2.type('ob.username', 'loc_user'); L2.click('obNext');
    t('onboarding location step lists only supported cities', L2.html().includes('data-v="Bhopal"') && !/data-v="(Indore|Ahmedabad|Mumbai|Delhi|Pune)"/.test(L2.html()) && L2.geoCalls == 0);
    L2.click('set', { k: 'ob.city', v: 'Indore' });
    t('onboarding will not proceed with an unsupported city', /data-a="obNext"[^>]*disabled/.test(L2.html()));
    L2.click('set', { k: 'ob.city', v: 'Bhopal' }); L2.click('obNext');
    L2.click('set', { k: 'ob.gender', v: 'Girl' }); L2.click('obNext'); L2.click('set', { k: 'ob.age', v: '18–20' }); L2.click('obNext');
    L2.ev("O.ob.city='Indore'"); L2.click('obNext');
    t('finishing onboarding re-checks the city: an unsupported one is not saved', L2.said('supported location') && L2.ev("S.me.onboarded===false&&!S.me.city"));
    L2.ev("O.ob.city='Bhopal'"); L2.click('obNext'); await sleep(80);
    t('supported city is saved on the profile', L2.ev("S.me.onboarded===true&&S.me.city=='Bhopal'"));
    const L2b = boot(LP2); await sleep(80);
    t('profile location persists after refresh', L2b.ev("S.me.city=='Bhopal'&&S.me.name=='Loc'"));
    await L2.go('#/create');
    t('create plan offers only Bhopal localities', localitiesAll(L2.html()).length == 9 && !L2.html().includes('Vijay Nagar'));
    L2.click('set', { k: 'W.type', v: 'chai' }); L2.click('set', { k: 'W.loc', v: 'Vijay Nagar' }); L2.click('set', { k: 'W.when', v: '10:00 PM' }); L2.click('set', { k: 'W.size', v: '3' });
    L2.click('post'); await sleep(800);
    t('a locality from another place is refused when posting', L2.ev("S.plans.filter(p=>p.creator=='me').length")==0 && L2.said('Pick a place in Bhopal'));
    L2.click('set', { k: 'W.loc', v: 'MP Nagar' }); L2.click('post'); await sleep(800);
    t('valid Bhopal locality posts and records the city', L2.ev("S.plans[0].creator=='me'&&S.plans[0].city=='Bhopal'&&S.plans[0].loc=='MP Nagar'&&!('dist' in S.plans[0])"));
    await L2.go('#/explore');
    t('discovery shows only plans in the viewer\'s city, with no invented distances', L2.ev("vis().every(p=>planCity(p)=='Bhopal')") && !/~[\d.]+ km/.test(L2.html()));
    /* legacy unsupported saved city */
    L2.ev("S.me.city='Indore'"); await L2.go('#/home');
    t('legacy unsupported city is kept but the person is asked to pick a supported one', L2.ev("S.me.city")=='Indore' && L2.html().includes("isn't supported yet") && L2.html().includes('Choose a supported location'));
    L2.click('edit');
    t('profile editor explains it and offers only Bhopal', L2.sheet().includes("isn't supported yet") && L2.sheet().includes('data-v="Bhopal"') && !L2.sheet().includes('data-v="Mumbai"'));
    L2.click('saveEd');
    t('saving the profile with an unsupported city is refused (value untouched)', L2.said('Pick a supported location') && L2.ev("S.me.city")=='Indore');
    L2.click('set', { k: 'ed.city', v: 'Bhopal' }); L2.click('saveEd');
    t('choosing Bhopal fixes it and the notice disappears', L2.ev("S.me.city")=='Bhopal' && (await L2.go('#/home'), !L2.html().includes("isn't supported yet")));
    await L2.go('#/create'); L2.ev("S.me.city='Indore'");
    t('create plan with an unsupported saved city offers no localities', (await L2.go('#/create'), localitiesAll(L2.html()).length == 0));

    /* ---------- feedback & reviews ---------- */
    const FP = newP(); const F = boot(FP); await sleep(100);
    await signUp(F, 'Riya B', 'riya_b'); await sleep(80);
    const riyaId = F.ev('S.acct');
    await logout(F);
    await signUp(F, 'Somya', 'somya_t'); await sleep(80);
    await F.go('#/create');
    F.click('set', { k: 'W.type', v: 'chai' }); F.click('set', { k: 'W.loc', v: 'MP Nagar' }); F.click('set', { k: 'W.when', v: '10:00 PM' }); F.click('set', { k: 'W.size', v: '3' });
    F.click('post'); await sleep(800);
    const fp = F.ev('S.plans[0].id');
    F.ev(`pl('${fp}').simAt=0;pl('${fp}').members=['me','${riyaId}','u1']`);
    const mkEnded = (id, extra = '') => F.ev(`{const c=JSON.parse(JSON.stringify(P0[0]));Object.assign(c,{id:'${id}',title:'Past ${id}',creator:'u3',members:['u3','me','u1'],reqs:[],status:'ended',roster:['u3','me','u1']${extra}});S.plans.push(c);['u3','me','u1'].forEach(u=>S.attendance.push({id:'a${id}'+u,planId:'${id}',uid:u,status:'present',method:'manual',at:1,token:'',audit:[]}))}`);
    t('feedback is not requested for a future (open) plan', F.ev(`fbEligible(pl('${fp}'))===false&&fbPending().length==0`) && F.ev(`fbSaveMeetup(pl('${fp}'),{rating:5,tags:[],comment:''})`) == 'ineligible');
    F.click('fbOpen', { v: fp });
    t('opening feedback for a future plan is refused with a message', F.said("Feedback isn't open") && F.sheet() == '');
    await F.go('#/plan/' + fp);
    t('open plan page shows no feedback button', !F.html().includes('How was it?'));
    F.ev(`{const c=JSON.parse(JSON.stringify(P0[0]));Object.assign(c,{id:'pcx',creator:'me',members:['me','u1'],reqs:[],status:'cancelled'});S.plans.push(c)}`);
    t('feedback is not requested for a cancelled plan', F.ev("fbEligible(pl('pcx'))===false&&fbSaveMeetup(pl('pcx'),{rating:5})")=='ineligible' && F.ev("fbPending().every(p=>p.id!='pcx')"));
    F.ev('SQUADO_CONFIG.completionConfirmations=0'); F.click('attMark', { k: fp + '|' + riyaId + '|present' }); F.click('attMark', { k: fp + '|u1|present' });
    F.click('end', { v: fp }); await sleep(30);
    t('host wrapping up ends the plan, snapshots who was in it and opens the feedback form', F.ev(`pl('${fp}').status=='ended'&&pl('${fp}').roster.length==3&&typeof pl('${fp}').endedAt=='number'`) && F.sheet().includes('How was Chai') && F.sheet().includes('Overall experience') && (F.sheet().match(/data-a="fbStar"/g) || []).length == 5);
    t('form offers the six quick tags', ['Felt safe', 'Friendly vibe', 'Fun experience', 'Good communication', 'Well organized', 'Would meet again'].every(x => F.sheet().includes(x)));
    t('written feedback is optional and clearly marked', F.sheet().includes('(optional)') && F.sheet().includes('<textarea'));
    t('participants are told, with a notification that opens the plan', F.ev(`S.notifs.filter(n=>n.type=='plan'&&n.planId=='${fp}'&&n.to=='${riyaId}').length==1`) && F.ev(`notifRoute(S.notifs.find(n=>n.planId=='${fp}'&&n.to=='${riyaId}'))`) == '#/plan/' + fp);
    F.click('fbSubmit');
    t('submitting without a rating is refused with a clear message, nothing saved', F.sheet().includes('Pick a star rating first.') && F.ev('S.feedback.length')==0);
    F.click('fbStar', { v: '4' }); F.click('fbTag', { v: 'Felt safe' }); F.click('fbTag', { v: 'Well organized' }); F.click('fbTag', { v: 'Would meet again' }); F.click('fbTag', { v: 'Would meet again' });
    t('stars and several tags can be chosen (and un-chosen)', F.ev('O.fm.rating==4&&O.fm.tags.join()=="Felt safe,Well organized"') && F.sheet().includes('aria-pressed="true" data-a="fbTag"'.replace('aria-pressed="true" ','')) );
    P.fail = false; FP.fail = true;
    F.click('fbSubmit');
    t('while sending: loading state, no double submit', F.sheet().includes('Sending…') && (F.click('fbSubmit'), true));
    await sleep(30);
    t('failed save: understandable error, nothing stored, entered feedback kept, retry offered', F.sheet().includes("We couldn't save your feedback") && F.sheet().includes('Try again') && F.ev("S.feedback.length==0&&O.fm.rating==4&&O.fm.tags.length==2&&!O.fm.done&&!O.fm.busy"));
    FP.fail = false;
    F.type('fm.comment', '   '); /* whitespace-only comment counts as empty */
    F.click('fbSubmit'); await sleep(30);
    const rec = F.ev("JSON.parse(JSON.stringify(S.feedback[0]))");
    t('retry succeeds exactly once: stored against the plan, reviewer, rating, tags, timestamp; empty comment accepted', F.ev('S.feedback.length')==1 && rec.kind == 'meetup' && rec.planId == fp && rec.by == 'me' && rec.rating == 4 && rec.tags.join() == 'Felt safe,Well organized' && rec.comment === '' && rec.at > 0);
    t('clear success confirmation, offers optional squadmate reviews', F.sheet().includes('Thanks, feedback sent') && F.sheet().includes("Anyone you'd like to review?") && F.sheet().includes('Rate members') && F.sheet().includes('Skip for now') && F.sheet().includes("don't need to rate everyone"));
    t('duplicate meetup feedback is refused (function and UI)', F.ev(`fbSaveMeetup(pl('${fp}'),{rating:5,tags:[],comment:''})`) == 'duplicate' && (F.click('fbOpen', { v: fp }), F.said('already sent')) && F.ev('S.feedback.length') == 1);
    F.click('close');
    t('after submitting, nothing is pending and the plan page says so', F.ev('fbPending().length')==0 && (await F.go('#/plan/' + fp), F.html().includes('Feedback sent') && !F.html().includes('How was it?')));
    /* individual reviews */
    t('skipping leaves no individual reviews and the group rating stays saved', F.ev("S.feedback.filter(f=>f.kind=='person').length")==0 && F.ev("S.feedback.filter(f=>f.kind=='meetup').length")==1);
    t('cannot review yourself, someone who was not in the squad, or send an empty selection', F.ev(`fbSavePeople(pl('${fp}'),{me:{r:5,t:['Reliable']}})`) == 'empty' && F.ev(`fbSavePeople(pl('${fp}'),{u7:{r:5,t:['Reliable']}})`) == 'empty' && F.ev(`fbSavePeople(pl('${fp}'),{})`) == 'empty' && F.ev("S.feedback.filter(f=>f.kind=='person').length")==0 && F.ev(`fbTargets(pl('${fp}')).join()=="${riyaId},u1"`));
    t('invalid ratings are refused and nothing is stored', ['0', '6', '"x"', 'null', '2.4e9'].every(v => F.ev(`fbSavePeople(pl('${fp}'),{u1:{r:${v},t:[]}})`) == 'rating') && F.ev("S.feedback.filter(f=>f.kind=='person').length")==0);
    F.click('fbPeople', { v: fp });
    t('step 1 asks who to review, lists only the other participants as selectable, nobody preselected', F.sheet().includes("Anyone you'd like to review?") && F.sheet().includes("don't need to rate everyone") && F.sheet().includes('Riya B') && F.sheet().includes('Aditi') && !F.sheet().includes('data-v="me"') && (F.sheet().match(/data-a="fbPick"/g) || []).length == 2 && F.ev('O.fb.sel.length') == 0 && F.sheet().includes('disabled'));
    F.click('fbCont', { v: fp });
    t('cannot continue without picking anyone, but skipping stays possible', F.ev('O.fb.step') == 'pick' && F.sheet().includes('Skip for now'));
    F.click('fbPick', { k: fp, v: 'u1' });
    t('only the chosen person goes to step 2 (a subset of the squad)', F.ev("O.fb.sel.join()") == 'u1');
    F.click('fbCont', { v: fp });
    t('step 2 shows stars, tags and an optional note for the chosen person only', F.ev('O.fb.step') == 'rate' && F.sheet().includes('Rate who you picked') && F.sheet().includes('Aditi') && !F.sheet().includes('Riya B') && (F.sheet().match(/data-a="fbPStar"/g) || []).length == 5 && F.sheet().includes('<textarea') && F.sheet().includes('Made everyone feel welcome'));
    F.click('fbSend', { v: fp }); await sleep(30);
    t('a chosen person without a star rating blocks sending, with a clear message and nothing stored', F.sheet().includes('Give each person you picked a star rating') && F.ev("S.feedback.filter(f=>f.kind=='person').length")==0);
    F.click('fbPStar', { k: fp + '|u1', v: '4' }); F.click('fbTog', { k: fp + '|u1', v: 'Reliable' }); F.click('fbTog', { k: fp + '|u1', v: 'Made everyone feel welcome' }); F.type('fb.d.u1.c', 'Great <b>company</b>');
    F.click('fbBack', { v: fp }); F.click('fbCont', { v: fp });
    t('going back and forward keeps the rating, tags and note', F.ev("JSON.stringify(O.fb.d.u1)") == JSON.stringify({ r: 4, t: ['Reliable', 'Made everyone feel welcome'], c: 'Great <b>company</b>' }) && F.sheet().includes('&lt;b&gt;company&lt;/b&gt;') && !F.sheet().includes('<b>company</b>'));
    FP.fail = true;
    F.click('fbSend', { v: fp }); await sleep(30);
    t('failed save: clear error, nothing stored, everything entered kept, retry offered', F.sheet().includes("We couldn't save your reviews") && F.sheet().includes('Try again') && F.ev("S.feedback.filter(f=>f.kind=='person').length")==0 && F.ev("O.fb.d.u1.r==4&&O.fb.sel.join()=='u1'&&!O.fb.busy"));
    FP.fail = false;
    F.click('fbSend', { v: fp }); F.click('fbSend', { v: fp }); await sleep(30);
    const pr = F.ev("JSON.parse(JSON.stringify(S.feedback.filter(f=>f.kind=='person')))");
    t('retry (even double-tapped) stores exactly one record against the right plan, reviewer, person, rating, tags, note', pr.length == 1 && pr[0].planId == fp && pr[0].by == 'me' && pr[0].to == 'u1' && pr[0].rating == 4 && pr[0].tags.join() == 'Reliable,Made everyone feel welcome' && pr[0].comment == 'Great <b>company</b>' && pr[0].at > 0 && F.sheet() == '');
    t('the person who was not picked has no record at all, and group and individual records stay separate', F.ev(`S.feedback.every(f=>f.kind=='meetup'?f.to===undefined:f.to=='u1')`) && F.ev("S.feedback.filter(f=>f.kind=='meetup').length")==1);
    t('the same person cannot be reviewed twice for the same plan', F.ev(`fbSavePeople(pl('${fp}'),{u1:{r:1,t:[]}})`) == 'duplicate' && F.ev("S.feedback.filter(f=>f.kind=='person').length") == 1);
    t('plan page shows the status without nagging: group sent, 1 of 2 member reviews, quiet optional entry', await (async () => { await F.go('#/plan/' + fp); return F.html().includes('Your rating: 4') && F.html().includes('Member reviews: 1 of 2') && F.html().includes('Review more members (optional)'); })());
    /* reputation maths (records are injected for people other than the signed-in account, then removed again) */
    F.ev(`S.feedback.push({id:'tx1',kind:'person',planId:'${fp}',by:'x1',to:'u2',rating:5,tags:['Respectful'],comment:'',at:1},{id:'tx2',kind:'person',planId:'${fp}',by:'x2',to:'u2',rating:4,tags:['Respectful','Reliable'],comment:'',at:1},{id:'tx3',kind:'person',planId:'${fp}',by:'x3',to:'u2',rating:4,tags:[],comment:'',at:1})`);
    t('average and count come only from real ratings (5, 4, 4 → 4.3 from 3)', F.ev("fbAgg(usr('u2')).n") == 3 && F.ev("fbAgg(usr('u2')).avg") == 4.3 && F.ev("fbAgg(usr('u2')).tags.Respectful") == 2 && F.ev("fbs(usr('u2'))").includes('4.3 ★ · 3 ratings'));
    F.ev(`S.feedback.push({id:'tx4',kind:'meetup',planId:'${fp}',by:'x4',rating:1,tags:['Felt safe'],comment:'',at:1},{id:'tx5',kind:'person',planId:'${fp}',by:'x5',to:'u2',tags:['Friendly vibe'],again:'Not really',at:1})`);
    t('meetup ratings and older tag-only reviews never change the star average or count', F.ev("fbAgg(usr('u2')).n") == 3 && F.ev("fbAgg(usr('u2')).avg") == 4.3);
    t('unrated people get no number: no zero, no NaN, a neutral message', F.ev("fbAgg(usr('u5')).n") == 0 && F.ev("fbAgg(usr('u5')).avg") === null && F.ev("fbs(usr('u5'))").includes('Not rated yet') && !/NaN|0 ★/.test(F.ev("fbs(usr('u5'))")));
    t('1-2 ratings show a neutral "not enough yet" instead of an identifying number', F.ev("fbAgg(usr('u1')).n") == 1 && F.ev("fbs(usr('u1'))").includes('Not enough ratings') && !F.ev("fbs(usr('u1'))").includes('★ ·'));
    t('fixtures contain no invented ratings or review totals', F.ev("U.every(u=>u.fb===undefined)") && F.ev("S.users.filter(u=>!u.real).every(u=>fbAgg(u).n==(u.id=='u1'?1:u.id=='u2'?3:0))"));
    F.ev("S.feedback=S.feedback.filter(f=>!f.id.startsWith('tx'))");
    F.click('noshow', { k: fp, v: 'u1' }); F.click('noshow', { k: fp, v: 'u1' });
    t('host can mark a no-show once (one record, audited); they stop being eligible', F.ev(`attGet(pl('${fp}'),'u1').status=='absent'&&S.attendance.filter(a=>a.planId=='${fp}'&&a.uid=='u1').length==1&&attGet(pl('${fp}'),'u1').audit.filter(x=>x.action=='manual').length==2`) && F.ev(`fbRoster(pl('${fp}')).includes('u1')`) === false);
    /* pending prompt, postponing, expiry */
    mkEnded('pe1'); mkEnded('pe2');
    await F.go('#/home');
    t('home asks about plans still waiting for feedback', F.html().includes('How was Past pe1?') && F.html().includes('Give feedback') && F.html().includes('Later'));
    F.click('fbOpen', { v: 'pe1' }); F.click('fbLater', { v: 'pe1' });
    t('"Later" postpones without marking it done', F.ev("fbFind(pl('pe1'),'meetup')")===undefined && F.ev("S.fbLater.pe1>Date.now()&&fbPending().every(p=>p.id!='pe1')") && !F.html().includes('How was Past pe1?'));
    await F.go('#/plan/pe1');
    t('postponed feedback is still reachable from the plan page', F.html().includes('How was it?'));
    F.ev("S.fbLater.pe1=1");
    t('postponed prompt returns once the delay has passed', F.ev("fbPending().some(p=>p.id=='pe1')"));
    F.ev("delete S.fbLater.pe1");
    /* persistence */
    const F2 = boot(FP); await sleep(100);
    t('feedback persists after a refresh (records and "submitted" state)', F2.ev(`S.feedback.length==2&&!!fbFind(pl('${fp}'),'meetup')&&fbPending().every(p=>p.id!='${fp}')`));
    t('earlier plans and profile are untouched by the feature', F2.ev(`pl('${fp}').members.length==3&&S.me.username=='somya_t'&&S.me.onboarded===true`));
    await logout(F2);
    t('sign-out leaves no stale "me" in plans (members, attendance, completion) or in feedback records', !F2.ev('JSON.stringify(S.plans)').includes('"me"') && !F2.ev('JSON.stringify(S.attendance)').includes('"me"') && !F2.ev('JSON.stringify(S.feedback)').includes('"me"'));
    /* account separation + privacy */
    await signIn(F2, 'riya_b'); await sleep(50);
    t("another account: own pending prompt; the first person's feedback does not count for them", F2.ev(`fbEligible(pl('${fp}'))&&!fbFind(pl('${fp}'),'meetup')&&fbPending().some(p=>p.id=='${fp}')&&S.feedback.every(f=>f.by!='me')`));
    F2.click('notifs');
    t('the "How was it?" notification is addressed to them and opens the plan', F2.sheet().includes('How was Chai') && (F2.click('notifGo', { v: F2.ev(`myNotifs().find(n=>n.planId=='${fp}').id`) }), await sleep(60), F2.h == '#/plan/' + fp));
    t('their plan page offers feedback', F2.html().includes('How was it?'));
    t('they cannot review themselves', F2.ev(`fbSavePeople(pl('${fp}'),{me:{r:5,t:['Reliable']}})`) == 'empty');
    F2.click('fbOpen', { v: fp }); F2.click('fbStar', { v: '5' }); F2.click('fbTag', { v: 'Friendly vibe' }); F2.type('fm.comment', 'secret-comment-xyz');
    F2.click('fbSubmit'); await sleep(30);
    t('second account submits their own, separate record', F2.ev(`S.feedback.filter(f=>f.kind=='meetup'&&f.planId=='${fp}'&&f.by=='me').length==1&&S.feedback.filter(f=>f.kind=='meetup').length==2`));
    F2.click('close');
    const tg = F2.ev(`fbTargets(pl('${fp}'))[0]`);
    F2.click('fbPeople', { v: fp }); F2.click('fbPick', { k: fp, v: tg }); F2.click('fbCont', { v: fp }); F2.click('fbPStar', { k: fp + '|' + tg, v: '3' }); F2.click('fbTog', { k: fp + '|' + tg, v: 'Respectful' }); F2.click('fbSend', { v: fp }); await sleep(30);
    await logout(F2);
    await signUp(F2, 'Carol', 'carol_c'); await sleep(50);
    t('a signed-in person who was not in the squad cannot send feedback or reviews', F2.ev(`fbEligible(pl('${fp}'))===false&&fbSaveMeetup(pl('${fp}'),{rating:5})=="ineligible"&&fbSavePeople(pl('${fp}'),{u1:{r:5,t:['Reliable']}})=="ineligible"&&fbPending().length==0`) && (F2.click('fbOpen', { v: fp }), F2.said("Feedback isn't open")));
    await F2.go('#/plan/' + fp);
    t('...and sees neither the form nor any feedback totals or comments', !F2.html().includes('How was it?') && !F2.html().includes('Squad feedback') && !F2.html().includes('secret-comment-xyz'));
    await logout(F2);
    t('a guest cannot send feedback', F2.ev(`fbSaveMeetup(pl('${fp}'),{rating:5})`) == 'ineligible');
    /* host again: totals only, with 3+ responses, no comments, no reviewer identity */
    F2.ev(`S.feedback.push({id:'fx',kind:'meetup',planId:'${fp}',by:'u1',rating:3,tags:['Felt safe'],comment:'private-note',at:1})`);
    await signIn(F2, 'somya_t'); await sleep(50);
    await F2.go('#/plan/' + fp);
    t('host sees anonymous totals computed from the stored responses (average of 4, 5, 3)', F2.html().includes('Squad feedback') && F2.html().includes('4 / 5 from 3 anonymous responses') && F2.html().includes('Felt safe · 2'));
    t('comments and reviewer identities are never shown to others', !F2.html().includes('secret-comment-xyz') && !F2.html().includes('private-note') && !F2.sheet().includes('secret-comment-xyz'));
    t("reviews about the host reach their own profile totals; their data is intact", F2.ev("fbAgg(S.me).n")==1 && F2.ev(`S.feedback.filter(f=>f.kind=='person'&&f.to=='me').length==1`) && F2.ev("S.me.name=='Somya'&&S.me.city=='Bhopal'&&S.me.onboarded===true"));
    await F2.go('#/me');
    t('profile page still renders with feedback data', F2.html().includes('Somya') && !F2.html().includes('undefined'));
    t("only a plan's host can mark no-shows", await (async () => { await logout(F2); await signIn(F2, 'riya_b'); const before = F2.ev(`S.attendance.filter(a=>a.status=='absent').length`); F2.click('noshow', { k: fp, v: F2.ev(`fbTargets(pl('${fp}'))[0]`) }); return F2.ev(`S.attendance.filter(a=>a.status=='absent').length`) == before; })());
    t('sending feedback leaves location, auth and onboarding state untouched', F2.ev("S.me.city=='Bhopal'&&S.me.sub=='g-riya'&&S.me.onboarded===true&&S.acct&&CITIES.join()=='Bhopal'"));

    /* ---------- Google sign-in diagnostics (local origin, client ID handling) ---------- */
    {
        const LOC = { host: '127.0.0.1', port: 3000 };
        const D = boot(newP(), { ...LOC, noClient: 1 }); D.ident = ID.somya_t; D.click('gGoogle'); await sleep(30);
        t('no client ID on 127.0.0.1:3000: says so, names the exact origin to authorize (no path/query), offers local ID entry; no popup, no sign-in', D.sheet().includes("Google sign-in isn't set up") && D.sheet().includes('http://127.0.0.1:3000') && !D.sheet().includes('vscode-livepreview') && D.sheet().includes('data-a="gDevSave"') && D.gCalls == 0 && D.ev('S.me.guest'));
        D.type('dev.cid', 'not-a-client-id'); D.click('gDevSave');
        t('a malformed client ID is rejected with a clear message and is not saved or used', D.sheet().includes('Google client ID looks wrong') && !D.ev("localStorage.getItem('squado-dev-google-client-id')") && D.gCalls == 0);
        D.type('dev.cid', D.CID); D.click('gDevSave');
        t('a valid pasted ID is kept only in this origin\'s local storage', D.ev("localStorage.getItem('squado-dev-google-client-id')") == D.CID && D.ev('gClientId()') == D.CID && D.sheet().includes('Continue with Google'));
        D.click('gGoogle'); await sleep(80);
        t('with that ID the real flow runs end to end (popup asked, identity checked, onboarding opens)', D.gCalls == 1 && D.gOpts.prompt == 'select_account' && D.ev("S.me.sub=='g-somya'&&S.me.onboarded===false") && D.html().includes('What should we call you?'));
        t('a new project copy served from the same origin keeps working without editing config.js', await (async () => { const store = D.ev('localStorage.getItem("squado-dev-google-client-id")'); const P2 = newP(); P2.store['squado-dev-google-client-id'] = store; const N = boot(P2, { ...LOC, noClient: 1 }); N.ident = ID.riya_b; N.click('gGoogle'); await sleep(80); return N.gCalls == 1 && N.ev("S.me.sub=='g-riya'"); })());
        t('config.js wins over the local fallback', await (async () => { const P2 = newP(); P2.store['squado-dev-google-client-id'] = 'other.apps.googleusercontent.com'; const N = boot(P2, LOC); return N.ev('gClientId()') == N.CID; })());
        t('on a non-local host the local fallback is ignored and no ID entry is offered', await (async () => { const P2 = newP(); P2.store['squado-dev-google-client-id'] = 'x.apps.googleusercontent.com'; const N = boot(P2, { host: 'user.github.io', proto: 'https:', noClient: 1 }); N.click('gGoogle'); await sleep(30); return N.ev('gClientId()') === '' && N.sheet().includes("isn't set up") && !N.sheet().includes('data-in="dev.cid"') && N.sheet().includes('https://user.github.io') && N.gCalls == 0; })());
        t('a malformed ID in config.js is reported, never sent to Google', await (async () => { const N = boot(newP(), LOC); N.ev("SQUADO_CONFIG.googleClientId='abc123'"); N.click('gGoogle'); await sleep(30); return N.sheet().includes('looks wrong') && N.gCalls == 0; })());
        t('opened from file:// is explained instead of failing oddly', await (async () => { const N = boot(newP(), { host: '', proto: 'file:' }); N.click('gGoogle'); await sleep(30); return N.sheet().includes('file://') && N.gCalls == 0; })());
        t('closed popup shows the origin to check (origin_mismatch / invalid_client hint) and stays signed out', await (async () => { const N = boot(newP(), LOC); N.gmode = 'cancel'; N.ident = ID.somya_t; N.click('gGoogle'); await sleep(60); return N.sheet().includes('Sign-in cancelled') && N.sheet().includes('origin_mismatch') && N.sheet().includes('http://127.0.0.1:3000') && N.ev('S.me.guest&&S.acct===null'); })());
        t('Google script that loads late is waited for instead of reported as a network error', await (async () => { const N = boot(newP(), LOC); N.ident = ID.somya_t; const g = N.ev('window.google'); N.ev('window.google=undefined'); N.click('gGoogle'); const early = N.sheet().includes('Connecting to Google'); setTimeout(() => N.ctx.google = g, 300); await sleep(700); return early && N.gCalls == 1 && N.ev("S.me.sub=='g-somya'"); })());
        t('there is no development-only or fallback login: shipped code contains no mock sign-in path', !/mockLogin|fakeLogin|devLogin|simulateSignIn/i.test(['app/auth.js', 'components/auth/AuthGate.js'].map(f => fs.readFileSync('src/js/' + f, 'utf8')).join('')));
        t('feedback still works after a Google sign-in on the local origin', await (async () => { const N = boot(newP(), LOC); N.ident = ID.somya_t; N.click('gGoogle'); await sleep(80); return N.ev("typeof fbAgg=='function'&&fbAgg(S.me).n===0&&fbs(S.me).includes('Not rated yet')"); })());
    }

    /* ---------- QR attendance, completion, verified-attendee feedback, derived stats ---------- */
    {
        const QP = newP(); const Q = boot(QP, { host: 'user.github.io', proto: 'https:' }); await sleep(100);
        const mk = async (name, key) => { await signUp(Q, name, key); const id = Q.ev('S.acct'); await logout(Q); return id; };
        const riya = await mk('Riya Q', 'riya_b'), sam = await mk('Sam Q', 'sam_s'), zed = await mk('Zed Q', 'zed_z');
        await signUp(Q, 'Hana Q', 'somya_t');
        const plan = (id, extra = '') => Q.ev(`{const c=JSON.parse(JSON.stringify(P0[0]));Object.assign(c,{id:'${id}',title:'QR ${id}',creator:'me',members:['me','${riya}','${sam}','${zed}','u1'],reqs:[],status:'open'${extra}});delete c.roster;S.plans.push(c)}`);
        const as = async key => { await logout(Q); await signIn(Q, key); };
        plan('pq1'); plan('pq2'); plan('pq3', ",status:'cancelled'");
        const hex = /^[0-9a-f]{32}$/;
        Q.ev("SQUADO_CONFIG.appBaseUrl=''");
        t('no deployed address configured: no QR link is made and nothing is guessed', Q.ev("attStart(pl('pq1'))") == 'ok' && Q.ev("attUrl(pl('pq1')).err") == 'nobase');
        const bad = ['http://127.0.0.1:3000/', 'https://localhost/', 'http://user.github.io/x/', 'https://192.168.1.5/', 'not a url', 'https://intranet/'];
        t('localhost, private, plain-http or malformed addresses are never used for QR links', bad.every(b => { Q.ev(`SQUADO_CONFIG.appBaseUrl=${JSON.stringify(b)}`); return Q.ev("attUrl(pl('pq1')).err") == 'badbase'; }));
        Q.ev("SQUADO_CONFIG.appBaseUrl='https://user.github.io/squado/'");
        const u1 = Q.ev("attUrl(pl('pq1')).url"), tok1 = Q.ev("pl('pq1').checkin.token");
        t('QR link = deployed https address (with repo path) + meetup + random 128-bit token, nothing personal', u1 == `https://user.github.io/squado/#/checkin/pq1/${tok1}` && hex.test(tok1) && !/hana|somya|@|localhost|127\./i.test(u1));
        t('starting check-in creates the organizer\'s own single record and no one else\'s', Q.ev("S.attendance.filter(a=>a.planId=='pq1').length") == 1 && Q.ev("attGet(pl('pq1'),'me').method") == 'organizer' && Q.ev("pl('pq1').checkin.expiresAt-pl('pq1').checkin.openedAt") == 6 * 36e5);
        Q.click('attQr', { v: 'pq1' });
        t('organizer sees the QR code and link; closing the sheet works', Q.sheet().includes('data-qr') && Q.sheet().includes(tok1) && Q.qrData == u1);
        Q.click('close');
        await Q.go('#/plan/pq1');
        t('organizer panel: count, per-member status, "not checked in" is not "absent"', Q.html().includes('1 of 5') && Q.html().includes('Not checked in yet') && !Q.html().includes('Marked absent') && Q.html().includes('Close check-in'));
        Q.ev("attStart(pl('pq1'))"); const tok2 = Q.ev("pl('pq1').checkin.token");
        t('a new code replaces the old one at once', tok2 != tok1 && Q.ev(`attCheck(pl('pq1'),'${tok1}')`) == 'revoked');
        Q.ev("attStart(pl('pq3'))");
        t('cancelled plans can\'t start check-in', Q.ev("attStart(pl('pq3'))") == 'state');

        /* a guest opens the phone-camera link */
        await logout(Q);
        await Q.go(`#/checkin/pq1/${tok2}`);
        t('opened while signed out: asks to sign in and does not record anything', Q.html().includes('Sign in to check in') && Q.ev("S.attendance.filter(a=>a.planId=='pq1').length") == 1);
        Q.click('checkinSignIn'); await sleep(30);
        Q.ident = ID.riya_b; Q.click('gGoogle'); await sleep(120);
        t('after signing in they return to the same check-in page, not Home', Q.h == `#/checkin/pq1/${tok2}` && Q.html().includes('Check me in'));
        t('opening the link alone records no attendance', Q.ev("attGet(pl('pq1'),'me')") === null);
        Q.click('checkinGo', { k: 'pq1|' + tok2 }); Q.click('checkinGo', { k: 'pq1|' + tok2 }); await sleep(30);
        const ra = Q.ev("JSON.parse(JSON.stringify(attGet(pl('pq1'),'me')))");
        t('tapping once creates exactly one verified record (method native_camera, time set by the app, token reference only)', ra.status == 'present' && ra.method == 'native_camera' && typeof ra.at == 'number' && Math.abs(ra.at - Date.now()) < 5000 && ra.token == tok2.slice(0, 8) && Q.ev("S.attendance.filter(a=>a.planId=='pq1'&&a.uid=='me').length") == 1 && Q.html().includes('checked in'));
        t('scanning again (either way) is a harmless duplicate: no new record, same count', Q.ev(`scanHandle(${JSON.stringify(u1.replace(tok1, tok2))})`) === undefined && Q.sheet().includes('Already checked in') && Q.ev("S.attendance.filter(a=>a.planId=='pq1').length") == 2 && Q.ev("attCount(pl('pq1'))") == 2);
        t('check-in alone does not complete the meetup', Q.ev("pl('pq1').status") == 'open' && Q.ev("lifeState(pl('pq1'))") == 'awaiting_completion');
        t('feedback stays locked before completion, with the reason shown', Q.ev("fbEligible(pl('pq1'))") === false && Q.ev("fbSaveMeetup(pl('pq1'),{rating:5})") == 'ineligible' && Q.ev("fbLockReason(pl('pq1'))").includes('opens after the host confirms'));

        /* Sam: in-app scanner path + every rejection */
        await as('sam_s');
        const cases = { garbage: ['x', 'invalid'], wrongLen: ['abc', 'invalid'], otherPlanToken: [Q.ev("pl('pq3').checkin&&pl('pq3').checkin.token")||'0'.repeat(32), 'invalid'], revoked: [tok1, 'revoked'] };
        t('invalid, other-meetup and revoked codes are rejected and record nothing', Object.values(cases).every(([tk, want]) => Q.ev(`attCheckIn('pq1','${tk}','in_app_scanner')`) == want) && Q.ev("S.attendance.filter(a=>a.planId=='pq1'&&a.uid=='me').length") == 0 && Q.ev(`attCheckIn('nope','${tok2}','in_app_scanner')`) == 'noplan' && Q.ev(`attCheckIn('pq3','${tok2}','in_app_scanner')`) == 'cancelled');
        t('unknown check-in methods are refused', Q.ev(`attCheckIn('pq1','${tok2}','telepathy')`) == 'method' && Q.ev(`attCheckIn('pq1','${tok2}','manual')`) == 'method');
        Q.ev("pl('pq1').checkin.expiresAt=Date.now()-1");
        t('expired code is rejected', Q.ev(`attCheckIn('pq1','${tok2}','in_app_scanner')`) == 'expired');
        Q.ev("pl('pq1').checkin.expiresAt=Date.now()+1e6;pl('pq1').checkin.closed=true");
        t('closed session is rejected', Q.ev(`attCheckIn('pq1','${tok2}','in_app_scanner')`) == 'closed');
        Q.ev("pl('pq1').checkin.closed=false");
        Q.ev("window.jsQR=()=>null");
        Q.click('scanOpen'); await sleep(40);
        t('camera is only requested after the person starts scanning, and the scanner sheet offers the paste-link fallback', Q.camCalls == 1 && Q.sheet().includes('Scan to check in') && Q.sheet().includes('data-in="scan.code"'));
        const st = Q.streams[Q.streams.length - 1];
        Q.click('close');
        t('closing the scanner stops the camera stream', st.stopped === 1);
        Q.type('scan.code', 'hello'); Q.click('scanManual');
        t('pasting something that is not a Squado check-in link is rejected', Q.sheet().includes("That code isn't valid") && Q.ev("attGet(pl('pq1'),'me')") === null);
        Q.type('scan.code', u1.replace(tok1, tok2)); Q.click('scanManual');
        t('a valid scan through the in-app scanner records the same kind of record (method in_app_scanner)', Q.sheet().includes("You're checked in") && Q.ev("attGet(pl('pq1'),'me').method") == 'in_app_scanner' && Q.ev("attGet(pl('pq1'),'me').status") == 'present' && Q.streams.every(x => x.stopped === 1));
        Q.cam = { name: 'NotAllowedError' }; Q.click('close'); Q.click('scanOpen'); await sleep(40);
        t('camera permission denied: clear message, paste fallback, no crash', Q.sheet().includes('Camera permission was denied') && Q.sheet().includes('data-in="scan.code"'));
        Q.cam = { name: 'NotFoundError' }; Q.click('scanOpen'); await sleep(40);
        t('no camera available: clear message', Q.sheet().includes('No camera was found'));
        const nav = Q.ev('navigator.mediaDevices'); Q.ev('navigator.mediaDevices=undefined'); Q.click('scanOpen'); await sleep(20);
        t('browser without camera support: clear message and fallback', Q.sheet().includes("can't open the camera") && Q.sheet().includes('data-in="scan.code"'));
        Q.click('close'); Q.cam = { ok: 1 };

        /* Zed: not scanning, claims; non-members and guests */
        await as('carol_c');
        t('a signed-in person who is not in the squad cannot check in', Q.ev(`attCheckIn('pq1','${tok2}','in_app_scanner')`) == 'notmember' && Q.ev("S.attendance.filter(a=>a.planId=='pq1').length") == 3);
        await logout(Q);
        t('a guest cannot check in (and nothing is stored)', Q.ev(`attCheckIn('pq1','${tok2}','native_camera')`) == 'auth' && Q.ev("S.attendance.filter(a=>a.planId=='pq1').length") == 3);

        await as('zed_z');
        t('a member who did not scan has no record and feedback stays locked ("not checked in" is not "absent")', Q.ev("attGet(pl('pq1'),'me')") === null && Q.ev("fbEligible(pl('pq1'))") === false);
        Q.click('attClaim', { v: 'pq1' });
        t('"I was there" is an unverified claim: one record, not verified, does not count as present', Q.ev("attGet(pl('pq1'),'me').status") == 'claimed' && Q.ev("attCount(pl('pq1'))") == 3 && Q.ev("attClaim(pl('pq1'))") == 'duplicate');

        /* Hana: manual attendance */
        await as('somya_t');
        t('organizer: manual present for someone who could not scan; repeating is a no-op', Q.ev(`attManual(pl('pq1'),'u1','present','')`) == 'ok' && Q.ev(`attManual(pl('pq1'),'u1','present','')`) == 'unchanged' && Q.ev("S.attendance.filter(a=>a.planId=='pq1'&&a.uid=='u1').length") == 1 && Q.ev("attGet(pl('pq1'),'u1').audit.length") == 1);
        t('a manual correction (absent then present again) keeps ONE record with an audit trail (who, when, why)', Q.ev(`attManual(pl('pq1'),'u1','absent','left early')`) == 'ok' && Q.ev(`attManual(pl('pq1'),'u1','present','was there after all')`) == 'ok' && Q.ev("S.attendance.filter(a=>a.planId=='pq1'&&a.uid=='u1').length") == 1 && Q.ev("attGet(pl('pq1'),'u1').audit.map(x=>x.reason).join('|')").includes('left early') && Q.ev("attGet(pl('pq1'),'u1').audit.every(x=>x.by==='me'&&x.at>0)") && Q.ev("attCount(pl('pq1'))") == 4);
        t('organizer verifies the claimed member (counts once) and cannot be marked absent themselves', Q.ev(`attManual(pl('pq1'),'${zed}','present','claimed, verified')`) == 'ok' && Q.ev("attCount(pl('pq1'))") == 5 && Q.ev(`attManual(pl('pq1'),'me','absent','')`) == 'forbidden' && Q.ev(`attManual(pl('pq1'),'${riya}','nonsense','')`) == 'status');
        Q.ev(`attManual(pl('pq1'),'${zed}','absent','')`);
        await as('zed_z');
        t('an organizer-marked absent member who scans only opens a dispute; it never overrules the organizer', Q.ev(`attCheckIn('pq1','${tok2}','native_camera')`) == 'disputed' && Q.ev("attGet(pl('pq1'),'me').status") == 'absent' && !!Q.ev("attGet(pl('pq1'),'me').dispute") && Q.ev("fbEligible(pl('pq1'))") === false && Q.ev("attPresent(pl('pq1'),'me')") === false);
        await as('riya_b');
        t('ordinary members cannot edit anyone\'s attendance', Q.ev(`attManual(pl('pq1'),'${sam}','absent','')`) == 'forbidden' && Q.ev(`attManual(pl('pq1'),'me','present','')`) == 'forbidden' && Q.ev("attStart(pl('pq1'))") == 'forbidden' && Q.ev("attClose(pl('pq1'))") == 'forbidden' && Q.ev("compHost(pl('pq1'))") == 'forbidden');
        t('members do not see other people\'s attendance', !(await (async () => { await Q.go('#/plan/pq1'); return Q.html().includes('checked in or marked present') || Q.html().includes('Marked absent') || Q.html().includes('data-a="attMark"'); })()) && Q.html().includes('Your attendance'));

        /* completion */
        await as('somya_t');
        Q.ev(`attManual(pl('pq1'),'${zed}','present','dispute resolved')`);
        t('organizer resolving the dispute (marking present) clears it and the member is verified', !Q.ev(`attGet(pl('pq1'),'${zed}').dispute`) && Q.ev(`attPresent(pl('pq1'),'${zed}')`) === true);
        Q.click('end', { v: 'pq1' }); await sleep(30);
        t('organizer confirms: meetup is pending, NOT completed, and nobody was auto-marked present', Q.ev("pl('pq1').status") == 'open' && Q.ev("lifeState(pl('pq1'))") == 'completion_pending' && Q.ev("S.attendance.filter(a=>a.planId=='pq1').length") == 5 && Q.ev("fbEligible(pl('pq1'))") === false);
        t('verified attendees are asked once to confirm (no duplicate notifications)', Q.ev(`S.notifs.filter(n=>n.planId=='pq1'&&n.key=='comp').length`) == 4 && (Q.click('end', { v: 'pq1' }), Q.ev(`S.notifs.filter(n=>n.planId=='pq1'&&n.key=='comp').length`) == 4));
        t('feedback is still locked while confirmations are missing', Q.ev("fbSaveMeetup(pl('pq1'),{rating:5})") == 'ineligible' && Q.ev("fbSaveMeetup(pl('pq1'),{rating:5})") == 'ineligible');
        await as('riya_b');
        t('an attendee\'s confirmation alone is not completion; the organizer already confirmed, so it completes only now', Q.ev("pl('pq1').status") == 'open' && Q.ev("compMember(pl('pq1'),'confirm')") == 'completed' && Q.ev("pl('pq1').status") == 'ended' && Q.ev("lifeState(pl('pq1'))") == 'completed');
        t('verified attendee can send one group rating; a second is refused', Q.ev("fbEligible(pl('pq1'))") === true && Q.ev("fbSaveMeetup(pl('pq1'),{rating:5,tags:['Felt safe'],comment:'x'})") == 'ok' && Q.ev("fbSaveMeetup(pl('pq1'),{rating:4})") == 'duplicate' && Q.ev("S.feedback.filter(f=>f.kind=='meetup').length") >= 1);
        t('individual ratings: optional, only verified attendees, no self, no duplicates', Q.ev(`fbSavePeople(pl('pq1'),{me:{r:5}})`) == 'empty' && Q.ev(`fbSavePeople(pl('pq1'),{${sam}:{r:4,t:['Respectful']}})`) == 'ok' && Q.ev(`fbSavePeople(pl('pq1'),{${sam}:{r:1}})`) == 'duplicate' && Q.ev("S.feedback.filter(f=>f.kind=='person').length") == 1);
        await as('sam_s');
        t('Sam\'s reputation counts that one rating; group ratings never enter it; unrated people get no number', Q.ev("fbAgg(S.me).n") == 1 && Q.ev("fbAgg(S.me).avg") == 4 && Q.ev("fbAgg(usr('u1')).avg") === null);

        /* Zed: attended after dispute resolved, can rate; a non-attendee cannot */
        await as('zed_z');
        t('a member whose attendance the organizer verified (after a dispute) is eligible once completed', Q.ev("fbEligible(pl('pq1'))") === true);

        /* disputes + rules for a second plan */
        await as('somya_t');
        Q.ev("attStart(pl('pq2'))"); const t3 = Q.ev("pl('pq2').checkin.token");
        await as('sam_s'); Q.ev(`attCheckIn('pq2','${t3}','native_camera')`);
        await as('somya_t'); Q.ev("compHost(pl('pq2'))");
        await as('sam_s');
        t('an attendee who disputes keeps the meetup open and feedback locked', Q.ev("compMember(pl('pq2'),'dispute')") == 'disputed' && Q.ev("lifeState(pl('pq2'))") == 'disputed' && Q.ev("pl('pq2').status") == 'open' && Q.ev("fbEligible(pl('pq2'))") === false);
        t('only verified attendees may confirm or dispute (a non-attendee cannot)', (await (async () => { await as('zed_z'); return Q.ev("compMember(pl('pq2'),'confirm')") == 'forbidden' && Q.ev("compMember(pl('pq2'),'dispute')") == 'forbidden'; })()));
        await as('somya_t');
        t('organizer can resolve by correcting the disputed attendance; then completion proceeds', Q.ev(`attManual(pl('pq2'),'${sam}','absent','not there')`) == 'ok' && Q.ev("compHost(pl('pq2'))") == 'completed' && Q.ev("pl('pq2').status") == 'ended' && Q.ev("fbRoster(pl('pq2')).join()") == 'me');
        t('with no other verified attendee a completed meetup has no feedback (needs 2+ attendees)', Q.ev("fbEligible(pl('pq2'))") === false);
        t('cancelled meetup: no check-in, no feedback', Q.ev("fbEligible(pl('pq3'))") === false && Q.ev("fbSaveMeetup(pl('pq3'),{rating:5})") == 'ineligible' && Q.ev("lifeState(pl('pq3'))") == 'cancelled');

        /* stats derived from records */
        const rs = () => Q.ev("JSON.stringify(relOf(S.me))");
        await as('riya_b'); const r1 = JSON.parse(rs());
        Q.ev(`attCheckIn('pq1','${tok2}','native_camera')`); Q.ev("attManual(pl('pq1'),'me','present','')"); Q.ev(`attClaim(pl('pq1'))`);
        t('profile stats: attended counts distinct completed meetups with verified attendance once; repeats change nothing', r1.attended == 1 && r1.joined == 3 && r1.hosted == 0 && JSON.parse(rs()).attended == 1);
        await as('somya_t'); const h1 = JSON.parse(rs());
        t('organizer stats: hosted, organized (completed) and attended come from records, with no double counting', h1.hosted == 3 && h1.organized == 2 && h1.attended == 2 && h1.noshow == 0);
        t('absent marks are counted once from the record, never from a counter', (() => { Q.ev(`attManual(pl('pq1'),'${sam}','absent','x')`); Q.ev(`attManual(pl('pq1'),'${sam}','absent','x')`); return true; })() && (await (async () => { await as('sam_s'); return JSON.parse(rs()).noshow >= 1 && JSON.parse(rs()).noshow == Q.ev("S.attendance.filter(a=>a.uid=='me'&&a.status=='absent'&&!a.dispute&&pl(a.planId).status=='ended').length"); })()));
        t('demo profiles keep their fixed demo numbers and are not recomputed', Q.ev("JSON.stringify(relOf(usr('u3')))") == Q.ev("JSON.stringify({...usr('u3').rel,attended:usr('u3').rel.completed})"));

        /* persistence + a failed save */
        const Q2 = boot(QP, { host: 'user.github.io', proto: 'https:' }); await sleep(100);
        t('attendance, completion and feedback survive a refresh', Q2.ev("S.attendance.filter(a=>a.planId=='pq1').length") == 5 && Q2.ev("pl('pq1').status") == 'ended' && Q2.ev("S.feedback.length") == 2);
        if (Q2.ev('S.me.guest') || Q2.ev('S.me.name') != 'Hana Q') await signIn(Q2, 'somya_t');
        Q2.ev(`{const c=JSON.parse(JSON.stringify(P0[0]));Object.assign(c,{id:'pq4',title:'QR pq4',creator:'me',members:['me','u1'],reqs:[],status:'open'});S.plans.push(c)}`);
        const before = Q2.ev("JSON.stringify(S.attendance)");
        QP.fail = true;
        t('a failed save changes nothing (no session, no organizer record) and is reported', Q2.ev("attStart(pl('pq4'))") == 'save' && Q2.ev("pl('pq4').checkin") === undefined && Q2.ev("JSON.stringify(S.attendance)") == before && Q2.ev("attManual(pl('pq4'),'u1','present','')") == 'save' && Q2.ev("JSON.stringify(S.attendance)") == before);
        QP.fail = false;
        t('QR/attendance code contains no mock check-in or hidden bypass', !/mockCheck|fakeCheck|bypass|skipVerify/i.test(['state/attendance.js', 'components/squads/AttendanceSheet.js'].map(f => fs.readFileSync('src/js/' + f, 'utf8')).join('')));
    }


    /* =====================================================================================================
       SECTION 01: authentication, route protection, membership access and privacy
       ===================================================================================================== */
    {
        const AP = newP();
        let X = boot(AP); await sleep(100);
        const mkPlan = (id, extra = '') => X.ev(`S.plans.unshift(Object.assign({id:'${id}',creator:'me',type:'chai',title:'Chai ${id}',desc:'d',vibe:[],loc:'MP Nagar',city:'Bhopal',when:'10:00 PM',live:false,max:5,members:['me'],who:'Everyone',reqs:[],status:'open',day:'Today',spot:'secret-spot-${id}',created:Date.now()},${extra || '{}'}));S.msgs['${id}']=[{sys:1,x:'sys'},{by:'me',x:'private-hello-${id}',t:'1:00 PM'}];save()`);
        const msgsOf = id => X.ev(`(S.msgs['${id}']||[]).length`);

        /* ---------- guests: public browsing, no identities, no private actions ---------- */
        await X.go('#/home'); await X.go('#/explore');
        t('S01 guests can browse Home and Discover', X.html().includes('Poha jalebi run') || X.html().includes('Anyone still dancing?'));
        await X.go('#/plan/p1');
        t('S01 guest plan page: public details, no member identities, no profile buttons', X.html().includes('Anyone still dancing?') && !X.html().includes('data-a="user"') && !/title="(Kabir|Naina)"/.test(X.html()) && X.html().includes('av anon'));
        t('S01 guest sees only the host name (no username, bio or profile) and no exact spot', X.html().includes('sign in to see more') && !X.html().includes('@aditi') && X.html().includes('Exact spot unlocks'));
        await X.go('#/event/e1');
        t('S01 guest event page: attendee identities hidden, count and sign-in hint shown', X.html().includes('Who&#39;s going') || X.html().includes("Who's going") ? !/title="(Aditi|Arjun|Riya|Somya|Kabir|Meera|Dev|Naina)"/.test(X.html()) && X.html().includes('sign in to see who') : false);
        await X.go('#/explore');
        t('S01 guest Discover cards show anonymous avatars only', !/class="av"[^>]*title=/.test(X.html()) && X.html().includes('av anon'));
        const m0 = msgsOf('p9');
        X.click('user', { v: 'u1' });
        t('S01 guest cannot open a member profile (sign-in instead)', X.sheet().includes('Continue with Google') && !X.sheet().includes('Squad feedback')); X.click('close');
        for (const [a, d] of [['members', { v: 'p9' }], ['attachments', { v: 'p9' }], ['gopts', { v: 'p9' }], ['ginfo', { v: 'p9' }]]) { X.click(a, d); }
        t('S01 guest cannot open member list, attachments, group options or info', !X.sheet().includes('The squad') && !X.sheet().includes('Camera') && !X.sheet().includes('Group info')); X.click('close');
        X.ev("O.chat.draft='hi'"); X.ev("A.send('p9')"); X.click('sendMedia', { k: 'p9' }); X.click('react', { k: 'p9', v: '1' });
        t('S01 guest cannot send messages, media or reactions', msgsOf('p9') == m0);
        X.click('remove', { k: 'p1', v: 'u5' }); X.click('cancel', { v: 'p1' }); X.click('accept', { k: 'p1', v: 'u5' });
        t('S01 guest cannot run host actions', X.ev("pl('p1').members.includes('u5')") && X.ev("pl('p1').status") == 'open'); X.click('close');
        for (const r of ['#/groups', '#/gc/p9', '#/posted/p1', '#/me', '#/settings', '#/create', '#/outside']) {
            await X.go(r);
            if (!(X.h == '#/home' && X.sheet().includes('Sign in to continue') || X.sheet().includes('make a plan')) || X.html().includes('Message your squad')) { t('S01 guest blocked from ' + r, false); break; }
            X.click('close');
        }
        t('S01 direct links to every protected route send a guest Home with the sign-in prompt', true);

        /* ---------- invalid / unavailable links ---------- */
        for (const [r, txt] of [['#/plan/%3Cscript%3E', "look right"], ['#/plan/nope', 'Plan escaped'], ['#/event/zzz', 'Event not found'], ['#/bogus', 'Page not found'], ['#/checkin/p1/zz', 'look right'], ['#/plan', 'look right'], ['#/plan/' + 'x'.repeat(60), 'look right']]) {
            await X.go(r);
            if (!X.html().includes('data-fallback') && !X.html().includes(txt) || !X.html().includes('Go back') && !X.html().includes('Back to')) { t('S01 fallback for ' + r, false); break; }
        }
        t('S01 malformed ids, missing plans/events and unknown routes show styled fallbacks with a way out', X.html().length > 100);
        t('S01 fallbacks never echo the link or an id', !/%3C|zzz|nope/.test(X.html()));

        /* ---------- intent: validated, used once, never auto-sends ---------- */
        const ci = x => X.ev(`JSON.stringify(cleanIntent(${x}))`);
        t('S01 intent: arbitrary / unsafe return destinations are rejected', ['"//evil.example"', '"https://evil.example/#/home"', '"javascript:alert(1)"', '"#/gc/p9/../x"', '"#/plan/<x>"', '"#/admin"'].every(h => ci(`{hash:${h},at:Date.now()}`) == 'null'));
        t('S01 intent: unknown actions, stale and future intents are rejected', ci("{a:'constructor',at:Date.now()}") == 'null' && ci("{a:'join',v:'p1',at:Date.now()-31*60000}") == 'null' && ci("{a:'join',v:'p1',at:Date.now()+9e6}") == 'null' && ci("{a:'join',v:'p1'}") == 'null');
        t('S01 intent: a join resumes on that plan and a plan-creation intent only returns to the create page', JSON.parse(ci("{a:'join',v:'p1',hash:'#/explore',at:Date.now()}")).hash == '#/plan/p1' && JSON.parse(ci("{a:'post',hash:'#/home',at:Date.now()}")).hash == '#/create');

        /* guest taps Create (via route), signs up, finishes onboarding, lands on create page; nothing is published */
        await X.go('#/create');
        const plansBefore = X.ev('S.plans.length');
        await signUp(X, 'Somya', 'somya_t'); await sleep(900);
        t('S01 Create Plan: sign-in + onboarding return to the create flow, nothing published', X.h == '#/create' && X.html().includes('Which day?') && X.ev('S.plans.length') == plansBefore);
        const acctA = X.ev('S.acct');
        t('S01 a verified Google sign-in created the session', X.ev("S.session.acct==S.acct&&S.session.sub=='g-somya'&&AUTH.state=='authenticated'") );
        mkPlan('pa1');

        /* ---------- account switching and sign-out ---------- */
        await X.go('#/gc/pa1');
        X.type('chat.draft', 'draft-secret-xyz');
        X.click('gopts', { v: 'pa1' }); X.click('members', { v: 'pa1' });
        t('S01 host sees own chat and member sheet', X.sheet().includes('The squad') && X.ev("O.ctx&&O.ctx.plan")=='pa1');
        await logout(X);
        t('S01 sign-out clears private UI: draft, sheet, chat, context, intent', X.sheet() == '' && X.ev("O.chat.draft==''&&O.ctx===null&&S.intent===null&&O.media===null") && !X.html().includes('private-hello-pa1') && !X.html().includes('draft-secret-xyz'));
        await X.go('#/gc/pa1');
        t('S01 browser back/forward after sign-out cannot restore the private chat', X.h == '#/home' && !X.html().includes('private-hello-pa1') && !X.html().includes('Message your squad')); X.click('close');
        await signUp(X, 'Riya B', 'riya_b'); await sleep(900);
        const acctB = X.ev('S.acct');
        await X.go('#/gc/pa1');
        t('S01 account switching: the next account sees nothing of the previous account\'s chat or draft', X.html().includes('No access') && !X.html().includes('private-hello-pa1') && !X.html().includes('draft-secret-xyz') && X.ev("O.chat.draft")=='');
        await X.go('#/plan/pa1');
        t('S01 non-member sees public plan info only: no member avatars, no exact spot', X.html().includes('Chai pa1') && !X.html().includes('secret-spot-pa1') && !X.html().includes('style="all:unset;cursor:pointer"') && X.html().includes('av anon'));
        const n0 = msgsOf('pa1');
        X.ev("O.chat.draft='x'"); X.ev("A.send('pa1')"); X.click('members', { v: 'pa1' }); X.click('attachments', { v: 'pa1' }); X.click('react', { k: 'pa1', v: '1' });
        t('S01 non-member cannot message, list members, attach or react', msgsOf('pa1') == n0 && !X.sheet().includes('The squad') && !X.sheet().includes('Camera') && X.said('Only accepted squad members'));

        /* pending applicant */
        X.click('join', { v: 'pa1' }); X.click('cjoin', { v: 'pa1' }); await sleep(900);
        t('S01 pending applicant: request recorded, not a member', X.ev("membership(pl('pa1'),'me')")=='pending' && !X.ev("pl('pa1').members.includes('me')"));
        await X.go('#/gc/pa1');
        t('S01 pending applicant cannot open the chat, member list or messages', X.html().includes('No access') && !X.html().includes('private-hello-pa1'));
        X.click('members', { v: 'pa1' }); X.ev("A.send('pa1')");
        t('S01 pending applicant stays blocked at action level', !X.sheet().includes('The squad') && msgsOf('pa1') == n0);
        X.click('join', { v: 'pa1' }); X.click('cjoin', { v: 'pa1' }); await sleep(900);
        t('S01 a pending request is never duplicated or treated as membership', X.ev("pl('pa1').reqs.filter(r=>r.u=='me').length")==1);
        await logout(X);

        /* host rejects a third person silently, accepts B */
        await signIn(X, 'somya_t');
        X.ev("pl('pa1').reqs.push({u:'u6',at:Date.now()})");
        X.click('reject', { k: 'pa1', v: 'u6' });
        t('S01 rejected applicant: recorded, no notification at all', X.ev("pl('pa1').rej.includes('u6')&&!S.notifs.some(n=>n.to=='u6')&&!S.notifs.some(n=>n.type=='join-rejected')"));
        X.click('accept', { k: 'pa1', v: acctB });
        t('S01 host accepts: member now', X.ev(`pl('pa1').members.includes('${acctB}')`));
        await logout(X);

        /* accepted member */
        await signIn(X, 'riya_b');
        await X.go('#/gc/pa1');
        t('S01 accepted member can open the chat and the member list', X.html().includes('Message your squad') && (X.click('members', { v: 'pa1' }), X.sheet().includes('The squad')));
        X.click('close');
        X.click('remove', { k: 'pa1', v: acctA }); X.click('cancel', { v: 'pa1' }); X.click('accept', { k: 'pa1', v: 'u6' }); X.click('end', { v: 'pa1' });
        t('S01 regular member cannot execute host-only actions', X.ev("pl('pa1').status")=='open' && X.ev(`pl('pa1').members.includes('${acctA}')`) && X.said('Only the host'));
        X.click('leave', { v: 'pa1' }); /* ok: members may leave; undo by re-adding below via host accept */
        t('S01 voluntary departure is recorded as "left", never as removal', X.ev("pl('pa1').left.includes('me')&&!(pl('pa1').removed||[]).includes('me')&&membership(pl('pa1'),'me')=='left'"));
        await X.go('#/gc/pa1');
        t('S01 a departed member no longer has private access', X.html().includes('No access') && !X.html().includes('private-hello-pa1'));
        X.click('join', { v: 'pa1' }); X.click('cjoin', { v: 'pa1' }); await sleep(900);
        t('S01 a departed member may ask to join again (existing policy)', X.ev("membership(pl('pa1'),'me')")=='pending');
        await logout(X);
        await signIn(X, 'somya_t');
        X.click('accept', { k: 'pa1', v: acctB });
        t('S01 re-accepted departed member is cleared from "left"', X.ev(`!pl('pa1').left.includes('${acctB}')&&pl('pa1').members.includes('${acctB}')`));

        /* permanent removal by the host (through the real confirmation) */
        X.ev("pl('pa1').members.push('u2')");
        X.click('ask', { do: 'remove', k: 'pa1', v: acctB });
        t('S01 removal asks first and explains it is for this squad only', X.sheet().includes('Remove from squad?') && X.sheet().includes("can't ask to join it again") && X.sheet().includes("other squad"));
        X.click('confirmed'); await sleep(300);
        t('S01 removal: out of members, recorded as permanent, history kept', X.ev(`!pl('pa1').members.includes('${acctB}')&&pl('pa1').removed.includes('${acctB}')&&S.msgs['pa1'].length>=2`) && X.ev(`S.notifs.some(n=>n.to=='${acctB}'&&n.type=='removed')`));
        t('S01 removal is not a platform ban: nothing else changed for that person', X.ev(`S.plans.filter(p=>p.id!='pa1').every(p=>!(p.removed||[]).includes('${acctB}'))`));
        await logout(X);

        await signIn(X, 'riya_b');
        await X.go('#/gc/pa1');
        t('S01 removed member: chat closed with a clear message, no private content', X.html().includes('No access') && X.html().includes("no longer part of this squad") && !X.html().includes('private-hello-pa1') && !X.html().includes('Message your squad'));
        await X.go('#/plan/pa1');
        t('S01 removed member: plan page offers no join button', !X.html().includes('data-a="join"') && X.html().includes('Not available for you'));
        X.click('join', { v: 'pa1' }); X.click('cjoin', { v: 'pa1' }); await sleep(900);
        t('S01 removed member cannot rejoin that same squad (not even by hand-made action)', X.ev("membership(pl('pa1'),'me')")=='removed' && !X.ev("pl('pa1').reqs.some(r=>r.u=='me')") && X.said("can't ask to join"));
        const n1 = msgsOf('pa1');
        X.ev("O.chat.draft='x'"); X.ev("A.send('pa1')"); X.ev("O.media={id:'pa1',type:'photo',src:'data:x'}"); X.click('sendMedia', { k: 'pa1' });
        t('S01 removed member cannot send messages or attachments', msgsOf('pa1') == n1);
        await X.go('#/groups');
        t('S01 removed squad is gone from the removed member\'s Groups list', !X.html().includes('Chai pa1'));
        X.click('notifs');
        t('S01 notifications: removal is shown, but old squad notifications reveal no private preview', X.sheet().includes('removed from a squad'));
        X.ev(`notify('me',{type:'join-approved',ic:'party-popper',c:'green',t:'You are in!',b:'Somya accepted you for Chai pa1',planId:'pa1',userId:'x'})`);
        t('S01 a stale notification about a squad you lost reveals nothing and routes to the public plan', X.ev(`notifView(S.notifs.find(n=>n.type=='join-approved')).b`).includes('no longer have access') && X.ev(`notifView(S.notifs.find(n=>n.type=='join-approved')).route`)=='#/plan/pa1');
        X.click('close');
        X.click('join', { v: 'p3' }); X.click('cjoin', { v: 'p3' }); await sleep(900);
        t('S01 removal from one squad does not stop joining other squads', X.ev("membership(pl('p3'),'me')")=='pending');
        await logout(X);

        /* live access loss: the screen and open sheets are replaced immediately */
        await signIn(X, 'somya_t');
        mkPlan('pa2', "{creator:'u1',members:['u1','me','u3']}");
        await X.go('#/gc/pa2');
        X.click('gopts', { v: 'pa2' }); X.click('members', { v: 'pa2' });
        t('S01 (setup) member sheet open on a squad', X.sheet().includes('The squad'));
        X.ev("pl('pa2').members=pl('pa2').members.filter(m=>m!='me');pl('pa2').removed=['me']");
        X.ev('render()');
        t('S01 access loss while viewing: sheets closed, chat replaced, composer gone', X.sheet() == '' && X.html().includes('No access') && !X.html().includes('id="mi"') && X.said('no longer have access'));
        await logout(X);

        /* ---------- sessions ---------- */
        await signIn(X, 'riya_b');
        X.ev('S.session.at=Date.now()-40*864e5'); X.ev('render()'); await sleep(30);
        t('S01 expired session: signed out locally, profile kept, private pages not drawn', X.ev('S.me.guest&&S.acct===null&&accounts().length>=1') && !X.html().includes('Hey Riya'));
        await signIn(X, 'riya_b');
        X.ev('S.session=null'); X.ev('render()'); await sleep(30);
        t('S01 a profile without a session is never treated as signed in', X.ev('S.me.guest&&tier()=="guest"'));
        await signIn(X, 'riya_b');
        t('S01 cross-tab account switch clears private UI and reloads', (X.W.storage({ key: 'squado-v5', newValue: JSON.stringify({ ...JSON.parse(AP.store['squado-v5']), acct: 'other', session: { at: 1 } }) }), X.html() === '') );
        X = boot(AP); await sleep(100);

        /* ---------- onboarding resume ---------- */
        await signUp(X, 'Zed', 'zed_z').catch(() => { });
        await logout(X);
        await gsign(X, ID.carol_c); X.type('ob.name', 'Carol'); X.click('obNext'); X.type('ob.username', 'carol_c'); X.click('obNext');
        X.ev("S.me.ob.username='aditi'"); X.ev('obRestore()');
        t('S01 onboarding resume never skips an invalid earlier step', X.ev('O.ob.step') == 1);
        X.click('obCancel'); await sleep(50);

        /* ---------- error boundary ---------- */
        await signIn(X, 'somya_t');
        const renderErrors = [];
        X.ctx.console = { ...console, error: (...a) => renderErrors.push(a) };
        X.ev("window.__home=home;home=()=>{throw new Error('boom')}");
        X.ev("O.loaded={};O.loading={}");
        await X.go('#/explore'); renderErrors.length = 0;
        await X.go('#/home');
        await sleep(900);
        t('S01 a page that throws shows a styled fallback instead of a blank screen', X.html().includes('Something went wrong') && X.html().includes('Back to Home'));
        t('S01 a failing page is rendered once, with no repeated renders or timers (one error, none queued)', renderErrors.length == 1 && X.ev("(O.loading.home||0)+(O.loading.ex||0)") == 0);
        X.ev('home=window.__home');
        await X.go('#/explore'); await X.go('#/home');
        t('S01 the app recovers after the failing page', X.html().includes('So... what are we doing?'));

        /* ---------- blocked ---------- */
        await X.go('#/home');
        X.click('block', { v: 'u1' });
        await X.go('#/plan/p1');
        t('S01 blocked host: direct plan link is unavailable and joining is refused', X.html().includes('Plan escaped') && X.ev("joinCheck(pl('p1'))")=='unavailable');
        X.click('user', { v: 'u1' });
        t('S01 a blocked person\'s profile cannot be opened', !X.sheet().includes('Squad feedback') && X.said('You blocked this person'));
        X.click('unblock', { v: 'u1' });

        t('S01 source: no backend or new framework introduced by this section', !/firebase|firestore|supabase/i.test(['state/access.js', 'app/guards.js', 'app/router.js', 'components/common/AccessFallback.js'].map(f => fs.readFileSync('src/js/' + f, 'utf8')).join('')));
    }

    /* =====================================================================================================
       SECTION 02: GROUP MEMBERSHIP LIFECYCLE
       ===================================================================================================== */
    {
        /* ---------- A. the lifecycle module itself (pure state transitions; sample actors, no UI) ---------- */
        const U = boot(newP()); await sleep(80);
        const J = x => JSON.parse(U.ev(`JSON.stringify(${x})`));
        const mk = (id, extra = '{}') => U.ev(`S.plans.unshift(Object.assign({id:'${id}',creator:'u1',type:'chai',title:'T ${id}',desc:'',vibe:[],loc:'MP Nagar',city:'Bhopal',when:'9 PM',live:false,max:3,members:['u1'],who:'Everyone',reqs:[],status:'open'},${extra}))`);

        t('S02 model: the five lifecycle states map onto the plan lists (accepted/pending/rejected/left/removed)', J('MEM_LISTS').accepted == 'members' && J('MEM_LISTS').pending == 'reqs' && J('MEM_LISTS').rejected == 'rej' && J('MEM_LISTS').left == 'left' && J('MEM_LISTS').removed == 'removed');
        mk('m0', "{members:['u1','u2'],reqs:[{u:'u3',at:1}],rej:['u4'],left:['u5'],removed:['u6']}");
        t('S02 model: membership() reads host / member / pending / rejected / left / removed / none from one place', ['u1:host', 'u2:member', 'u3:pending', 'u4:rejected', 'u5:left', 'u6:removed', 'u9:none'].every(x => U.ev(`membership(pl('m0'),'${x.split(':')[0]}')`) == x.split(':')[1]));
        mk('m1', "{members:['u1','u2','u2'],reqs:[{u:'u2',at:1},{u:'u3',at:1},{u:'u3',at:2}],rej:['u3','u4','u4'],left:['u4','u5'],removed:['u2','u1','u7']}");
        U.ev("memReconcile(pl('m1'))");
        const m1 = J("(({members,reqs,rej,left,removed})=>({members,reqs:reqs.map(r=>r.u),rej,left,removed}))(pl('m1'))");
        t('S02 reconcile: conflicting records resolve deterministically (removed > accepted > pending > rejected > left), no duplicates', JSON.stringify(m1) == JSON.stringify({ members: ['u1'], reqs: ['u3'], rej: ['u4'], left: ['u5'], removed: ['u2', 'u7'] }));
        t('S02 reconcile: the host can never be removed, pending, rejected or left', m1.members.includes('u1') && !m1.removed.includes('u1'));
        mk('m2', "{members:'broken',reqs:null,rej:undefined,left:7,removed:{},max:'x'}");
        U.ev("memReconcile(pl('m2'))");
        t('S02 reconcile: missing or invalid membership records are repaired instead of throwing', J("[Array.isArray(pl('m2').members),pl('m2').members[0],Array.isArray(pl('m2').reqs),Number.isInteger(pl('m2').max)]").join() == 'true,u1,true,true');
        t('S02 capacity: only whole numbers inside the allowed range are valid', [[1, false], [2, true], [8, true], [9, false], [2.5, false], ['4', false], [NaN, false], [null, false]].every(([v, r]) => U.ev(`capacityOk(${v === null ? 'null' : typeof v == 'string' ? JSON.stringify(v) : v})`) === r));

        /* join requests */
        mk('r1', "{max:3}");
        const req = (u, id = 'r1') => J(`memRequest(pl('${id}'),'${u}')`);
        t('S02 request: an eligible person becomes pending (not a member)', req('u2').ok && U.ev("membership(pl('r1'),'u2')") == 'pending' && !U.ev("pl('r1').members.includes('u2')"));
        t('S02 request: a duplicate request is refused and stays a single record', req('u2').why == 'pending' && U.ev("pl('r1').reqs.filter(r=>r.u=='u2').length") == 1);
        t('S02 request: a member / closed squad / rejected person is refused', req('u1').why == 'member' && (mk('rc', "{status:'cancelled'}"), req('u2', 'rc').why == 'closed') && (mk('rj', "{rej:['u2']}"), req('u2', 'rj').why == 'rejected'));
        mk('rf', "{max:2,members:['u1','u2']}");
        t('S02 request: a full squad refuses new requests', req('u3', 'rf').why == 'full');
        mk('rm', "{removed:['u3']}");
        t('S02 request: a permanently removed person cannot request that squad', req('u3', 'rm').why == 'removed' && U.ev("!pl('rm').reqs.length"));
        t('S02 request: removal is not a platform ban (the same person can request another squad)', req('u3', 'r1').ok);

        /* approval, capacity, idempotence */
        const ap = (u, id = 'r1', actor = 'u1') => J(`memApprove(pl('${id}'),'${u}','${actor}')`);
        t('S02 approve: only the host can approve', ap('u2', 'r1', 'u9').why == 'admin' && U.ev("membership(pl('r1'),'u2')") == 'pending');
        t('S02 approve: the host approves a valid pending request', ap('u2').ok && U.ev("membership(pl('r1'),'u2')") == 'member');
        t('S02 approve: a request cannot be processed twice (idempotent, one member record)', ap('u2').why == 'notpending' && U.ev("pl('r1').members.filter(m=>m=='u2').length") == 1);
        t('S02 approve: nobody who never asked can be approved', ap('u8').why == 'notpending');
        mk('c1', "{max:3,reqs:[{u:'u2',at:1},{u:'u3',at:1},{u:'u4',at:1},{u:'u5',at:1}]}");
        const results = ['u2', 'u3', 'u4', 'u5', 'u2', 'u3', 'u4', 'u5'].map(u => ap(u, 'c1'));
        t('S02 capacity: simulated simultaneous/repeated approvals never exceed the configured capacity', U.ev("pl('c1').members.length") == 3 && results.filter(r => r.ok).length == 2 && results.some(r => r.why == 'full'));
        t('S02 capacity: the request that did not fit stays pending (not lost, not accepted)', U.ev("pl('c1').reqs.map(r=>r.u).join()") == 'u4,u5');
        mk('x1', "{members:['u1','u2'],reqs:[{u:'u3',at:1}]}");
        t('S02 reject: only a pending request can be rejected; a stale rejection cannot overwrite a newer state', J("memReject(pl('x1'),'u2','u1')").why == 'notpending' && U.ev("membership(pl('x1'),'u2')") == 'member' && J("memReject(pl('x1'),'u3','u1')").ok && U.ev("membership(pl('x1'),'u3')") == 'rejected' && J("memReject(pl('x1'),'u3','u1')").why == 'notpending');
        t('S02 reject: a rejected person who was approved later is not dragged back to rejected', (U.ev("pl('x1').reqs.push({u:'u3',at:2});pl('x1').rej=[]"), ap('u3', 'x1').ok && J("memReject(pl('x1'),'u3','u1')").why == 'notpending' && U.ev("membership(pl('x1'),'u3')") == 'member'));
        t('S02 reject: nobody but the host can reject', (mk('x2', "{reqs:[{u:'u3',at:1}]}"), J("memReject(pl('x2'),'u3','u9')").why == 'admin'));

        /* leaving */
        mk('l1', "{members:['u1','u2'],max:2}");
        t('S02 leave: only an accepted member can leave, and never the host', J("memLeave(pl('l1'),'u7')").why == 'notmember' && J("memLeave(pl('l1'),'u1')").why == 'host');
        t('S02 leave: a member leaves (state left, not removed) and the spot reopens', J("memLeave(pl('l1'),'u2')").ok && U.ev("membership(pl('l1'),'u2')") == 'left' && U.ev("!pl('l1').removed.includes('u2')&&pl('l1').members.length") == 1);
        t('S02 leave: a second leave is refused (idempotent)', J("memLeave(pl('l1'),'u2')").why == 'notmember');
        t('S02 leave: rejoining follows the documented rule (may ask again, host decides)', req('u2', 'l1').ok && U.ev("membership(pl('l1'),'u2')") == 'pending' && ap('u2', 'l1').ok && U.ev("!pl('l1').left.includes('u2')&&membership(pl('l1'),'u2')") == 'member');

        /* removal */
        mk('d1', "{members:['u1','u2','u3'],max:4}");
        t('S02 remove: only the host can remove; the host cannot remove themselves', J("memRemove(pl('d1'),'u2','u9')").why == 'admin' && J("memRemove(pl('d1'),'u1','u1')").why == 'host');
        t('S02 remove: an accepted member is removed permanently (recorded, out of members)', J("memRemove(pl('d1'),'u2','u1')").ok && U.ev("membership(pl('d1'),'u2')") == 'removed' && U.ev("!pl('d1').members.includes('u2')&&pl('d1').removed.includes('u2')"));
        t('S02 remove: repeating or removing a non-member is refused', J("memRemove(pl('d1'),'u2','u1')").why == 'already' && J("memRemove(pl('d1'),'u8','u1')").why == 'notmember');
        t('S02 remove: cannot request again, cannot be approved, cannot rejoin as a leaver', req('u2', 'd1').why == 'removed' && (U.ev("pl('d1').reqs.push({u:'u2',at:9})"), ap('u2', 'd1').why == 'removed' && U.ev("membership(pl('d1'),'u2')") == 'removed' && U.ev("!pl('d1').members.includes('u2')")));
        t('S02 remove: deleting the visible record elsewhere cannot lift the restriction (removed outranks every other record)', (U.ev("pl('d1').members.push('u2');pl('d1').left.push('u2');memReconcile(pl('d1'))"), U.ev("membership(pl('d1'),'u2')") == 'removed' && U.ev("!pl('d1').members.includes('u2')")));
        t('S02 history: every transition is recorded in the log, and the log grants nothing', J("pl('d1').mlog.map(m=>m.s)").includes('removed') && J("pl('l1').mlog.map(m=>m.s)").join() == 'left,pending,accepted' && U.ev("(pl('l1').mlog.push({u:'u9',s:'accepted',at:1,by:'u9'}),membership(pl('l1'),'u9'))") == 'none');

        /* ---------- B. the real flows with real accounts ---------- */
        const AP2 = newP();
        let Y = boot(AP2); await sleep(100);
        const mid = id => Y.ev(`(S.msgs['${id}']||[]).length`);

        /* create: creator is host; invalid capacity; duplicate submit */
        await signUp(Y, 'Somya', 'somya_t'); await sleep(900);
        await Y.go('#/create');
        const n0 = Y.ev('S.plans.length');
        for (const sz of ['1', '9']) { Y.click('set', { k: 'W.type', v: 'chai' }); Y.click('set', { k: 'W.loc', v: 'MP Nagar' }); Y.click('set', { k: 'W.when', v: '10:00 PM' }); Y.ev(`O.W.size=${sz}`); Y.click('post'); await sleep(900); }
        t('S02 create: an invalid capacity is rejected and no group is created', Y.ev('S.plans.length') == n0 && Y.said('squad size between 2 and 8'));
        Y.click('set', { k: 'W.size', v: '3' }); Y.click('post'); Y.click('post'); Y.click('post'); await sleep(1200);
        const pid = Y.ev('S.plans[0].id');
        t('S02 create: repeated submissions create exactly one group', Y.ev('S.plans.length') == n0 + 1);
        t('S02 create: the creator is the host/owner, accepted, never pending, with the chosen capacity', Y.ev(`membership(pl('${pid}'),'me')=='host'&&pl('${pid}').creator=='me'&&pl('${pid}').members.join()=='me'&&pl('${pid}').reqs.length==0&&pl('${pid}').max===3`));
        t('S02 create: plan ids are unique even in the same millisecond', Y.ev("(()=>{const a=newPlanId();S.plans.unshift({id:a,members:[],reqs:[]});const b=newPlanId();S.plans.shift();return a!==b})()"));
        const acctA2 = Y.ev('S.acct');
        await logout(Y);

        /* guest cannot request */
        await Y.go('#/plan/' + pid);
        Y.click('join', { v: pid });
        t('S02 join: a guest is prompted to sign in and cannot submit a request', Y.sheet().includes('Continue with Google') && Y.ev(`pl('${pid}').reqs.length==0`)); Y.click('close');

        /* three applicants */
        const acct = {};
        for (const [n, u] of [['Riya B', 'riya_b'], ['Carol C', 'carol_c'], ['Sam S', 'sam_s']]) {
            await signUp(Y, n, u); await sleep(900);
            acct[u] = Y.ev('S.acct');
            await Y.go('#/plan/' + pid);
            Y.click('join', { v: pid }); Y.click('cjoin', { v: pid }); Y.click('cjoin', { v: pid }); await sleep(1000);
            if (u == 'riya_b') {
                t('S02 join: an eligible user submits a request; duplicate clicks create one record', Y.ev(`pl('${pid}').reqs.filter(r=>r.u=='me').length`) == 1 && Y.ev(`membership(pl('${pid}'),'me')`) == 'pending');
                t('S02 join: pending users have no chat, no member list and no member-only content', (await Y.go('#/gc/' + pid), Y.html().includes('No access') && !Y.html().includes('Message your squad')) && (Y.click('members', { v: pid }), !Y.sheet().includes('The squad')));
                await Y.go('#/home'); await Y.go('#/plan/' + pid);
                t('S02 join: leaving the screen and coming back shows the same pending status, nowhere a contradiction', Y.html().includes('Requested') && !Y.html().includes('data-a="join"') && Y.ev(`membership(pl('${pid}'),'me')`) == 'pending');
                await Y.go('#/groups');
                t('S02 groups: no "Waiting on the host" section; the pending squad is not listed as a group', !Y.html().includes('Waiting on the host') && !Y.html().includes('Chai &amp; yap?') && !Y.html().includes('Chai & yap?'));
                await Y.go('#/me');
                t('S02 profile: no "My Squads" section (Groups is the single place)', !Y.html().includes('My Squads'));
            }
            await logout(Y);
        }

        /* host decisions */
        await signIn(Y, 'somya_t'); await sleep(100);
        t('S02 host: sees the pending requests on the plan', (await Y.go('#/plan/' + pid), Y.html().includes('Who wants in')));
        const nN = () => Y.ev('S.notifs.length');
        Y.click('accept', { k: pid, v: acct.riya_b });
        t('S02 approve: the host approves a valid request (member now, 2/3)', Y.ev(`membership(pl('${pid}'),'${acct.riya_b}')=='member'&&pl('${pid}').members.length==2`));
        const nAfter = nN();
        Y.click('accept', { k: pid, v: acct.riya_b }); Y.click('accept', { k: pid, v: acct.riya_b });
        t('S02 approve: repeating the approval changes nothing and sends no duplicate notification', Y.ev(`pl('${pid}').members.filter(m=>m=='${acct.riya_b}').length`) == 1 && nN() == nAfter && Y.ev(`S.notifs.filter(n=>n.type=='join-approved'&&n.to=='${acct.riya_b}').length`) == 1);
        Y.click('reject', { k: pid, v: acct.riya_b });
        t('S02 reject: a stale rejection cannot overwrite a newer accepted state', Y.ev(`membership(pl('${pid}'),'${acct.riya_b}')`) == 'member' && !Y.ev(`pl('${pid}').rej.includes('${acct.riya_b}')`));
        Y.click('accept', { k: pid, v: acct.carol_c });
        t('S02 capacity: the squad is now full (3/3)', Y.ev(`pl('${pid}').members.length`) == 3);
        Y.click('accept', { k: pid, v: acct.sam_s }); Y.click('accept', { k: pid, v: acct.sam_s });
        t('S02 capacity: approval fails when the squad is full; the request stays pending', Y.ev(`pl('${pid}').members.length`) == 3 && Y.ev(`membership(pl('${pid}'),'${acct.sam_s}')`) == 'pending' && Y.said('Squad full'));
        Y.click('reject', { k: pid, v: acct.sam_s });
        t('S02 reject: the host rejects; the requester is rejected, not removed or altered otherwise', Y.ev(`membership(pl('${pid}'),'${acct.sam_s}')`) == 'rejected' && Y.ev(`pl('${pid}').members.length`) == 3);
        t('S02 reject: no notification of any kind is created for the rejected requester', Y.ev(`!S.notifs.some(n=>n.to=='${acct.sam_s}')`));
        const rejLog = Y.ev(`pl('${pid}').mlog.filter(m=>m.s=='rejected').length`);
        Y.click('reject', { k: pid, v: acct.sam_s });
        t('S02 reject: a second rejection is a no-op', Y.ev(`pl('${pid}').mlog.filter(m=>m.s=='rejected').length`) == rejLog);
        await logout(Y);

        /* rejected applicant */
        await signIn(Y, 'sam_s'); await sleep(60);
        await Y.go('#/plan/' + pid);
        t('S02 rejected: sees only their own status, keeps the existing wording, gets no notification and no way in', Y.html().includes('Host passed this time') && myNotifsLen(Y) == 0);
        await Y.go('#/gc/' + pid);
        t('S02 rejected: the old URL, refresh and history cannot reopen the private chat', Y.html().includes('No access') && !Y.html().includes('Message your squad'));
        await logout(Y);

        /* accepted member: access, no host powers, notifications */
        await signIn(Y, 'riya_b'); await sleep(60);
        await Y.go('#/gc/' + pid);
        t('S02 accepted: the member reaches the private chat and the member list', Y.html().includes('Message your squad') && (Y.click('members', { v: pid }), Y.sheet().includes('The squad'))); Y.click('close');
        t('S02 accepted: gets exactly one "You\'re in" notification', myNotifsLen(Y) == 1);
        Y.click('reject', { k: pid, v: acct.carol_c }); Y.click('accept', { k: pid, v: acct.sam_s }); Y.click('remove', { k: pid, v: acct.carol_c });
        t('S02 permissions: an ordinary member cannot approve, reject or remove, whether by button, stale UI or direct call', Y.ev(`membership(pl('${pid}'),'${acct.carol_c}')`) == 'member' && Y.ev(`membership(pl('${pid}'),'${acct.sam_s}')`) == 'rejected' && Y.said('Only the host'));
        await Y.go('#/plan/' + pid);
        t('S02 permissions: the host-only request list is not shown to a member', !Y.html().includes('Who wants in'));

        /* leave: confirmation, access revoked, host notified once, distinct from removal */
        await Y.go('#/gc/' + pid);
        Y.ev("O.chat.draft='half-written'");
        const cancelBefore = Y.ev('S.me.rel.cancel');
        Y.click('ask', { do: 'leave', v: pid });
        t('S02 leave: asks for confirmation first', Y.sheet().includes('Leave') && Y.ev(`membership(pl('${pid}'),'me')`) == 'member');
        Y.click('confirmed'); await sleep(300);
        t('S02 leave: the member is "left" (not removed), out of the member list, spot reopened, reliability cancellation counter unchanged', Y.ev(`membership(pl('${pid}'),'me')`) == 'left' && Y.ev(`!pl('${pid}').removed.includes('me')&&pl('${pid}').members.length`) == 2 && Y.ev(`S.me.rel.cancel`) == cancelBefore);
        t('S02 leave: private chat, members and attachments are closed at once, stale composer cleared', (await Y.go('#/gc/' + pid), Y.html().includes('No access') && !Y.html().includes('id="mi"')) && Y.ev("O.chat.draft") == '' && (Y.click('members', { v: pid }), !Y.sheet().includes('The squad')) && !sentText(Y, pid, 'half-written'));
        t('S02 leave: the former member no longer lists the group in Groups', (await Y.go('#/groups'), !Y.html().includes('Chai &amp; yap?') && !Y.html().includes('Chai & yap?')));
        Y.click('leave', { v: pid });
        t('S02 leave: leaving again (a non-member) is refused', Y.ev(`pl('${pid}').mlog.filter(m=>m.s=='left'&&m.u=='me').length`) == 1);
        await logout(Y);

        await signIn(Y, 'somya_t'); await sleep(60);
        t('S02 leave: the host got exactly one "left your squad" notification, with no private content leak', Y.ev(`S.notifs.filter(n=>n.to=='me'&&n.type=='member'&&n.planId=='${pid}'&&/left your squad/.test(n.t)).length`) == 1);
        await logout(Y);

        /* rejoin after leaving */
        await signIn(Y, 'riya_b'); await sleep(60);
        await Y.go('#/plan/' + pid);
        t('S02 rejoin: a person who left sees the normal join button again', Y.html().includes('data-a="join"'));
        Y.click('join', { v: pid }); Y.click('cjoin', { v: pid }); await sleep(1000);
        t('S02 rejoin: asking again creates a pending request (not instant access)', Y.ev(`membership(pl('${pid}'),'me')`) == 'pending' && Y.ev(`!pl('${pid}').left.includes('me')`));
        await logout(Y);
        await signIn(Y, 'somya_t'); await sleep(60);
        Y.click('accept', { k: pid, v: acct.riya_b });
        t('S02 rejoin: the host approves again; history shows the full path', Y.ev(`pl('${pid}').mlog.filter(m=>m.u=='${acct.riya_b}').map(m=>m.s).join()`) == 'pending,accepted,left,pending,accepted');

        /* removal with preserved history */
        Y.ev(`S.attendance.push({planId:'${pid}',uid:'${acct.carol_c}',status:'present',method:'native_camera',at:Date.now()});S.feedback.push({id:'fb-s02',planId:'${pid}',from:'${acct.carol_c}',kind:'meetup'})`);
        Y.click('ask', { do: 'remove', k: pid, v: acct.carol_c });
        t('S02 remove: asks first and explains the consequence, for this squad only', Y.sheet().includes('Remove from squad?') && Y.sheet().includes("can't ask to join it again") && Y.sheet().includes('other squad'));
        Y.click('confirmed'); await sleep(300);
        t('S02 remove: the host removes an eligible member; recorded permanently', Y.ev(`membership(pl('${pid}'),'${acct.carol_c}')`) == 'removed' && Y.ev(`pl('${pid}').removed.includes('${acct.carol_c}')&&!pl('${pid}').members.includes('${acct.carol_c}')`));
        t('S02 remove: the member count and member list updated (host + Riya)', Y.ev(`pl('${pid}').members.length`) == 2);
        t('S02 remove: historical attendance and feedback records are preserved, but grant no membership or presence', Y.ev(`!!attGet(pl('${pid}'),'${acct.carol_c}')&&S.feedback.some(f=>f.id=='fb-s02')&&!attPresent(pl('${pid}'),'${acct.carol_c}')&&membership(pl('${pid}'),'${acct.carol_c}')=='removed'`));
        const hostRemoveAgain = Y.ev('S.notifs.length');
        Y.click('remove', { k: pid, v: acct.carol_c }); Y.click('remove', { k: pid, v: 'me' }); Y.click('remove', { k: pid, v: 'zzz' });
        t('S02 remove: repeating it, removing the host or a stranger does nothing', Y.ev('S.notifs.length') == hostRemoveAgain && Y.ev(`pl('${pid}').members.length`) == 2 && Y.ev(`pl('${pid}').members.includes('me')`));
        await logout(Y);

        /* removed user */
        await signIn(Y, 'carol_c'); await sleep(60);
        await Y.go('#/gc/' + pid);
        t('S02 removed: private chat is closed with a clear message and no private content', Y.html().includes('No access') && Y.html().includes("no longer part of this squad") && !Y.html().includes('Message your squad'));
        await Y.go('#/plan/' + pid);
        t('S02 removed: no join button, no way to request again (button, direct call, stale sheet)', !Y.html().includes('data-a="join"') && (Y.click('join', { v: pid }), Y.click('cjoin', { v: pid }), await sleep(900), Y.ev(`!pl('${pid}').reqs.some(r=>r.u=='me')&&membership(pl('${pid}'),'me')=='removed'`)));
        t('S02 removed: stale notification does not authorize anything (generic text, plan page only)', (Y.ev(`notify('me',{type:'join-approved',ic:'party-popper',c:'green',t:'You\\'re in!',b:'x',planId:'${pid}',userId:'x'})`), Y.ev(`notifView(S.notifs.find(n=>n.type=='join-approved'&&n.to=='me')).route`) == '#/plan/' + pid && !Y.ev(`notifView(S.notifs.find(n=>n.type=='join-approved'&&n.to=='me')).b`).includes('x')));
        Y.click('notifs'); const nv = Y.sheet(); Y.click('close');
        t('S02 removed: the removal notice is shown and links to the public plan, never the chat', nv.includes('removed from a squad') && Y.ev(`notifRoute(S.notifs.find(n=>n.type=='removed'&&n.to=='me'))`) == '#/plan/' + pid);
        t('S02 removed: not a platform-wide ban (other squads still open to them)', Y.ev("S.plans.filter(p=>p.id!='" + pid + "').every(p=>!(p.removed||[]).includes('me'))") && Y.ev("joinCheck(pl('p3'))") == 'ok');
        await Y.go('#/gc/zzz');
        t('S02 routing: an invalid group id shows the safe fallback, nothing private', Y.html().includes('No access') && !Y.html().includes('Message your squad'));
        await logout(Y);

        /* refresh: persisted state, same decisions */
        Y = boot(AP2); await sleep(120);
        await signIn(Y, 'carol_c'); await sleep(60);
        await Y.go('#/gc/' + pid);
        t('S02 refresh: a removed user stays out after a reload', Y.html().includes('No access') && Y.ev(`pl('${pid}').removed.includes('me')`));
        await logout(Y);
        await signIn(Y, 'riya_b'); await sleep(60);
        await Y.go('#/gc/' + pid);
        t('S02 refresh: an accepted member still has access after a reload', Y.html().includes('Message your squad'));

        /* account switching: member signs out, an outsider signs in; the stale chat is gone */
        Y.ev("O.chat.draft='private-draft-02'");
        await logout(Y);
        t('S02 account switch: signing out leaves no private chat, draft or sheet behind', !Y.html().includes('Message your squad') && Y.ev("O.chat.draft==''") && Y.sheet() == '');
        await signIn(Y, 'sam_s'); await sleep(60);
        await Y.go('#/gc/' + pid);
        t('S02 account switch: the next person cannot see the previous member\'s private group (direct URL)', Y.html().includes('No access') && !Y.html().includes('private-draft-02'));
        await logout(Y);

        /* stale chat callbacks: a delayed simulated reply cannot restore private content after access is lost */
        await signIn(Y, 'riya_b'); await sleep(60);
        Y.ev(`S.plans.unshift({id:'ps1',creator:'u1',type:'chai',title:'Sample squad',desc:'',vibe:[],loc:'MP Nagar',city:'Bhopal',when:'9 PM',live:false,max:5,members:['u1','me','u3'],who:'Everyone',reqs:[],status:'open'});S.msgs.ps1=[{sys:1,x:'hi'}];S.unread.ps1=0`);
        await Y.go('#/gc/ps1');
        Y.ev("O.chat.draft='hello squad'"); Y.ev("A.send('ps1')");
        const afterSend = mid('ps1');
        Y.ev("memRemove(pl('ps1'),'me','u1')");
        await sleep(1800);
        t('S02 stale chat: removal before the simulated reply arrives; no reply, no unread, nothing restored', mid('ps1') == afterSend && Y.ev('S.unread.ps1||0') == 0);
        Y.ev('render()');
        t('S02 stale chat: the open screen is replaced and the composer is gone', Y.html().includes('No access') && !Y.html().includes('id="mi"') && !Y.html().includes('hello squad'));
        Y.ev("O.chat.draft='sneaky'; A.send('ps1')");
        t('S02 stale chat: the old composer cannot send after removal', mid('ps1') == afterSend);
        await logout(Y);

        t('S02 source: no backend, framework or paid service introduced by this section', !/firebase|firestore|supabase|react|vue|next\.js/i.test(fs.readFileSync('src/js/state/membership.js', 'utf8')));
    }

    /* =====================================================================================================
       SECTION 03: GROUP CHAT AND MEDIA (frontend-only; local messages, never "synced")
       ===================================================================================================== */
    {
        const AP3 = newP();
        let Z = boot(AP3); await sleep(100);
        const mkp = (id, extra) => Z.ev(`S.plans.unshift(Object.assign({id:'${id}',creator:'u1',type:'chai',title:'Chat ${id}',desc:'',vibe:[],loc:'MP Nagar',city:'Bhopal',when:'9 PM',live:false,max:6,members:['u1','me'],who:'Everyone',reqs:[],status:'open'},${extra || '{}'}));S.msgs['${id}']=[{sys:1,x:'start ${id}'}];S.unread['${id}']=0`);
        const texts = id => Z.ev(`JSON.stringify(S.msgs['${id}'].filter(m=>m.by=='me').map(m=>m.x||m.type))`);
        const cnt = id => Z.ev(`(S.msgs['${id}']||[]).length`);
        const mi = { value: '', h: {}, addEventListener(t, f) { this.h[t] = f; this.value = Z.ev('O.chat.draft') || ''; }, focus() { } };
        const q0 = Z.ctx.document.querySelector;
        Z.ctx.document.querySelector = s => s == '#mi' ? mi : q0(s);

        /* ---------- guests ---------- */
        mkp('cg', "{members:['u1','u2']}");
        Z.ev("O.chat.draft='guest text';A.send('cg')"); Z.click('sendMedia', { k: 'cg' }); Z.click('attachments', { v: 'cg' });
        t('S03 guest: cannot send text, send media or open attachments in any conversation', cnt('cg') == 1 && !Z.sheet().includes('Share something') && Z.ev('unreadTotal()') == 0);
        await Z.go('#/gc/cg');
        t('S03 guest: a direct conversation link leads Home with the sign-in prompt, not the chat', Z.h == '#/home' && !Z.html().includes('Message your squad')); Z.click('close');

        /* ---------- one signed-in account, six relationships to six squads ---------- */
        await signUp(Z, 'Riya B', 'riya_b'); await sleep(900);
        Z.ev("S.plans=S.plans.filter(p=>p.id!='cg')");
        mkp('cm1'); mkp('cm2');
        mkp('cp', "{members:['u1'],reqs:[{u:'me',at:1}]}"); mkp('cr', "{members:['u1'],rej:['me']}");
        mkp('cl', "{members:['u1'],left:['me']}"); mkp('cx', "{members:['u1'],removed:['me']}");
        const acc = id => Z.ev(`groupAccess(pl('${id}'))`);
        t('S03 access: accepted members may open the conversation; pending, rejected, left and removed may not', acc('cm1') && acc('cm2') && !acc('cp') && !acc('cr') && !acc('cl') && !acc('cx'));
        const closed = [];
        for (const id of ['cp', 'cr', 'cl', 'cx', 'nope', 'cm1/../cm2', 'cm1/extra']) {
            await Z.go('#/gc/' + id);
            closed.push((Z.html().includes('No access') || Z.html().includes('look right')) && !Z.html().includes('Message your squad') && !Z.html().includes('id="mi"') && !Z.html().includes('start cm') && !Z.html().includes('start ' + id));
        }
        t('S03 access: direct routes to pending/rejected/left/removed/unknown ids and to routes with extra path segments show no messages and no composer', closed.length == 7 && closed.every(Boolean));
        t('S03 access: changing the group id in the route never opens another group\'s messages', (await Z.go('#/gc/cm1'), Z.html().includes('start cm1') && !Z.html().includes('start cm2')) && (await Z.go('#/gc/cm2'), Z.html().includes('start cm2') && !Z.html().includes('start cm1')) && (await Z.go('#/gc/cp'), !Z.html().includes('start cp')));
        const b = ['cp', 'cr', 'cl', 'cx'].map(id => cnt(id));
        for (const id of ['cp', 'cr', 'cl', 'cx']) { Z.ev(`O.chat.draft='x';A.send('${id}')`); Z.ev(`O.media={id:'${id}',type:'photo',src:'data:image/jpeg;base64,QUJD',loc:null};`); Z.click('sendMedia', { k: id }); Z.click('react', { k: id, v: '0' }); Z.click('attachments', { v: id }); Z.click('members', { v: id }); }
        t('S03 unauthorized: text, photos, reactions, attachment sheet and member list are all refused (hand-made actions included)', ['cp', 'cr', 'cl', 'cx'].map(id => cnt(id)).join() == b.join() && !Z.sheet().includes('Share something') && !Z.sheet().includes('The squad'));
        Z.ev('O.media=null');
        Z.click('openMediaCamera', { v: 'cx' }); Z.click('mediaGallery', { v: 'cx' }); await sleep(30);
        t('S03 unauthorized: the camera and gallery are never even opened for a squad you cannot open', Z.camCalls == 0 && Z.opened.length == 0);
        t('S03 stale reference: media prepared for one squad cannot be sent into another', (await Z.go('#/gc/cm1'), Z.ev("O.media={id:'cm1',type:'photo',src:'data:image/jpeg;base64,QUJD',loc:null};1"), Z.click('sendMedia', { k: 'cm2' }), cnt('cm2') == 1) && Z.ev('O.media!==null'));
        Z.ev('O.media=null');

        /* ---------- composer ---------- */
        await Z.go('#/gc/cm1');
        const n1 = cnt('cm1');
        Z.ev("O.chat.draft='   ';A.send('cm1')"); Z.ev("O.chat.draft='';A.send('cm1')"); Z.ev("O.chat.draft='\\n\\t ';A.send('cm1')");
        t('S03 composer: empty and whitespace-only messages are not sent', cnt('cm1') == n1);
        t('S03 composer: the send button is disabled until there is text', Z.html().includes('id="sendbtn"') && /id="sendbtn"[^>]*disabled/.test(Z.html()));
        Z.ev("O.chat.draft='alpha';A.send('cm1')"); Z.ev("O.chat.draft='beta';A.send('cm1')"); Z.ev("O.chat.draft='gamma';A.send('cm1')");
        t('S03 composer: messages are stored in the group they were sent in, in the order sent, from me', texts('cm1') == '["alpha","beta","gamma"]' && texts('cm2') == '[]' && Z.ev("S.msgs.cm1.slice(-3).every(m=>m.by=='me'&&m.t)"));
        mi.value = 'dup'; Z.ev("A.send('cm1')"); Z.ev("A.send('cm1')"); Z.ev("A.send('cm1')");
        t('S03 composer: repeated clicks send the text once (the composer is cleared after the first)', JSON.parse(texts('cm1')).filter(x => x == 'dup').length == 1 && Z.ev('O.chat.draft') == '');
        const sendKey = ev => { mi.h.keydown && mi.h.keydown(ev); };
        mi.value = 'via-enter'; sendKey({ key: 'Enter' });
        t('S03 keyboard: Enter sends the message', JSON.parse(texts('cm1')).filter(x => x == 'via-enter').length == 1);
        mi.value = 'ime'; sendKey({ key: 'Enter', isComposing: true }); sendKey({ key: 'Enter', keyCode: 229 }); sendKey({ key: 'Enter', repeat: true }); sendKey({ key: 'a' });
        t('S03 keyboard: Enter that confirms an IME composition, a held-down key repeat, or any other key does not send', !JSON.parse(texts('cm1')).includes('ime'));
        mi.value = 'once'; sendKey({ key: 'Enter' }); mi.value = 'once'; mi.h.keydown && (mi.value = '');
        t('S03 keyboard: pressing Enter twice for one message sends it once', JSON.parse(texts('cm1')).filter(x => x == 'once').length == 1);
        const long = 'W'.repeat(900) + '<img src=x onerror=alert(1)>';
        Z.ev(`O.chat.draft=${JSON.stringify(long)};A.send('cm1')`);
        t('S03 composer: a very long message is cut to the configured limit and cannot inject markup', Z.ev("S.msgs.cm1.slice(-1)[0].x.length") == 300 && Z.html().includes('W'.repeat(100)) && !Z.html().includes('<img src=x') && Z.html().includes(`maxlength="300"`));
        Z.ev("O.chat.draft='unsent-draft'"); await Z.go('#/gc/cm2');
        t('S03 composer: an unsent draft never follows you into another squad', Z.ev('O.chat.draft') == '' && !Z.html().includes('unsent-draft'));
        t('S03 composer: the chat css keeps the composer at the bottom and the list scrollable (sticky bottom, own scroll area, long words wrap)', /\.comp\s*\{[^}]*position:sticky[^}]*bottom:0/.test(CSS_BASE) && /\.gmsgs\s*\{[^}]*overflow-y:auto/.test(CSS_PAGES) && /\.gmsgs\s*\{[^}]*min-height:0/.test(CSS_PAGES) && /word-break:break-word/.test(CSS_PAGES) && /max-width:min\(240px,100%\)/.test(fs.readFileSync('src/js/components/squads/GroupChat.js', 'utf8')));
        Z.ev("S.msgs.cm2=[]");
        await Z.go('#/groups'); await Z.go('#/gc/cm2');
        t('S03 empty conversation: shows a friendly empty state instead of a blank or broken panel', Z.html().includes('No messages yet') && Z.html().includes('id="mi"') && !Z.html().includes('Tap a message to react'));

        /* ---------- layout / navigation ---------- */
        await Z.go('#/groups');
        const gl = Z.html();
        t('S03 layout (list): Groups lists only squads you can open, each linking to its conversation', gl.includes('href="#/gc/cm1"') && gl.includes('href="#/gc/cm2"') && !gl.includes('href="#/gc/cp"') && !gl.includes('href="#/gc/cx"'));
        await Z.go('#/gc/cm1');
        const gc = Z.html();
        t('S03 layout (mobile): the conversation has a back control to the list; (desktop) the list stays beside it', gc.includes('class="iconbtn gback"') && gc.includes('href="#/groups"') && gc.includes('gwrap act') && gc.includes('class="glist') && gc.includes('aria-current="true"'));
        t('S03 layout: css hides the back control on desktop, shows one panel at a time on mobile, two columns on desktop', /@media\(min-width:900px\)[\s\S]*\.gback\s*\{\s*display:none/.test(CSS_PAGES) && /\.gwrap\.act \.glist\s*\{\s*display:none/.test(CSS_PAGES) && /grid-template-columns:minmax\(300px,380px\) minmax\(0,1fr\)/.test(CSS_PAGES));
        t('S03 layout: the chat shows the group name, plan context and the existing group actions', gc.includes('Chat cm1') && gc.includes('aria-label="Group options"') && gc.includes('aria-label="Add attachment"'));
        t('S03 theme: chat styling uses the shared design tokens in both themes (no hard-coded page colours on the composer)', /\.comp\s*\{[^}]*background:var\(--bg\)/.test(CSS_BASE) && /\[data-theme="?dark"?\]|prefers-color-scheme:\s*dark/.test(CSS_BASE + CSS_PAGES));

        /* ---------- mobile keyboard / viewport ---------- */
        Z.ev("document.body.classList={contains:()=>true,toggle(){},remove(){}};document.documentElement.style=(()=>{const p={};return{p,setProperty:(k,v)=>p[k]=v,removeProperty:k=>delete p[k]}})();window.visualViewport={height:512.4,offsetTop:0,addEventListener(){}}");
        t('S03 keyboard: with the keyboard open the chat height follows the visible viewport', Z.ev("syncViewport()") === true && Z.ev("document.documentElement.style.p['--vvh']") == '512px');
        Z.ev("window.visualViewport.height=300");
        t('S03 keyboard: it keeps tracking as the keyboard grows', Z.ev("(syncViewport(),document.documentElement.style.p['--vvh'])") == '300px');
        Z.ev("document.body.classList.contains=()=>false");
        t('S03 keyboard: outside a chat the override is removed and the normal layout applies', Z.ev("(syncViewport(),document.documentElement.style.p['--vvh'])") === undefined);
        Z.ev("window.visualViewport=undefined;document.body.classList.contains=()=>true");
        t('S03 keyboard: browsers without visualViewport keep the plain 100dvh layout (no error)', Z.ev("syncViewport()") === false);
        t('S03 keyboard: css uses the published height with a 100dvh fallback for the chat container', (CSS_PAGES.match(/var\(--vvh,100dvh\)/g) || []).length == 3);

        /* ---------- attachments: validation, cancellation, permissions ---------- */
        await Z.go('#/gc/cm1');
        const okFile = f => Z.ev(`mediaValidate(${JSON.stringify(f)})`) === '';
        t('S03 media: JPG, PNG, WebP and GIF are accepted', ['image/jpeg', 'image/png', 'image/webp', 'image/gif'].every(type => okFile({ type, size: 1000 })));
        t('S03 media: SVG, PDF, executables, text, a missing type and a non-file are refused', ['image/svg+xml', 'application/pdf', 'application/x-msdownload', 'text/html', ''].every(type => !okFile({ type, size: 10 })) && Z.ev("mediaValidate(null)") != '' && Z.ev("mediaValidate({type:5})") != '');
        t('S03 media: an empty file and a file over the size limit are refused with clear messages', Z.ev("mediaValidate({type:'image/png',size:0})").includes('empty') && Z.ev("mediaValidate({type:'image/png',size:11*1048576})").includes('too large') && okFile({ type: 'image/png', size: 10 * 1048576 }));
        Z.click('attachments', { v: 'cm1' });
        t('S03 media: opening the attachment sheet asks for no permission', Z.sheet().includes('Share something') && Z.camCalls == 0);
        Z.files.push({ type: 'image/svg+xml', size: 500 }); Z.toasts.length = 0;
        Z.click('mediaGallery', { v: 'cm1' }); await sleep(40);
        t('S03 media: an unsupported file is refused with feedback, no preview, and the chat still works', Z.said("isn't supported") && Z.ev('O.media') === null && !Z.sheet().includes('Preview') && (Z.ev("O.chat.draft='still works';A.send('cm1')"), JSON.parse(texts('cm1')).includes('still works')));
        Z.files.push({ type: 'image/png', size: 11 * 1048576 }); Z.toasts.length = 0;
        Z.click('mediaGallery', { v: 'cm1' }); await sleep(40);
        t('S03 media: an oversized image is refused with feedback and nothing is kept', Z.said('too large') && Z.ev('O.media') === null);
        Z.click('mediaGallery', { v: 'cm1' }); await sleep(40);
        t('S03 media: cancelling the picker (no file chosen) changes nothing', Z.ev('O.media') === null && !Z.sheet().includes('Preview'));
        Z.files.push({ type: 'image/png', size: 2000 });
        Z.click('mediaGallery', { v: 'cm1' }); await sleep(40);
        t('S03 media: a valid image shows a preview with Send and a way to choose another', Z.sheet().includes('Preview') && Z.sheet().includes('Choose another') && Z.ev("O.media&&O.media.id")=='cm1');
        const m0 = cnt('cm1'); Z.click('sendMedia', { k: 'cm1' });
        t('S03 media: sending adds one photo message to that squad and releases the pending attachment', cnt('cm1') == m0 + 1 && Z.ev("S.msgs.cm1.slice(-1)[0].type") == 'photo' && Z.ev('O.media') === null && Z.sheet() == '');
        Z.files.push({ type: 'image/png', size: 2000 });
        Z.click('attachments', { v: 'cm2' }); Z.click('mediaGallery', { v: 'cm2' });
        Z.ev("memRemove(pl('cm2'),'me','u1')");
        await sleep(60);
        t('S03 media: an image picked just as access is lost never reaches a preview or the conversation', Z.ev('O.media') === null && !Z.sheet().includes('Preview') && JSON.parse(texts('cm2')).length == 0);
        Z.ev("S.plans.find(p=>p.id=='cm2').removed=[];S.plans.find(p=>p.id=='cm2').members.push('me')");
        Z.cam = { name: 'NotAllowedError' };
        Z.click('openMediaCamera', { v: 'cm1' }); await sleep(40);
        t('S03 camera: permission denied shows instructions, Try again and a gallery fallback; nothing is sent', Z.sheet().includes('Camera access is blocked') && Z.sheet().includes('Try again') && Z.sheet().includes('Choose from gallery instead') && Z.ev('O.media') === null);
        Z.cam = { name: 'NotFoundError' }; Z.click('mediaRetry', { v: 'cm1' }); await sleep(40);
        t('S03 camera: no camera available points to the gallery', Z.sheet().includes('No camera available'));
        Z.ev("window.__md=navigator.mediaDevices;navigator.mediaDevices=undefined"); Z.click('openMediaCamera', { v: 'cm1' }); await sleep(40);
        t('S03 camera: a browser without camera support degrades gracefully (no crash, gallery still offered)', Z.sheet().includes('No camera available') && Z.sheet().includes('Choose from gallery instead'));
        Z.ev("navigator.mediaDevices=window.__md"); Z.cam = { ok: 1 }; Z.click('close');
        t('S03 media: no object URLs are created anywhere (nothing to leak); previews are bounded by the 1280 px re-encode', !/createObjectURL/.test(allSrc()) && /1280/.test(fs.readFileSync('src/js/utils/media.js', 'utf8')));
        const st = Z.streams.length;
        Z.click('openMediaCamera', { v: 'cm1' }); await sleep(40); Z.click('close'); await sleep(10);
        t('S03 media: closing the camera sheet stops the stream', Z.streams.length == st + 1 && Z.streams[Z.streams.length - 1].stopped == 1);

        /* ---------- unread ---------- */
        await Z.go('#/gc/cm1'); await sleep(1700); /* let the sample replies to the messages sent above land while this chat is open */
        Z.ev("S.unread={cm1:-4,cm2:'x',cp:3,zzz:2,cx:9,cl:1}"); Z.ev('render()');
        t('S03 unread: negative, non-numeric, unknown-squad and no-access entries are discarded; the total is never negative', Z.ev('unreadTotal()') == 0 && Z.ev('Object.keys(S.unread).length') == 0);
        Z.ev("S.unread={cm1:2.9,cm2:3}"); await Z.go('#/groups');
        t('S03 unread: whole numbers per squad, summed on the Groups nav badge, shown on each squad in the list', Z.ev('unreadFor("cm1")') == 2 && Z.ev('unreadTotal()') == 5 && Z.html().includes('5 unread messages') && Z.html().includes('2 unread') && Z.html().includes('3 unread'));
        Z.ev('render();render();render()');
        t('S03 unread: repeated rendering does not change counts', Z.ev('unreadTotal()') == 5);
        await Z.go('#/gc/cm1');
        t('S03 unread: opening a conversation clears only that squad and the nav stays on Groups', Z.ev('unreadTotal()') == 3 && Z.ev('unreadFor("cm1")') == 0 && /aria-current="page"[^>]*>\s*<b>[\s\S]{0,400}?Groups/.test(Z.html().match(/<nav[\s\S]*?<\/nav>/)[0]));
        await Z.go('#/groups');
        t('S03 unread: returning to the list does not bring the cleared count back', Z.ev('unreadFor("cm1")') == 0 && Z.ev('unreadTotal()') == 3);
        Z.ev("O.chat.draft='ping';A.send('cm1')"); await Z.go('#/groups'); await sleep(1600);
        t('S03 unread: a reply that arrives while you are on the list counts once, for the right squad', Z.ev('unreadFor("cm1")') == 1 && Z.ev('unreadFor("cm2")') == 3);
        Z.ev("memRemove(pl('cm2'),'me','u1')"); Z.ev('render()');
        t('S03 unread: losing access to a squad removes its unread count at once', Z.ev('unreadFor("cm2")') == 0 && Z.ev('unreadTotal()') == 1 && !('cm2' in Z.ev('S.unread')));
        Z.ev("O.chat.draft='stale reply please';A.send('cm1')"); Z.ev("memRemove(pl('cm1'),'me','u1')"); await sleep(1700);
        t('S03 unread: a delayed sample reply cannot raise the count of a squad you were removed from', Z.ev('unreadTotal()') == 0);

        /* ---------- reliability counter ---------- */
        mkp('rl1'); mkp('rl2', "{creator:'me',members:['me','u2']}");
        const rel0 = Z.ev('S.me.rel.cancel');
        Z.click('ask', { do: 'leave', v: 'rl1' }); Z.click('confirmed'); await sleep(300);
        t('S03 reliability: voluntarily leaving an open squad updates membership and access but not the cancellation counter', Z.ev("membership(pl('rl1'),'me')") == 'left' && !acc('rl1') && Z.ev('S.me.rel.cancel') == rel0);
        await Z.go('#/gc/rl1');
        t('S03 reliability: the departed member is refused the conversation', Z.html().includes('No access') && !Z.html().includes('start rl1'));
        const u3Before = Z.ev("(usr('u3').rel&&usr('u3').rel.cancel)||0");
        Z.ev("pl('rl2').members.push('u3')"); Z.click('remove', { k: 'rl2', v: 'u3' });
        t('S03 reliability: a host removing a member records no cancellation for anyone', Z.ev("membership(pl('rl2'),'u3')") == 'removed' && Z.ev('S.me.rel.cancel') == rel0 && Z.ev("(usr('u3').rel&&usr('u3').rel.cancel)||0") == u3Before);
        Z.click('cancel', { v: 'rl2' });
        t('S03 reliability: a host really cancelling a plan still follows the existing rule (counts once)', Z.ev('S.me.rel.cancel') == rel0 + 1);

        /* ---------- group-page responsibilities / navigation ---------- */
        t('S03 navigation: still exactly Home, Discover, Create, Groups, Profile; no QR/attendance/completion item', Z.ev('NAV.map(n=>n.l).join()') == 'Home,Discover,Create,Groups,Profile' && Z.ev('NAV.length') == 5);
        await Z.go('#/me');
        t('S03 profile: no "My Squads" section (Groups is the single place)', !Z.html().includes('My Squads') && !Z.html().includes('Waiting on the host'));
        const navHtml = Z.html().match(/<nav[\s\S]*?<\/nav>/)[0];
        t('S03 navigation: each primary item appears once', ['Home', 'Discover', 'Create', 'Groups', 'Profile'].every(l => navHtml.split('<span>' + l + '<').length == 2));
        await Z.go('#/gc/cm1');
        t('S03 group page: the chat has no scanner, check-in or completion controls', !Z.html().includes('scanOpen') && !Z.html().includes('attStart') && !Z.html().includes('compOk'));
        t('S03 data boundary: message data is read and written only by the chat state/actions (one place to swap for a backend)', allSrcFiles().filter(f => /msgs\(|S\.msgs/.test(fs.readFileSync(f, 'utf8'))).map(f => f.replace(/^src\/js\//, '')).sort().join() == ['app/actions.js', 'components/squads/GroupChat.js', 'components/squads/GroupList.js', 'state/chat.js', 'state/store.js'].join());
        t('S03 source: no backend, framework or paid service in the chat code', !/supabase|firebase|firestore|createClient|XMLHttpRequest|fetch\(/.test(['components/squads/GroupChat.js', 'components/squads/MediaSheet.js', 'state/chat.js', 'app/viewport.js', 'utils/media.js'].map(f => fs.readFileSync('src/js/' + f, 'utf8')).join('')));
    }

}

/* Runner: always ends with one clear summary line and a real exit code, whether the suite finishes, an assertion
   throws (reported as a failure with its stack), a promise is rejected, or the whole run hangs (watchdog). */
let finished = false;
const finish = (why) => {
    if (finished) return;
    finished = true;
    if (why) { bad++; console.log('FAIL ' + why); }
    console.log('RESULT: ' + ok + ' passed, ' + bad + ' failed' + (bad ? ' (FAILED)' : ' (all passed)'));
    process.exitCode = bad ? 1 : 0;
    process.exit(process.exitCode);
};
const watchdog = setTimeout(() => finish('test run exceeded 300 s and was stopped; last completed test: "' + last + '"'), 300000);
/* a stall (no assertion finishing for 45 s) is reported with the last completed test instead of hanging silently */
const stall = setInterval(() => { if (Date.now() - lastAt > 45000) finish('no test finished for 45 s; last completed test: "' + last + '"'); }, 5000);
stall.unref();
process.on('unhandledRejection', e => finish('unhandled rejection: ' + (e && e.stack || e)));
process.on('uncaughtException', e => finish('uncaught exception: ' + (e && e.stack || e)));
main().then(() => { clearTimeout(watchdog); finish(); }, e => finish('suite stopped by an error: ' + (e && e.stack || e)));
